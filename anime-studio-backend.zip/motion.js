'use strict'

const fs = require('node:fs/promises')
const path = require('node:path')

function loadMotionTools() {
  try {
    const gsap = require.resolve('gsap/dist/gsap.min.js')
    const install = path.dirname(require.resolve('hyperframes/package.json'))
    return { gsap, cli: path.join(install, 'bin', 'hyperframes.mjs') }
  } catch {
    return null
  }
}

function bounded(value, fallback, low, high) {
  const number = value ?? fallback
  if (typeof number !== 'number' || !Number.isFinite(number) || number < low || number > high) {
    throw new Error(`Se esperaba un número entre ${low} y ${high}`)
  }
  return number
}

function color(value, fallback) {
  const text = value ?? fallback
  if (typeof text !== 'string' || !/^#[a-f\d]{6}$/i.test(text)) throw new Error('Usá un color hex de seis dígitos')
  return text
}

function validateMotion(value) {
  if (!value || typeof value !== 'object' || !Array.isArray(value.layers) ||
      value.layers.length < 1 || value.layers.length > 20) throw new Error('La composición requiere entre 1 y 20 capas')
  const duration = bounded(value.duration, 4, 0.5, 10)
  const dimension = (size, fallback) => Math.floor(bounded(size, fallback, 128, 1280) / 2) * 2
  const width = dimension(value.width, 960)
  const height = dimension(value.height, 540)
  const fps = value.fps ?? 30
  if (![24, 25, 30, 50, 60].includes(fps)) throw new Error('FPS no compatible')
  const format = value.transparent === true ? 'webm' : 'mp4'
  const background = format === 'webm' ? 'transparent' : color(value.background, '#100c1c')
  const layers = value.layers.map(layer => {
    if (!layer || !['text', 'rectangle', 'circle', 'image'].includes(layer.kind)) throw new Error('Tipo de capa inválido')
    if (layer.kind === 'text' && (typeof layer.text !== 'string' || !layer.text.trim() || layer.text.length > 240)) {
      throw new Error('Cada texto requiere entre 1 y 240 caracteres')
    }
    const dataUrl = layer.kind === 'image' ? layer.dataUrl : undefined
    if (layer.kind === 'image' && (typeof dataUrl !== 'string' || dataUrl.length > 2_800_000 ||
      !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(dataUrl))) {
      throw new Error('La imagen debe ser PNG, JPEG o WebP local de hasta 2 MB')
    }
    const size = bounded(layer.size, 64, 4, 500)
    if (!Array.isArray(layer.frames) || layer.frames.length < 1 || layer.frames.length > 20) {
      throw new Error('Cada capa requiere entre 1 y 20 keyframes')
    }
    const frames = layer.frames.map(frame => {
      if (!frame || !Object.hasOwn(frame, 'time')) throw new Error('Falta el tiempo de un keyframe')
      return {
        time: bounded(frame.time, 0, 0, duration),
        x: bounded(frame.x, 50, -100, 200),
        y: bounded(frame.y, 50, -100, 200),
        rotation: bounded(frame.rotation, 0, -2160, 2160),
        scale: bounded(frame.scale, 1, 0, 12),
        opacity: bounded(frame.opacity, 1, 0, 1),
        ease: ['none', 'power2.in', 'power2.out', 'power2.inOut'].includes(frame.ease) ? frame.ease : 'none',
      }
    })
    if (frames[0].time !== 0 || frames.some((frame, i) => i > 0 && frame.time <= frames[i - 1].time)) {
      throw new Error('Los keyframes deben comenzar en cero y estar en orden creciente')
    }
    return { kind: layer.kind, dataUrl, text: layer.kind === 'text' ? layer.text : '', color: color(layer.color, '#ffffff'), size, frames }
  })
  return { duration, width, height, fps, background, format, layers }
}

function htmlFor(scene, gsap) {
  const layers = scene.layers.map((layer, i) => {
    const shape = layer.kind === 'text' ? `font-size:${layer.size}px;color:${layer.color}`
      : `width:${layer.size}px;height:${layer.size}px;background:${layer.color};border-radius:${layer.kind === 'circle' ? 50 : 0}%`
    if (layer.kind === 'image') return `<img alt="" id="layer-${i}" class="layer" style="width:${layer.size}px;height:auto" />`
    return `<div id="layer-${i}" class="layer" style="${shape}"></div>`
  }).join('\n')
  const data = JSON.stringify(scene.layers).replaceAll('<', '\\u003c')
  return `<!doctype html>
<html lang="es"><meta charset="utf-8">
<style>
*{box-sizing:border-box} body{margin:0;overflow:hidden;background:${scene.background}}
#motion{position:absolute;inset:0;overflow:hidden}
.layer{position:absolute;left:0;top:0;white-space:pre-line;text-align:center;font-family:system-ui,sans-serif;font-weight:800}
</style>
<div id="motion" data-composition-id="motion" data-start="0" data-duration="${scene.duration}"
  data-width="${scene.width}" data-height="${scene.height}" data-fps="${scene.fps}">
${layers}
</div>
<script>${gsap}</script>
<script>
const layers = ${data};
const tl = gsap.timeline({paused:true});
tl.set('#motion', {visibility:'visible'}, ${scene.duration});
function properties(f) {
  return {left:f.x+'%',top:f.y+'%',xPercent:-50,yPercent:-50,scale:f.scale,rotation:f.rotation,opacity:f.opacity};
}
layers.forEach((layer,i) => {
  const el = document.getElementById('layer-'+i);
  if (layer.kind === 'image') el.src = layer.dataUrl;
  else el.textContent = layer.text;
  gsap.set(el, properties(layer.frames[0]));
  for (let j=1; j<layer.frames.length; j++) {
    const before = layer.frames[j-1], after = layer.frames[j];
    tl.fromTo(el, properties(before), {...properties(after),duration:after.time-before.time,ease:after.ease,immediateRender:false}, before.time);
  }
});
window.__timelines ??= {};
window.__timelines.motion = tl;
</script>
</html>`
}

async function renderMotion(job, spec, run) {
  const tools = loadMotionTools()
  if (!tools) throw new Error('Instalá HyperFrames y GSAP en el servidor de render')
  const scene = validateMotion(spec)
  const source = path.join(job.dir, 'index.html')
  const json = path.join(job.dir, 'motion.json')
  const video = path.join(job.dir, `motion.${scene.format}`)
  const gsap = await fs.readFile(tools.gsap, 'utf8')
  await Promise.all([
    fs.writeFile(source, htmlFor(scene, gsap)),
    fs.writeFile(json, JSON.stringify(spec, null, 2)),
  ])
  await run(process.execPath, [tools.cli, 'render', job.dir, '-o', video, '--format', scene.format,
    '--fps', String(scene.fps), '--workers', '1', '--quality', 'draft', '--no-browser-gpu'],
  { job, timeoutMs: 12 * 60_000 })
  return {
    video, source, json, mime: scene.format === 'webm' ? 'video/webm' : 'video/mp4',
    result: { duration: scene.duration, width: scene.width, height: scene.height, fps: scene.fps, transparent: scene.format === 'webm' },
  }
}

module.exports = { loadMotionTools, renderMotion, validateMotion }
