"""Render a bounded, declarative scene in Blender background mode."""
import json
import math
from pathlib import Path
import sys
from zipfile import ZIP_STORED, ZipFile

import bpy
from mathutils import Vector


def aim(obj, position, target):
    obj.location = position
    obj.rotation_euler = (Vector(target) - Vector(position)).to_track_quat("-Z", "Y").to_euler()


def create_objects(items):
    primitives = {
        "cube": bpy.ops.mesh.primitive_cube_add,
        "sphere": bpy.ops.mesh.primitive_uv_sphere_add,
        "plane": bpy.ops.mesh.primitive_plane_add,
        "cylinder": bpy.ops.mesh.primitive_cylinder_add,
        "cone": bpy.ops.mesh.primitive_cone_add,
    }
    for item in items:
        primitives[item["kind"]](location=item["position"])
        obj = bpy.context.object
        obj.scale = item["scale"]
        obj.rotation_euler = [math.radians(angle) for angle in item["rotation"]]
        material = bpy.data.materials.new(name="Anime Studio Material")
        material.use_nodes = True
        bsdf = material.node_tree.nodes.get("Principled BSDF")
        color = (*item["color"], 1)
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Emission Color"].default_value = color
        bsdf.inputs["Emission Strength"].default_value = item["emission"]
        obj.data.materials.append(material)


def configure_camera(scene, config):
    camera = bpy.data.objects.new("Camera", bpy.data.cameras.new("Camera"))
    scene.collection.objects.link(camera)
    scene.camera = camera
    camera.data.lens = config["lens"]
    for pose, frame in ((config["from"], scene.frame_start), (config["to"], scene.frame_end)):
        aim(camera, pose["position"], pose["target"])
        camera.keyframe_insert(data_path="location", frame=frame)
        camera.keyframe_insert(data_path="rotation_euler", frame=frame)


def main():
    source, blend, output, model = sys.argv[sys.argv.index("--") + 1:]
    with open(source, encoding="utf-8") as fp:
        config = json.load(fp)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.frame_start = 1
    scene.frame_end = config["frames"]
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = 4
    scene.cycles.use_denoising = False
    scene.render.threads_mode = "FIXED"
    scene.render.threads = 2
    scene.render.resolution_x = config["width"]
    scene.render.resolution_y = config["height"]
    scene.render.resolution_percentage = 100
    scene.render.fps = config["fps"]
    scene.world = bpy.data.worlds.new("World")
    scene.world.use_nodes = True
    scene.world.node_tree.nodes.get("Background").inputs["Color"].default_value = (*config["world"], 1)
    if model:
        bpy.ops.import_scene.gltf(filepath=model)
        bpy.ops.file.pack_all()
    create_objects(config["objects"])
    configure_camera(scene, config["camera"])
    for item in config["lights"]:
        data = bpy.data.lights.new("Area", "AREA")
        data.energy = item["power"]
        data.color = item["color"]
        data.shape = "DISK"
        data.size = 3
        light = bpy.data.objects.new("Area", data)
        scene.collection.objects.link(light)
        aim(light, item["position"], item["target"])
    frame_dir = Path(output).parent / "frames"
    if config["sequence"]:
        scene.render.image_settings.file_format = "PNG"
        scene.render.filepath = "//frames/frame-"
        frame_dir.mkdir()
    else:
        scene.render.image_settings.file_format = "FFMPEG"
        scene.render.ffmpeg.format = "MPEG4"
        scene.render.ffmpeg.codec = "H264"
        scene.render.ffmpeg.constant_rate_factor = "MEDIUM"
        scene.render.use_file_extension = False
        scene.render.filepath = "//scene.mp4"
    scene.frame_set(1)
    bpy.ops.wm.save_as_mainfile(filepath=blend)
    scene.render.filepath = str(frame_dir / "frame-") if config["sequence"] else output
    bpy.ops.render.render(animation=True)
    if config["sequence"]:
        frames = sorted(frame_dir.glob("frame-*.png"))
        if len(frames) != config["frames"]:
            raise RuntimeError("La secuencia de fotogramas está incompleta")
        with ZipFile(frame_dir.parent / "fotogramas.zip", "w", compression=ZIP_STORED) as archive:
            for frame in frames:
                archive.write(frame, arcname=frame.name)


if __name__ == "__main__":
    main()
