'use strict'

const fs = require('node:fs')
const fsp = require('node:fs/promises')
const http = require('node:http')
const path = require('node:path')
const crypto = require('node:crypto')
const { pipeline } = require('node:stream/promises')

const TYPES = {
  '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.woff2': 'font/woff2',
}

function settingsFor(manifest) {
  const { doc, settings, items } = manifest ?? {}
  if (!doc || !settings || !Array.isArray(items) || items.length > 32 ||
      !Array.isArray(doc.clips) || !Array.isArray(doc.assets) || !Array.isArray(doc.tracks) ||
      doc.clips.length < 1 || doc.clips.length > 140 || doc.tracks.length > 40 || doc.assets.length !== items.length) {
    throw new Error('Proyecto inválido o fuera de los límites del render remoto')
  }
  const dimensions = [doc.composition?.width, doc.composition?.height, settings.width, settings.height]
  if (dimensions.some(size => !Number.isInteger(size) || size < 16 || size > 3840) ||
      settings.width * settings.height > 1920 * 1080 || settings.width % 2 || settings.height % 2 ||
      !Number.isFinite(doc.composition?.fps) || doc.composition.fps < 1 || doc.composition.fps > 120 ||
      ![24, 25, 30, 50, 60].includes(settings.fps) || !['mp4', 'mov', 'webm'].includes(settings.format) ||
      !['low', 'medium', 'high'].includes(settings.quality)) {
    throw new Error('Resolución, calidad o FPS fuera de los límites del servidor (hasta 1080p)')
  }
  if (!Number.isFinite(doc.composition?.duration) || doc.composition.duration <= 0 || doc.composition.duration > 90 ||
      doc.clips.some(clip => !clip || !Number.isFinite(clip.start) || !Number.isFinite(clip.duration) ||
        clip.start < 0 || clip.duration <= 0 || clip.start + clip.duration > 90)) {
    throw new Error('El render remoto admite hasta 90 segundos por proyecto')
  }
  if (!items.every((item, index) => item?.id === doc.assets[index]?.id && typeof item.id === 'string' &&
      item.id.length < 200 && Number.isSafeInteger(item.size) && item.size > 0 &&
      ['video', 'audio', 'image'].includes(doc.assets[index]?.kind)) ||
      new Set(items.map(item => item.id)).size !== items.length) throw new Error('Medios del proyecto inválidos')
  if (doc.clips.some(clip => ['video', 'audio', 'image'].includes(clip.kind) && !items.some(item => item.id === clip.assetId))) {
    throw new Error('Faltan medios del proyecto')
  }
  const audioKbps = Number(settings.audioKbps ?? 192)
  if (!Number.isInteger(audioKbps) || audioKbps < 32 || audioKbps > 320) throw new Error('Bitrate de audio inválido')
  return { doc, items, settings: { width: settings.width, height: settings.height, fps: settings.fps, format: settings.format,
    quality: settings.quality, audioKbps } }
}

async function unpack(source, dir) {
  const handle = await fsp.open(source, 'r')
  try {
    const header = Buffer.alloc(4)
    if ((await handle.read(header, 0, 4, 0)).bytesRead !== 4) throw new Error("Proyecto incompleto")
    const length = header.readUInt32BE(0)
    if (length < 2 || length > 1_000_000) throw new Error('Cabecera de proyecto inválida')
    const manifest = Buffer.alloc(length)
    if ((await handle.read(manifest, 0, length, 4)).bytesRead !== length) throw new Error('Proyecto incompleto')
    const plan = settingsFor(JSON.parse(manifest.toString('utf8')))
    let offset = 4 + length
    if (offset + plan.items.reduce((total, item) => total + item.size, 0) !== (await handle.stat()).size) {
      throw new Error('Paquete de proyecto incompleto')
    }
    for (let i = 0; i < plan.items.length; i++) {
      const item = plan.items[i]
      const dest = path.join(dir, `asset-${i}`)
      await pipeline(fs.createReadStream(source, { start: offset, end: offset + item.size - 1 }), fs.createWriteStream(dest, { flags: 'wx', mode: 0o600 }))
      offset += item.size
    }
    return plan
  } finally {
    await handle.close()
  }
}

function trustedUiFile(root, prefix, pathname) {
  if (!pathname.startsWith(`${prefix}/`)) return null
  const rel = pathname.slice(prefix.length + 1)
  if (rel !== 'render-worker.html' && !/^_next\/static\/[a-zA-Z0-9._/-]+$/.test(rel)) return null
  const file = path.resolve(root, rel)
  return file.startsWith(`${root}${path.sep}`) ? file : null
}

async function sendMedia(req, res, filename, mime, bytes, allowRange) {
  const range = allowRange && req.headers.range?.match(/^bytes=(\d+)-(\d*)$/)
  const start = range ? Number(range[1]) : 0
  const end = range && range[2] ? Math.min(Number(range[2]), bytes - 1) : bytes - 1
  if (start > end || start >= bytes) { res.writeHead(416); res.end(); return }
  const headers = { 'Content-Type': mime, 'Content-Length': end - start + 1, 'X-Content-Type-Options': 'nosniff' }
  if (allowRange) headers['Accept-Ranges'] = 'bytes'
  if (range) headers['Content-Range'] = `bytes ${start}-${end}/${bytes}`
  res.writeHead(range ? 206 : 200, headers)
  await pipeline(fs.createReadStream(filename, { start, end }), res)
}

async function storeOutput(req, dest, maxBytes) {
  const handle = await fsp.open(dest, 'wx', 0o600)
  let bytes = 0
  try {
    for await (const chunk of req) {
      bytes += chunk.length
      if (bytes > maxBytes) throw new Error('El render excede el límite de salida')
      await handle.writeFile(chunk)
    }
  } finally { await handle.close() }
}

async function renderInBrowser(dir, plan, root, prefix, maxBytes) {
  const puppeteer = require('puppeteer-core')
  const token = crypto.randomBytes(24).toString('hex')
  const privateRoute = `/render/${token}`
  const app = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost')
      if (req.method === 'PUT' && [`${privateRoute}/video`, `${privateRoute}/audio`].includes(url.pathname)) {
        await storeOutput(req, path.join(dir, url.pathname.endsWith('/audio') ? 'render-audio.wav' : 'render-media.bin'), maxBytes)
        res.writeHead(201); res.end(); return
      }
      if (req.method !== 'GET') { res.writeHead(405); res.end(); return }
      const index = url.pathname.startsWith(`${privateRoute}/`) ? url.pathname.slice(privateRoute.length + 1) : ''
      if (/^\d+$/.test(index) && plan.items[Number(index)]) {
        await sendMedia(req, res, path.join(dir, `asset-${index}`), 'application/octet-stream', plan.items[Number(index)].size, true)
        return
      }
      const file = trustedUiFile(root, prefix, url.pathname)
      if (!file) { res.writeHead(404); res.end(); return }
      await sendMedia(req, res, file, TYPES[path.extname(file)] || 'application/octet-stream', (await fsp.stat(file)).size, false)
    } catch {
      if (res.headersSent) res.destroy()
      else { res.writeHead(404); res.end() }
    }
  })
  await new Promise((resolve, reject) => {
    app.once('error', reject)
    app.listen(0, '127.0.0.1', resolve)
  })
  const origin = `http://127.0.0.1:${app.address().port}`
  let browser
  try {
    browser = await puppeteer.launch({
      executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium',
      headless: true, protocolTimeout: 600_000,
      args: ['--no-sandbox', '--disable-background-networking', '--disable-dev-shm-usage', '--use-gl=angle', '--use-angle=swiftshader',
        '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required', '--mute-audio'],
    })
    const page = await browser.newPage()
    await page.setRequestInterception(true)
    page.on('request', request => {
      const local = request.url().startsWith(`${origin}/`)
      const generated = /^(data:|blob:)/.test(request.url())
      void (local || generated ? request.continue() : request.abort()).catch(() => {})
    })
    await page.exposeFunction('animeRenderProgress', update => process.stdout.write(`TIMELINE=${JSON.stringify(update)}\n`))
    await page.goto(`${origin}${prefix}/render-worker.html`)
    await page.waitForFunction('typeof window.animeRenderProject === "function"', { timeout: 20_000 })
    const doc = {
      ...plan.doc,
      assets: plan.doc.assets.map((asset, index) => ({
        id: asset.id, kind: asset.kind, name: asset.name, duration: asset.duration, width: asset.width, height: asset.height,
        fps: asset.fps, size: plan.items[index].size, url: `${origin}${privateRoute}/${index}`,
      })),
    }
    await page.evaluate(({ doc, settings, output, audio }) => window.animeRenderProject(doc, settings, output, audio), {
      doc, settings: { ...plan.settings, format: 'auto', engine: 'auto' },
      output: `${origin}${privateRoute}/video`, audio: `${origin}${privateRoute}/audio`,
    })
  } finally {
    try { await browser?.close() } finally {
      app.closeAllConnections()
      await new Promise(resolve => app.close(resolve))
    }
  }
}

async function main() {
  const [dir, source, root, prefix, maxBytes] = process.argv.slice(2)
  const plan = await unpack(source, dir)
  await renderInBrowser(dir, plan, root, prefix, Number(maxBytes))
  await fsp.writeFile(path.join(dir, 'settings.json'), JSON.stringify(plan.settings))
}

if (require.main === module) {
  main().catch(error => {
    console.error(error.message)
    process.exitCode = 1
  })
}
