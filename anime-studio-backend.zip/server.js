#!/usr/bin/env node
/**
 * Anime Studio media API. Job state is kept in memory and each input/output
 * lives in a private temporary directory. See LEEME-BACKEND.md for deployment,
 * supported operations and the optional rendering and speech dependencies.
 */

'use strict'

const http = require('node:http')
const os = require('node:os')
const fs = require('node:fs')
const fsp = require('node:fs/promises')
const path = require('node:path')
const crypto = require('node:crypto')
const { pipeline } = require('node:stream/promises')
const { spawn } = require('node:child_process')
const { loadMotionTools, renderMotion, validateMotion } = require('./motion')
const { renderScene, stageModel, validateScene } = require('./scene3d')
const { aiEnabled, planProduction } = require('./assistant')

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

function limit(name, fallback, min, max) {
  const value = Number(process.env[name] ?? fallback)
  if (!Number.isSafeInteger(value) || value < min || value > max) {
    throw new Error(`${name} debe estar entre ${min} y ${max}`)
  }
  return value
}

const PORT = limit('PORT', 8787, 0, 65535)
const ORIGINS = new Set((process.env.ALLOWED_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean))
const MAX_UPLOAD_MB = limit('MAX_UPLOAD_MB', 32, 1, 200)
const MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
const CONCURRENCY = limit('CONCURRENCY', 1, 1, 8)
const JOB_TTL_MIN = limit('JOB_TTL_MIN', 120, 1, 1440)
const MAX_JOBS = limit('MAX_JOBS', 12, 1, 100)
const MAX_PER_USER = limit('MAX_JOBS_PER_USER', 4, 1, MAX_JOBS)
const OUTPUT_ROOT = path.resolve(process.env.OUTPUT_DIR || path.join(os.tmpdir(), 'anime-studio-jobs'))
const MAX_OUTPUT_MB = limit('MAX_OUTPUT_MB', 128, 1, 1024)
const MAX_DURATION_SECONDS = limit('MAX_DURATION_SECONDS', 600, 10, 7200)
const YTDLP_PROXY = process.env.YTDLP_PROXY || ''
const RENDER_ROOT = process.env.RENDER_FRONTEND_DIR ? path.resolve(process.env.RENDER_FRONTEND_DIR) : ''
const RENDER_PREFIX = process.env.RENDER_FRONTEND_BASE_PATH ?? '/anime-studio'
if (RENDER_PREFIX && !/^\/[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*$/.test(RENDER_PREFIX)) {
  throw new Error('RENDER_FRONTEND_BASE_PATH debe ser una subruta válida')
}
function canRenderProject() {
  try {
    return Boolean(RENDER_ROOT) && fs.existsSync(path.join(RENDER_ROOT, 'render-worker.html')) &&
      fs.existsSync(process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium') &&
      Boolean(require.resolve('puppeteer-core'))
  } catch { return false }
}
const TOKEN_HASHES = new Map()
const tokenHash = token => crypto.createHash('sha256').update(token).digest()
const configuredTokens = JSON.parse(process.env.BACKEND_TOKENS || '{}')
if (!configuredTokens || typeof configuredTokens !== 'object' || Array.isArray(configuredTokens)) {
  throw new Error('BACKEND_TOKENS debe ser un objeto JSON usuario → token')
}
if (process.env.BACKEND_TOKEN) configuredTokens.__personal = process.env.BACKEND_TOKEN
for (const [owner, token] of Object.entries(configuredTokens)) {
  if (typeof token !== 'string' || !/^[A-Za-z0-9_-]{32,128}$/.test(token)) {
    throw new Error('Los tokens deben usar 32–128 caracteres alfanuméricos, guiones o guiones bajos')
  }
  const hash = tokenHash(token)
  if ([...TOKEN_HASHES.values()].some(existing => existing.equals(hash))) {
    throw new Error('Cada usuario necesita un token distinto')
  }
  TOKEN_HASHES.set(owner, hash)
}
if (!TOKEN_HASHES.size) throw new Error('Configurá BACKEND_TOKENS o BACKEND_TOKEN para iniciar la API')

// ---------------------------------------------------------------------------
// Estado: cola de trabajos
// ---------------------------------------------------------------------------

/** @type {Map<string, any>} */
const jobs = new Map()
const queue = []
let running = 0

function newJob(id, owner, type, label) {
  const job = {
    id,
    owner,
    dir: path.join(OUTPUT_ROOT, id),
    type,
    label: label || type,
    state: 'queued', // queued | running | done | error | cancelled
    progress: 0,
    message: 'En cola',
    createdAt: Date.now(),
    files: [], // { name, path, mime, size }
    result: null, // JSON opcional (ej. segmentos de subtítulos)
    error: null,
    cancelRequested: false,
    /** @type {(() => void) | null} */
    onCancel: null,
    payload: null,
    expiresAt: null,
  }
  jobs.set(id, job)
  return job
}

function enqueue(job) {
  queue.push(job)
  drain()
}

function drain() {
  while (running < CONCURRENCY && queue.length > 0) {
    const job = queue.shift()
    if (!job || job.state === 'cancelled') continue
    running++
    setJobState(job, 'running', 'Procesando…')
    runJob(job)
      .then(() => {
        if (job.state !== 'cancelled') {
          job.progress = 1
          setJobState(job, 'done', 'Listo')
        }
      })
      .catch(err => {
        if (job.state !== 'cancelled') {
          job.error = String(err && err.message ? err.message : err)
          setJobState(job, 'error', job.error)
        }
      })
      .finally(() => {
        job.payload = null
        job.expiresAt = Date.now() + JOB_TTL_MIN * 60_000
        if (job.state !== 'done') void cleanup(job)
        running--
        drain()
      })
  }
}

function setJobState(job, state, message) {
  job.state = state
  if (message != null) job.message = message
}

function setProgress(job, p, message) {
  job.progress = Math.max(0, Math.min(1, p))
  if (message) job.message = message
}

function checkCancelled(job) {
  if (job.cancelRequested) {
    throw Object.assign(new Error('Cancelado por el usuario'), { cancelled: true })
  }
}

async function cleanup(job) {
  await fsp.rm(job.dir, { recursive: true, force: true }).catch(() => {})
}

setInterval(() => {
  const now = Date.now()
  for (const [id, job] of jobs) {
    if (job.expiresAt !== null && now >= job.expiresAt) {
      jobs.delete(id)
      void cleanup(job)
    }
  }
}, 15_000).unref()

// ---------------------------------------------------------------------------
// Capacidades reales del servidor (nada inventado: se ejecuta el binario)
// ---------------------------------------------------------------------------

async function binVersion(bin, args = ['-version']) {
  return new Promise(resolve => {
    let done = false
    const finish = v => { if (!done) { done = true; resolve(v) } }
    const p = spawn(bin, args, { env: toolEnvironment(), stdio: ['ignore', 'pipe', 'ignore'] })
    let out = ''
    p.stdout.on('data', d => { out += d })
    p.on('error', () => finish(null))
    p.on('close', code => finish(code === 0 ? out.split('\n')[0].trim() : null))
    setTimeout(() => { try { p.kill('SIGKILL') } catch { } finish(null) }, 8000).unref()
  })
}

async function pyHasModule(mod) {
  return new Promise(resolve => {
    let done = false
    const finish = v => { if (!done) { done = true; resolve(v) } }
    const p = spawn('python3', ['-c', `import ${mod}`], { env: toolEnvironment(), stdio: 'ignore' })
    p.on('error', () => finish(false))
    p.on('close', code => finish(code === 0))
    setTimeout(() => { try { p.kill('SIGKILL') } catch { } finish(false) }, 15000).unref()
  })
}

let capsCache = null
async function capabilities() {
  if (capsCache && Date.now() - capsCache.at < 60_000) return capsCache.v
  const [ffmpeg, ffprobe, ytdlp, blender] = await Promise.all([
    binVersion('ffmpeg'), binVersion('ffprobe'), binVersion('yt-dlp', ['--version']), binVersion('blender', ['--version']),
  ])
  const [pyWhisper, pyEarshot] = await Promise.all([pyHasModule('faster_whisper'), pyHasModule('earshot')])
  const v = {
    name: 'anime-studio-backend',
    maxUploadMB: MAX_UPLOAD_MB,
    authRequired: true,
    ai: { ok: aiEnabled },
    projectRender: { ok: canRenderProject() && Boolean(ffmpeg) },
    ffmpeg: ffmpeg ? { ok: true, version: ffmpeg } : { ok: false },
    ffprobe: ffprobe ? { ok: true } : { ok: false },
    ytdlp: ytdlp && YTDLP_PROXY ? { ok: true, version: ytdlp } : { ok: false, hint: 'Requiere yt-dlp y un proxy de salida restringido' },
    whisper: pyWhisper ? { ok: true, engine: 'faster-whisper' } : { ok: false, hint: 'pip install faster-whisper' },
    earshot: pyEarshot ? { ok: true, engine: 'earshot VAD (pykeio)' } : { ok: false, hint: 'pip install earshot' },
    hyperframes: { ok: Boolean(loadMotionTools()) && Boolean(ffmpeg), requiresBrowser: true },
    blender: { ok: Boolean(blender) && Boolean(ffmpeg), version: blender || undefined },
  }
  capsCache = { at: Date.now(), v }
  return v
}

// ---------------------------------------------------------------------------
// Utilidades de procesos
// ---------------------------------------------------------------------------

function toolEnvironment() {
  const keys = ['PATH', 'HOME', 'LANG', 'LC_ALL', 'PYTHONPATH', 'HF_HOME', 'HF_HUB_OFFLINE',
    'HF_HUB_DISABLE_XET', 'HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'http_proxy', 'https_proxy',
    'no_proxy', 'SSL_CERT_FILE', 'REQUESTS_CA_BUNDLE', 'XDG_CACHE_HOME',
    'CHROME_PATH', 'PUPPETEER_EXECUTABLE_PATH', 'PUPPETEER_CACHE_DIR', 'NODE_PATH', 'TMPDIR']
  return { HYPERFRAMES_NO_TELEMETRY: '1', HYPERFRAMES_CACHE_DIR: path.join(OUTPUT_ROOT, '.hyperframes-cache'), ...Object.fromEntries(keys
    .filter(key => process.env[key] !== undefined).map(key => [key, process.env[key]])) }
}

function run(bin, args, { onLine, onProgress, job, timeoutMs = 30 * 60 * 1000 } = {}) {
  return new Promise((resolve, reject) => {
    checkCancelled(job || {})
    const child = spawn(bin, args, {
      cwd: job?.dir,
      env: toolEnvironment(),
      detached: process.platform !== 'win32',
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    const terminate = () => {
      try {
        if (child.pid && process.platform !== 'win32') process.kill(-child.pid, 'SIGKILL')
        else child.kill('SIGKILL')
      } catch { /* process already closed */ }
    }
    let stdout = ''
    let stderr = ''
    let failure = null
    if (job) job.onCancel = () => {
      failure = new Error('Cancelado por el usuario')
      terminate()
    }
    const timer = setTimeout(() => {
      failure = new Error(`${bin} excedió el tiempo límite`)
      terminate()
    }, timeoutMs)
    timer.unref()
    const outputLimit = 4 * 1024 * 1024
    child.stdout.on('data', d => {
      const s = d.toString()
      stdout += s
      if (stdout.length > outputLimit) {
        stdout = ''
        failure ||= new Error('El proceso excedió el límite de salida')
        terminate()
      }
      if (onProgress) onProgress(s)
    })
    child.stderr.on('data', d => {
      const s = d.toString()
      stderr = (stderr + s).slice(-outputLimit)
      if (onLine) for (const line of s.split('\n')) { if (line) onLine(line) }
    })
    child.on('error', err => {
      failure ||= err
    })
    child.on('close', code => {
      clearTimeout(timer)
      if (job) job.onCancel = null
      if (failure) return reject(failure)
      if (code === 0) resolve({ stdout, stderr })
      else {
        const tail = stderr.split('\n').filter(Boolean).slice(-4).join(' | ')
        reject(new Error(`${bin} salió con código ${code}: ${tail.replaceAll(job?.dir || '\0', '[trabajo]').slice(-800) || 'sin detalle'}`))
      }
    })
  })
}

// Restrict inputs to self-contained media containers and local files. Playlist
// demuxers (including HLS and concat) and MOV external references stay disabled.
const DEMUXERS = 'aac,aiff,avi,flac,matroska,mov,mp3,mpeg,mpegts,ogg,wav'
const localMedia = ['-protocol_whitelist', 'file', '-format_whitelist', DEMUXERS]

async function inspectMedia(job, file) {
  const { stdout } = await run('ffprobe', ['-v', 'error', ...localMedia,
    '-show_entries', 'format=duration,format_name:stream=index,codec_type,codec_name,width,height,avg_frame_rate,sample_rate,channels',
    '-of', 'json', file], { job, timeoutMs: 30_000 })
  const info = JSON.parse(stdout)
  if (!info.streams?.some(stream => ['audio', 'video'].includes(stream.codec_type))) {
    throw new Error('El archivo no contiene audio ni video compatibles')
  }
  const duration = Number(info.format?.duration)
  if (!Number.isFinite(duration) || duration <= 0 || duration > MAX_DURATION_SECONDS) {
    throw new Error(`La duración debe ser válida y no superar ${MAX_DURATION_SECONDS} segundos`)
  }
  if (info.streams.some(stream => (stream.width || 0) * (stream.height || 0) > 4096 * 2160)) {
    throw new Error('La resolución de entrada supera el límite del servidor')
  }
  return { info, duration }
}

async function addResult(job, filePath, mime, name) {
  const { size } = await fsp.stat(filePath)
  if (!size || size >= MAX_OUTPUT_MB * 1024 * 1024) throw new Error('El resultado está vacío o excede el límite de salida')
  job.files.push({ name: name || path.basename(filePath), path: filePath, mime, size })
}

/** Nombre de archivo seguro (sin traversal ni caracteres raros) */
function safeName(name) {
  const base = path.basename(String(name || 'media')).replace(/[^\w.\- ]+/g, '_').slice(0, 120)
  return base || 'media'
}

async function writeInput(job, input) {
  if (job.inputPath) return job.inputPath
  if (!input || typeof input.dataB64 !== 'string' || input.dataB64.length === 0) {
    throw new HttpError(400, 'Falta el archivo de entrada (input.dataB64)')
  }
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(input.dataB64) || input.dataB64.length % 4 !== 0) {
    throw new HttpError(400, 'Base64 inválido')
  }
  const buf = Buffer.from(input.dataB64, 'base64')
  if (buf.length === 0) throw new HttpError(400, 'Archivo de entrada vacío')
  if (buf.length > MAX_UPLOAD_BYTES) {
    throw new HttpError(413, `El archivo supera el límite de ${MAX_UPLOAD_MB} MB de este servidor`)
  }
  const inPath = path.join(job.dir, 'source.media')
  await fsp.writeFile(inPath, buf, { flag: 'wx', mode: 0o600 })
  return inPath
}

// ---------------------------------------------------------------------------
// Herramientas FFmpeg (con progreso real por -progress pipe:1)
// ---------------------------------------------------------------------------

function ffmpegProgressParser(job, totalDur) {
  let lastEmit = 0
  return chunk => {
    if (!totalDur || totalDur <= 0) return
    for (const line of chunk.split('\n')) {
      const m = line.match(/out_time_us=(\d+)/) || line.match(/out_time_ms=(\d+)/)
      if (m) {
        const p = Number(m[1]) / 1e6 / totalDur
        const now = Date.now()
        if (now - lastEmit > 300 || p >= 1) {
          lastEmit = now
          setProgress(job, Math.min(0.99, p), `Procesando ${(p * 100).toFixed(0)}%`)
        }
      }
    }
  }
}

function crfFromQuality(q) {
  // calidad: high = mejor imagen, low = archivo más chico
  return q === 'high' ? '18' : q === 'low' ? '28' : '23'
}

function numberOption(value, fallback, min, max) {
  if (value === undefined || value === '') return fallback
  const number = Number(value)
  if (!Number.isFinite(number) || number < min || number > max) {
    throw new Error(`El valor debe estar entre ${min} y ${max}`)
  }
  return number
}

function outSpec(kind, p) {
  const kbps = numberOption(p.audioKbps, 192, 32, 320)
  if (kind === 'extractAudio') {
    if (p.audioFormat === 'mp3') return { ext: 'mp3', mime: 'audio/mpeg', args: ['-vn', '-c:a', 'libmp3lame', '-b:a', `${kbps}k`] }
    return { ext: 'wav', mime: 'audio/wav', args: ['-vn', '-c:a', 'pcm_s16le'] }
  }
  if (kind === 'normalize') return { ext: 'wav', mime: 'audio/wav', args: ['-vn', '-c:a', 'pcm_s16le', '-ar', '48000'] }
  const ext = p.format || 'mp4'
  if (!['mp4', 'mov', 'webm'].includes(ext)) throw new Error('Formato no compatible')
  if (ext === 'webm') {
    if (p.codec && p.codec !== 'vp9') throw new Error('WebM requiere VP9')
    return { ext, mime: 'video/webm', args: ['-c:v', 'libvpx-vp9', '-crf', crfFromQuality(p.quality), '-b:v', '0', '-c:a', 'libopus', '-b:a', `${kbps}k`] }
  }
  if (p.codec && p.codec !== 'h264') throw new Error('MP4 y MOV requieren H.264')
  return { ext, mime: ext === 'mov' ? 'video/quicktime' : 'video/mp4',
    args: ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', crfFromQuality(p.quality),
      '-c:a', 'aac', '-b:a', `${kbps}k`, '-pix_fmt', 'yuv420p', '-movflags', '+faststart'] }
}

async function jobFfmpeg(job, p) {
  checkCancelled(job)
  const input = await writeInput(job, p.input)
  const kind = p.ffmpegKind
  const { info, duration } = await inspectMedia(job, input)
  const hasVideo = info.streams.some(stream => stream.codec_type === 'video')
  const hasAudio = info.streams.some(stream => stream.codec_type === 'audio')

  if (kind === 'probe') {
    job.result = info
    setProgress(job, 1, 'Analizado')
    return
  }

  if (['loudness', 'normalize', 'extractAudio'].includes(kind) && !hasAudio) throw new Error('El archivo no tiene audio')
  if (kind === 'loudness') {
    // Audio Lab: loudness real (EBU R128) con loudnorm print_format=json
    setProgress(job, 0.1, 'Midiendo loudness (EBU R128)…')
    const { stderr } = await run('ffmpeg', ['-hide_banner', '-nostats', ...localMedia, '-i', input, '-map', '0:a:0', '-vn', '-af', 'loudnorm=print_format=json', '-f', 'null', '-'], { job })
    const m = stderr.match(/\{[\s\S]*\}/)
    if (!m) throw new Error('ffmpeg no devolvió el reporte de loudnorm')
    const r = JSON.parse(m[0])
    job.result = {
      inputI: r.input_i, inputTp: r.input_tp, inputLra: r.input_lra, inputTh: r.input_th,
      targetI: r.target_i, targetTp: r.target_tp,
      reading: `Loudness integrado: ${r.input_i} LUFS · pico real: ${r.input_tp} dBTP · rango: ${r.input_lra} LU`,
      clippingHint: Number(r.input_tp) >= 0 ? 'El pico alcanza 0 dBTP o más. Revisá el posible recorte.' : 'El pico medido está por debajo de 0 dBTP.',
    }
    setProgress(job, 1, 'Medición lista')
    return
  }

  const spec = outSpec(kind, p)
  const out = path.join(job.dir, `resultado.${spec.ext}`)
  const audioOnly = kind === 'extractAudio' || kind === 'normalize'
  const args = ['-hide_banner', '-nostdin', '-y', ...localMedia, '-i', input,
    '-map', audioOnly ? '0:a:0' : '0:v:0?', ...(audioOnly ? [] : ['-map', '0:a:0?']),
    '-map_metadata', '-1', '-map_chapters', '-1',
    ...spec.args, '-progress', 'pipe:1', '-nostats', '-fs', String(MAX_OUTPUT_MB * 1024 * 1024)]
  const start = numberOption(p.start, 0, 0, duration)
  if (start >= duration) throw new Error('El inicio del corte queda fuera del archivo')
  const length = numberOption(p.duration, duration - start, 0.01, duration - start)
  if (start > 0 && kind !== 'normalize') args.push('-ss', String(start))
  args.push('-t', String(length))
  if (hasVideo && !audioOnly) {
    const width = Math.floor(numberOption(p.scale, 0, 0, 3840) / 2) * 2
    const fps = numberOption(p.fps, 0, 0, 120)
    args.push('-vf', width >= 2 ? `scale='trunc(min(${width},iw)/2)*2':-2` : 'pad=ceil(iw/2)*2:ceil(ih/2)*2')
    if (fps > 0) args.push('-r', String(fps))
  }
  if (kind === 'normalize') {
    const lufs = numberOption(p.lufs, -16, -30, -10)
    const filter = `atrim=start=${start}:duration=${length},asetpts=PTS-STARTPTS,loudnorm=I=${lufs}:TP=-1.5:LRA=11`
    const analysis = await run('ffmpeg', ['-hide_banner', '-nostdin', ...localMedia, '-i', input,
      '-map', '0:a:0',
      '-af', `${filter}:print_format=json`, '-f', 'null', '-'], { job })
    const measured = JSON.parse(analysis.stderr.match(/\{[^{}]*"input_i"[^{}]*\}/)?.[0] || '{}')
    if (!['input_i', 'input_tp', 'input_lra', 'input_thresh', 'target_offset'].every(key =>
      Number.isFinite(Number(measured[key])))) throw new Error('No se pudo medir el audio para normalizarlo')
    args.push('-af', `${filter}:measured_I=${measured.input_i}:measured_TP=${measured.input_tp}:measured_LRA=${measured.input_lra}:measured_thresh=${measured.input_thresh}:offset=${measured.target_offset}:linear=true`)
  }
  args.push(out)
  await run('ffmpeg', args, { job, onProgress: ffmpegProgressParser(job, length) })
  checkCancelled(job)
  await addResult(job, out, spec.mime, `resultado.${spec.ext}`)
  setProgress(job, 0.99, 'Cerrando archivo…')
}

async function jobReference(job, p) {
  const input = await writeInput(job, p.input)
  const { info, duration } = await inspectMedia(job, input)
  if (!info.streams.some(track => track.codec_type === 'video')) throw new Error('El análisis de cortes requiere video')
  const threshold = numberOption(p.threshold, 0.30, 0.05, 0.9)
  setProgress(job, 0, 'Buscando cambios de escena…')
  const { stdout } = await run('ffmpeg', ['-v', 'error', '-nostdin', ...localMedia, '-i', input,
    '-map', '0:v:0', '-an', '-sn', '-dn',
    '-vf', `fps=15,scale=320:-2,select='gte(scene,${threshold})',metadata=print:key=lavfi.scene_score:file=-`,
    '-f', 'null', '-'], { job })
  const cuts = []
  for (const match of stdout.matchAll(/pts_time:([\d.]+)\s*\r?\nlavfi\.scene_score=([\d.]+)/g)) {
    const time = Number(match[1])
    if (time > 0 && time < duration && time - (cuts.at(-1)?.time ?? 0) >= 0.13) {
      cuts.push({ time, score: Number(match[2]), label: `Corte estimado ${cuts.length + 1}` })
    }
  }
  const boundaries = [0, ...cuts.map(cut => cut.time), duration]
  const shots = boundaries.slice(1).map((end, i) => ({
    start: boundaries[i], end, duration: Math.round((end - boundaries[i]) * 1000) / 1000,
  }))
  const hasAudio = info.streams.some(track => track.codec_type === 'audio')
  setProgress(job, 0.55, 'Midiendo la actividad visual y las pausas de audio…')
  const activity = await run('ffmpeg', ['-v', 'error', '-nostdin', ...localMedia, '-i', input,
    '-map', '0:v:0', '-an', '-sn', '-dn',
    '-vf', 'fps=5,scale=160:-2,signalstats,metadata=print:key=lavfi.signalstats.YDIF:file=-',
    '-f', 'null', '-'], { job })
  const changes = [...activity.stdout.matchAll(/pts_time:([\d.]+)\s*\r?\nlavfi\.signalstats\.YDIF=([\d.]+)/g)]
    .map(match => ({ time: Number(match[1]), difference: Number(match[2]) }))
  for (const shot of shots) {
    const samples = changes.filter(sample => sample.time > shot.start + 0.2 && sample.time < shot.end)
    shot.meanLumaChange = samples.length
      ? Math.round(samples.reduce((sum, sample) => sum + sample.difference, 0) / samples.length * 100) / 100 : null
  }
  const quiet = []
  if (hasAudio) {
    const { stderr } = await run('ffmpeg', ['-hide_banner', '-nostats', '-nostdin', ...localMedia, '-i', input,
      '-map', '0:a:0', '-vn', '-af', 'silencedetect=noise=-36dB:d=0.25', '-f', 'null', '-'], { job })
    let start = null
    for (const match of stderr.matchAll(/silence_(start|end): ([\d.]+)/g)) {
      const time = Math.max(0, Math.min(duration, Number(match[2])))
      if (match[1] === 'start') start = time
      else if (start !== null) { if (time > start) quiet.push({ start, end: time }); start = null }
    }
    if (start !== null && duration > start) quiet.push({ start, end: duration })
  }
  job.result = { duration, threshold, sampleFps: 15, cuts, shots, quiet, hasAudio,
    cutsNearSoundChange: cuts.filter(cut => quiet.some(interval =>
      Math.min(Math.abs(cut.time - interval.start), Math.abs(cut.time - interval.end)) < 0.25)).length,
    meanShotSeconds: Math.round(duration / shots.length * 100) / 100 }
}

// ---------------------------------------------------------------------------
// Whisper (faster-whisper) — transcripción real a SRT/VTT + segmentos
// ---------------------------------------------------------------------------

function fmtTs(sec, sep = ',') {
  const total = Math.round(sec * 1000)
  const ms = total % 1000
  const s = Math.floor(total / 1000) % 60
  const m = Math.floor(total / 60_000) % 60
  const h = Math.floor(total / 3_600_000)
  const pad = (n, w = 2) => String(n).padStart(w, '0')
  return `${pad(h)}:${pad(m)}:${pad(s)}${sep}${pad(ms, 3)}`
}

function toSrt(segments) {
  return segments.map((sg, i) => `${i + 1}\n${fmtTs(sg.start)} --> ${fmtTs(sg.end)}\n${(sg.text || '').trim()}\n`).join('\n')
}
function toVtt(segments) {
  return `WEBVTT\n\n${segments.map(sg => `${fmtTs(sg.start, '.')} --> ${fmtTs(sg.end, '.')}\n${(sg.text || '').trim()}\n`).join('\n')}`
}

async function jobWhisper(job, p) {
  checkCancelled(job)
  const model = ['tiny', 'base', 'small'].includes(p.model) ? p.model : 'tiny'
  const input = await writeInput(job, p.input)
  const wavPath = await speechInput(job, input)
  const language = /^[a-z]{2,3}$/.test(p.language || '') ? p.language : 'auto'
  const scriptPath = path.join(job.dir, `${job.id}-whisper.py`)
  await fsp.writeFile(scriptPath, `
import json, sys, wave
import numpy as np
from faster_whisper import WhisperModel
path, model_name, lang = sys.argv[1:]
m = WhisperModel(model_name, device="cpu", compute_type="int8", cpu_threads=2)
with wave.open(path, "rb") as source:
    audio = np.frombuffer(source.readframes(source.getnframes()), dtype="<i2").astype(np.float32) / 32768
segments, info = m.transcribe(audio, language=None if lang == "auto" else lang, vad_filter=True)
out = []
for sg in segments:
    print(f"ANIME_PROGRESS={sg.end / max(info.duration, 0.001):.3f}", file=sys.stderr, flush=True)
    out.append({"start": round(sg.start, 3), "end": round(sg.end, 3), "text": sg.text})
print(json.dumps({"language": info.language, "duration": info.duration, "segments": out}, ensure_ascii=False))
`)
  setProgress(job, 0.15, `Transcribiendo con faster-whisper (${model})… puede tardar`)
  let stdout
  try {
    const r = await run('python3', [scriptPath, wavPath, model, language], {
      job,
      onLine: line => {
        const match = line.match(/^ANIME_PROGRESS=(\d+(?:\.\d+)?)$/)
        if (match) setProgress(job, Math.min(0.98, Math.max(job.progress, 0.15 + Number(match[1]) * 0.8)), 'Transcribiendo audio…')
      },
      timeoutMs: 60 * 60 * 1000,
    })
    stdout = r.stdout
  } catch (err) {
    const blob = `${err.message || ''} ${err.stderr || ''}`
    if (blob.includes('No module named')) {
      throw new Error('El servidor no tiene faster-whisper instalado (pip install faster-whisper). Nada se simuló.')
    }
    throw err
  }
  const parsed = JSON.parse(stdout)
  job.result = parsed
  const srtPath = path.join(job.dir, `${job.id}-subs.srt`)
  const vttPath = path.join(job.dir, `${job.id}-subs.vtt`)
  if (parsed.segments.length > 0) {
    await fsp.writeFile(srtPath, toSrt(parsed.segments), 'utf8')
    await addResult(job, srtPath, 'application/x-subrip', 'subtitulos.srt')
  }
  await fsp.writeFile(vttPath, toVtt(parsed.segments), 'utf8')
  await addResult(job, vttPath, 'text/vtt', 'subtitulos.vtt')
}

async function jobCaptionVideo(job, p) {
  const input = await writeInput(job, p.input)
  const { info, duration } = await inspectMedia(job, input)
  if (!info.streams.some(stream => stream.codec_type === 'video')) throw new Error('El MP4 subtitulado requiere video')
  await jobWhisper(job, p)
  const captions = job.files.find(file => file.mime === 'application/x-subrip')
  if (!captions) return
  const out = path.join(job.dir, 'video-subtitulado.mp4')
  setProgress(job, 0.95, 'Codificando el MP4 con pista de subtítulos…')
  await run('ffmpeg', ['-hide_banner', '-nostdin', '-y', ...localMedia, '-i', input, '-f', 'srt', '-i', captions.path,
    '-map', '0:v:0', '-map', '0:a:0?', '-map', '1:s:0', '-map_metadata', '-1', '-map_chapters', '-1',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22', '-pix_fmt', 'yuv420p',
    '-vf', 'pad=ceil(iw/2)*2:ceil(ih/2)*2', '-c:a', 'aac', '-b:a', '192k', '-c:s', 'mov_text',
    '-movflags', '+faststart', '-t', String(duration), '-fs', String(MAX_OUTPUT_MB * 1024 * 1024), out], { job })
  await addResult(job, out, 'video/mp4')
}

// ---------------------------------------------------------------------------
// Earshot (VAD pykeio) — segmentos de voz reales
// ---------------------------------------------------------------------------

async function speechInput(job, input) {
  await inspectMedia(job, input)
  const wav = path.join(job.dir, 'voice.wav')
  await run('ffmpeg', ['-v', 'error', '-nostdin', '-y', ...localMedia, '-i', input,
    '-map', '0:a:0', '-vn', '-t', String(MAX_DURATION_SECONDS), '-ac', '1', '-ar', '16000',
    '-c:a', 'pcm_s16le', wav], { job })
  return wav
}

async function jobEarshot(job, p) {
  const wavPath = await speechInput(job, await writeInput(job, p.input))
  const scriptPath = path.join(job.dir, `${job.id}-vad.py`)
  await fsp.writeFile(scriptPath, `
import json, struct, sys, wave
from earshot import Detector

detector = Detector()
segments = []
start = None
peak = 0.0
t = 0.0
with wave.open(sys.argv[1], 'rb') as source:
    for index in range(0, source.getnframes(), 256):
        raw = source.readframes(256)
        t = index / 16000
        frame = raw.ljust(512, b'\\x00')
        score = detector.predict_i16(struct.unpack('<256h', frame))
        if score >= (0.45 if start is not None else 0.60):
            if start is None:
                start, peak = t, 0.0
            peak = max(peak, score)
        elif start is not None:
            if t - start >= 0.12:
                segments.append({"start": round(start, 3), "end": round(t, 3), "peakScore": round(peak, 3)})
            start = None
    duration = source.getnframes() / 16000
if start is not None and duration - start >= 0.12:
    segments.append({"start": round(start, 3), "end": round(duration, 3), "peakScore": round(peak, 3)})
print(json.dumps({"segments": segments, "sampleRate": 16000}))
`)
  setProgress(job, 0.3, 'Detectando voz con Earshot…')
  try {
    const { stdout } = await run('python3', [scriptPath, wavPath], { job, timeoutMs: 20 * 60 * 1000 })
    job.result = JSON.parse(stdout)
    setProgress(job, 1, 'Segmentos de voz listos')
  } catch (err) {
    if (`${err.message || ''}${err.stderr || ''}`.includes('No module named')) {
      throw new Error('El servidor no tiene earshot instalado (pip install earshot). Nada se simuló.')
    }
    throw err
  }
}

// ---------------------------------------------------------------------------
// yt-dlp — SOLO contenido para el que el usuario tiene autorización
// ---------------------------------------------------------------------------

async function jobYtdlp(job, p) {
  checkCancelled(job)
  if (!YTDLP_PROXY) throw new Error('Importación por URL desactivada. Usá un archivo local.')
  const parsed = parseReference(p.url)
  const url = parsed.href
  if (p.mode !== 'info' && p.authorized !== true) throw new Error('Confirmá que tenés autorización de descarga')
  const common = ['--ignore-config', '--no-plugin-dirs', '--proxy', YTDLP_PROXY, '--no-playlist', '--no-warnings', '--use-extractors', 'youtube']

  const mode = p.mode

  if (mode === 'info') {
    setProgress(job, 0.2, 'Consultando información…')
    try {
      const { stdout } = await run('yt-dlp', [...common, '--dump-single-json', '--skip-download', '--', url], { job, timeoutMs: 120_000 })
      const info = JSON.parse(stdout)
      job.result = {
        title: info.title, duration: info.duration, uploader: info.uploader,
        webpage_url: url, isLive: !!info.is_live, availability: info.availability || 'unknown',
        notice: 'Importá solo contenido propio o autorizado. Si la plataforma no permite descarga, el intento falla de forma explícita.',
      }
      setProgress(job, 1, 'Info lista')
      return
    } catch (err) {
      throw new Error(`yt-dlp no pudo consultar la URL. Podés importar un archivo local. ${String(err.message).slice(0, 160)}`)
    }
  }

  const h = [240, 360, 480, 720, 1080].includes(Number(p.maxHeight)) ? Number(p.maxHeight) : 720
  setProgress(job, 0.1, `Descargando (≤${h}p)…`)
  const out = path.join(job.dir, `${job.id}-dl.%(ext)s`)
  await run('yt-dlp', [
    ...common, '--max-filesize', `${MAX_UPLOAD_MB}M`, '--match-filter',
    `duration <= ${MAX_DURATION_SECONDS} & !is_live & availability = public`, '-f', `bv*[height<=${h}][ext=mp4]+ba/b[height<=${h}]`,
    '--merge-output-format', 'mp4', '--newline', '--progress', '-o', out, '--', url,
  ], {
    job,
    onLine: line => {
      const m = line.match(/(\d{1,3})\.(\d)%/)
      if (m) setProgress(job, Number(m[1]) / 100 + Number(m[2]) / 1000, `Descargando ${m[1]}.${m[2]}%`)
    },
    timeoutMs: 45 * 60 * 1000,
  })
  const base = `${job.id}-dl`
  const files = await fsp.readdir(job.dir)
  const produced = files.filter(file => new RegExp(`^${base}\\.(mp4|webm|mkv)$`).test(file))
  if (produced.length === 0) throw new Error('La descarga no produjo archivos (la plataforma puede no permitir descargas).')
  for (const f of produced) {
    const media = path.join(job.dir, f)
    await inspectMedia(job, media)
    const ext = path.extname(f)
    const mime = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.mkv': 'video/x-matroska' }[ext]
    await addResult(job, media, mime, `referencia${ext}`)
  }
}

async function jobProject(job) {
  if (!canRenderProject()) throw new Error('El worker de render necesita el build estático y Chromium')
  setProgress(job, 0, 'Renderizando el timeline con el motor de Anime Studio…')
  let remainder = ''
  await run(process.execPath, [path.join(__dirname, 'project-worker.js'), job.dir, job.inputPath,
    RENDER_ROOT, RENDER_PREFIX, String(MAX_OUTPUT_MB * 1024 * 1024)], {
    job, timeoutMs: 20 * 60_000,
    onProgress: chunk => {
      const lines = (remainder + chunk).split('\n')
      remainder = lines.pop()
      for (const line of lines) {
        if (!line.startsWith('TIMELINE=')) continue
        try {
          const { progress } = JSON.parse(line.slice(9))
          if (Number.isFinite(progress)) setProgress(job, Math.min(0.85, Math.max(job.progress, progress * 0.85)))
        } catch { /* Ignore a malformed progress line */ }
      }
    },
  })
  const settings = JSON.parse(await fsp.readFile(path.join(job.dir, 'settings.json'), 'utf8'))
  const source = path.join(job.dir, 'render-media.bin')
  const { info, duration } = await inspectMedia(job, source)
  const audio = path.join(job.dir, 'render-audio.wav')
  const sidecar = fs.existsSync(audio)
  const spec = outSpec('convert', settings)
  const out = path.join(job.dir, `proyecto.${spec.ext}`)
  setProgress(job, 0.85, 'Codificando el archivo final con FFmpeg…')
  await run('ffmpeg', ['-hide_banner', '-nostdin', '-y', ...localMedia, '-i', source,
    ...(sidecar ? [...localMedia, '-i', audio] : []), '-map', '0:v:0', '-map', sidecar ? '1:a:0' : '0:a:0?',
    ...spec.args, '-r', String(settings.fps), '-t', String(duration),
    '-fs', String(MAX_OUTPUT_MB * 1024 * 1024), '-progress', 'pipe:1', '-nostats', out], { job })
  const checked = await inspectMedia(job, out)
  await addResult(job, out, spec.mime)
  job.result = { ...settings, duration: checked.duration,
    audio: sidecar || info.streams.some(stream => stream.codec_type === 'audio') }
}

// ---------------------------------------------------------------------------
// Dispatcher de trabajos
// ---------------------------------------------------------------------------

async function runJob(job) {
  const p = job.payload || {}
  switch (job.type) {
    case 'project.render':
      return jobProject(job)
    case 'ai.plan':
      setProgress(job, 0, 'Preparando un plan con el proveedor de IA…')
      job.result = await planProduction(job, p)
      return
    case 'scene.render': {
      setProgress(job, 0, 'Renderizando escena en Blender…')
      const output = await renderScene(job, p.scene, run, (chunk, frames) => {
        for (const match of chunk.matchAll(/Fra:(\d+)\b/g)) {
          const completed = Math.max(0, Number(match[1]) - 1)
          setProgress(job, Math.min(0.98, Math.max(job.progress, completed / frames)),
            `Blender · fotograma ${Math.min(frames, completed + 1)} de ${frames}`)
        }
      }, p.modelPath)
      await inspectMedia(job, output.video)
      await addResult(job, output.video, 'video/mp4')
      await addResult(job, output.blend, 'application/octet-stream')
      if (output.sequence) await addResult(job, output.sequence, 'application/zip')
      await addResult(job, output.config, 'application/json')
      job.result = output.result
      return
    }
    case 'motion.render': {
      setProgress(job, 0, 'Renderizando composición con HyperFrames…')
      const output = await renderMotion(job, p.scene, run)
      await inspectMedia(job, output.video)
      await addResult(job, output.video, output.mime)
      await addResult(job, output.source, 'text/html')
      await addResult(job, output.json, 'application/json')
      job.result = output.result
      return
    }
    case 'media.convert':
      return jobFfmpeg(job, { ...p, ffmpegKind: 'convert' })
    case 'media.compress':
      return jobFfmpeg(job, { ...p, ffmpegKind: 'compress' })
    case 'media.extractAudio':
      return jobFfmpeg(job, { ...p, ffmpegKind: 'extractAudio' })
    case 'media.probe':
      return jobFfmpeg(job, { ...p, ffmpegKind: 'probe' })
    case 'media.normalize':
      return jobFfmpeg(job, { ...p, ffmpegKind: 'normalize' })
    case 'media.loudness':
      return jobFfmpeg(job, { ...p, ffmpegKind: 'loudness' })
    case 'media.reference':
      return jobReference(job, p)
    case 'media.captionVideo':
      return jobCaptionVideo(job, p)
    case 'media.transcribe':
      return jobWhisper(job, p)
    case 'media.vad':
      return jobEarshot(job, p)
    case 'media.importUrl':
      return jobYtdlp(job, p)
    default:
      throw new Error(`Tipo de trabajo desconocido: ${job.type}`)
  }
}

// ---------------------------------------------------------------------------
// HTTP (sin dependencias)
// ---------------------------------------------------------------------------

function parseReference(value) {
  let url
  try { url = new URL(value) } catch { throw new HttpError(400, 'URL inválida') }
  if (url.protocol !== 'https:' || url.username || url.password || url.port ||
      url.hostname !== 'www.youtube.com' || url.pathname !== '/watch' ||
      !/^[A-Za-z0-9_-]{11}$/.test(url.searchParams.get('v') || '')) {
    throw new HttpError(400, 'URL no compatible. Importá un archivo local.')
  }
  return new URL(`https://www.youtube.com/watch?v=${url.searchParams.get('v')}`)
}

function setCORS(req, res) {
  const origin = req.headers.origin || ''
  if (ORIGINS.has(origin)) res.setHeader('Access-Control-Allow-Origin', origin)
  res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition')
  res.setHeader('Vary', 'Origin')
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization')
  res.setHeader('Access-Control-Max-Age', '86400')
}

function authenticatedOwner(req) {
  const header = req.headers.authorization || ''
  if (!/^Bearer [A-Za-z0-9_-]{32,128}$/.test(header)) return null
  const hash = tokenHash(header.slice(7))
  let owner = null
  for (const [name, expected] of TOKEN_HASHES) {
    if (crypto.timingSafeEqual(hash, expected)) owner = name
  }
  return owner
}

class HttpError extends Error {
  constructor(status, message) {
    super(message)
    this.status = status
  }
}

function sendJSON(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(obj))
}

async function* boundedBody(req, cap) {
  if (Number(req.headers['content-length']) > cap) throw new HttpError(413, 'Cuerpo demasiado grande')
  let size = 0
  for await (const chunk of req.iterator({ destroyOnReturn: false })) {
    size += chunk.length
    if (size > cap) throw new HttpError(413, 'Cuerpo demasiado grande')
    yield chunk
  }
  if (!size) throw new HttpError(400, 'El cuerpo está vacío')
}

const UPLOAD_TYPES = new Set(['media.convert', 'media.compress', 'media.extractAudio',
  'media.probe', 'media.loudness', 'media.normalize', 'media.reference', 'media.transcribe', 'media.captionVideo', 'media.vad', 'project.render'])
const JOB_TYPES = new Set([...UPLOAD_TYPES, 'media.importUrl', 'motion.render', 'scene.render', 'ai.plan'])
const reservations = new Map()

async function acceptJob(req, url, owner) {
  const admitted = [...jobs.values()].filter(job => job.owner === owner).length
  const uploading = reservations.get(owner) || 0
  const totalUploads = [...reservations.values()].reduce((sum, count) => sum + count, 0)
  if (admitted + uploading >= MAX_PER_USER || jobs.size + totalUploads >= MAX_JOBS) {
    throw new HttpError(429, 'Límite de trabajos alcanzado. Eliminá resultados terminados para continuar.')
  }
  const id = crypto.randomBytes(16).toString('hex')
  const dir = path.join(OUTPUT_ROOT, id)
  reservations.set(owner, uploading + 1)
  try {
    await fsp.mkdir(dir, { mode: 0o700 })
    const contentType = (req.headers['content-type'] || '').split(';')[0].trim()
    let body
    let inputPath
    if (contentType === 'application/octet-stream') {
      body = Object.fromEntries(url.searchParams)
      if (body.type === 'project.render' && !canRenderProject()) throw new HttpError(503, 'Render remoto no configurado')
      if (!UPLOAD_TYPES.has(body.type)) throw new HttpError(400, 'Tipo de trabajo inválido para una subida')
      inputPath = path.join(dir, 'source.media')
      const handle = await fsp.open(inputPath, 'wx', 0o600)
      try {
        for await (const chunk of boundedBody(req, MAX_UPLOAD_BYTES)) await handle.writeFile(chunk)
      } finally { await handle.close() }
    } else if (contentType === 'application/json') {
      const chunks = []
      for await (const chunk of boundedBody(req, Math.ceil(MAX_UPLOAD_BYTES * 4 / 3) + 4096)) chunks.push(chunk)
      try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')) }
      catch { throw new HttpError(400, 'JSON inválido') }
    } else {
      throw new HttpError(415, 'Usá JSON o application/octet-stream')
    }
    if (!body || !JOB_TYPES.has(body.type)) throw new HttpError(400, 'Tipo de trabajo desconocido')
    const label = typeof body.label === 'string' ? safeName(body.label) : body.type
    let payload = body
    if (body.type === 'media.importUrl') {
      if (!['info', 'download'].includes(body.mode)) throw new HttpError(400, 'Indicá si querés consultar o descargar')
      if (!YTDLP_PROXY) throw new HttpError(503, 'Importación por URL desactivada. Usá un archivo local.')
      parseReference(body.url)
      if (body.mode !== 'info' && body.authorized !== true) throw new HttpError(400, 'Confirmá el permiso de descarga')
    } else if (body.type === 'ai.plan') {
      if (!aiEnabled) throw new HttpError(503, 'El proveedor de AI Studio todavía no está configurado')
    } else if (body.type === 'motion.render' || body.type === 'scene.render') {
      try {
        if (body.type === 'motion.render') validateMotion(body.scene)
        else {
          validateScene(body.scene, body.model !== undefined)
          const modelPath = body.model === undefined ? undefined : await stageModel(dir, body.model)
          payload = { scene: body.scene, modelPath }
        }
      } catch (error) { throw new HttpError(400, error.message) }
    } else if (body.type === 'project.render' && !inputPath) {
      throw new HttpError(415, 'El proyecto requiere un paquete binario')
    } else if (!inputPath) {
      inputPath = await writeInput({ dir }, body.input)
      const { input, ...params } = body
      payload = params
    }
    const job = newJob(id, owner, body.type, label)
    job.inputPath = inputPath
    job.payload = payload
    enqueue(job)
    return job
  } catch (error) {
    await cleanup({ dir })
    throw error
  } finally {
    const count = reservations.get(owner)
    if (count === 1) reservations.delete(owner)
    else reservations.set(owner, count - 1)
  }
}

function publicJob(job) {
  return {
    id: job.id, type: job.type, label: job.label, state: job.state,
    progress: job.progress, message: job.message, createdAt: job.createdAt,
    files: job.files.map(f => ({ name: f.name, mime: f.mime, size: f.size })),
    result: job.result, error: job.error,
  }
}

const server = http.createServer({ requestTimeout: 180_000 }, async (req, res) => {
  setCORS(req, res)
  res.setHeader('Cache-Control', 'no-store')
  res.setHeader('X-Content-Type-Options', 'nosniff')
  try {
    const url = new URL(req.url, 'http://localhost')
    if (req.headers.origin && !ORIGINS.has(req.headers.origin)) {
      throw new HttpError(403, 'Origen no autorizado')
    }
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return }
    if (url.pathname === '/api/health' && req.method === 'GET') {
      return sendJSON(res, 200, { ok: true, name: 'anime-studio-backend' })
    }

    const owner = authenticatedOwner(req)
    if (!owner) throw new HttpError(401, 'Token incorrecto o ausente')
    if (url.pathname === '/api/capabilities' && req.method === 'GET') {
      return sendJSON(res, 200, await capabilities())
    }
    if (url.pathname === '/api/jobs' && req.method === 'POST') {
      const job = await acceptJob(req, url, owner)
      return sendJSON(res, 202, { id: job.id, state: job.state })
    }
    if (url.pathname === '/api/jobs' && req.method === 'GET') {
      return sendJSON(res, 200, { jobs: [...jobs.values()].filter(job => job.owner === owner).map(publicJob) })
    }

    const route = url.pathname.match(/^\/api\/jobs\/([a-f0-9]{32})(?:\/files\/(\d+))?$/)
    const job = route && jobs.get(route[1])
    if (!job || job.owner !== owner) throw new HttpError(404, 'Trabajo no encontrado')
    if (route[2] !== undefined && req.method === 'GET') {
      const file = job.state === 'done' && job.files[Number(route[2])]
      if (!file) throw new HttpError(404, 'Archivo no encontrado')
      const handle = await fsp.open(file.path, 'r').catch(() => {
        throw new HttpError(404, 'Archivo no encontrado')
      })
      res.writeHead(200, {
        'Content-Type': file.mime,
        'Content-Length': file.size,
        'Content-Disposition': `attachment; filename="${encodeURIComponent(file.name)}"`,
      })
      await pipeline(handle.createReadStream(), res)
      return
    }
    if (route[2] === undefined && req.method === 'GET') return sendJSON(res, 200, publicJob(job))
    if (route[2] === undefined && req.method === 'DELETE') {
      if (job.state === 'queued') {
        queue.splice(queue.indexOf(job), 1)
        jobs.delete(job.id)
        await cleanup(job)
      } else if (job.state === 'running') {
        job.cancelRequested = true
        setJobState(job, 'cancelled', 'Cancelado')
        job.onCancel?.()
      } else if (job.expiresAt !== null) {
        jobs.delete(job.id)
        await cleanup(job)
      }
      return sendJSON(res, 200, { ok: true, state: 'cancelled' })
    }
    throw new HttpError(404, 'Ruta desconocida')
  } catch (error) {
    if (res.destroyed || res.headersSent) return
    if (!req.complete) res.setHeader('Connection', 'close')
    if (error instanceof HttpError) return sendJSON(res, error.status, { error: error.message })
    console.error(error)
    return sendJSON(res, 500, { error: 'Error interno de procesamiento' })
  }
})

fs.mkdirSync(OUTPUT_ROOT, { recursive: true, mode: 0o700 })
server.listen(PORT, () => console.log(`ANIME STUDIO backend en puerto ${server.address().port}`))
