'use strict'

const { validateMotion } = require('./motion')
const { validateScene } = require('./scene3d')

const MODEL = process.env.AI_MODEL || ''
const ENDPOINT = process.env.AI_CHAT_URL ? new URL(process.env.AI_CHAT_URL) : null
const API_KEY = process.env.AI_SERVER_KEY || ''
if (ENDPOINT && ENDPOINT.protocol !== 'https:' && ENDPOINT.protocol !== 'http:') {
  throw new Error('AI_CHAT_URL requiere una URL HTTP(S) controlada por el operador')
}

const MEDIA_JOBS = new Set(['media.transcribe', 'media.captionVideo', 'media.reference', 'media.loudness',
  'media.normalize', 'media.vad', 'media.convert', 'media.extractAudio'])
const SYSTEM_PROMPT = `Sos el asistente de producción de Anime Studio. Respondé un solo objeto JSON con
{ "type": "nombre del trabajo o null", "options": {}, "explanation": "paso que verá el usuario", "placement": "manual" }.
Elegí un trabajo real de esta lista con sus opciones. Si no hay una herramienta adecuada,
usá type null y explicá qué falta. Nunca afirmes que algo ya se ejecutó.
Media (requiere hasMedia:true):
media.transcribe {language?:'es'|'en'|'ja'}; media.captionVideo misma opción, crea MP4 con pista de subtítulos;
media.reference {threshold?: número 0.05 a 0.9} estima cortes; media.loudness mide picos y LUFS;
media.normalize {lufs?: número -30 a -10}; media.vad detecta voz;
media.convert {format?:'mp4'|'mov'|'webm',scale?:ancho máximo,fps?:número,quality?:'high'|'medium'|'low',start?:segundos,duration?:segundos};
media.extractAudio {audioFormat?:'wav'|'mp3'}.
Creación sin archivos:
motion.render {scene:{duration:0.5–10,width:128–1280,height:128–1280,fps:24|25|30|50|60,background:"#rrggbb",transparent?:bool,
layers:[{kind:"text"|"circle"|"rectangle",text, color:"#rrggbb",size:4–500,
frames:[{time:segundos,x:porcentaje,y:porcentaje,scale,rotation:grados,opacity:0–1,ease:"none"|"power2.out"|"power2.in"|"power2.inOut"}]}]}}.
Usá 1–20 capas. Primer keyframe de cada capa en 0 y demás en orden creciente. Se pueden animar títulos, transiciones y partículas con capas.
scene.render {scene:{duration:0.25–8,width:par128–1280,height:par128–1280,fps:12|24|30,world:[r,g,b],
objects:[{kind:"cube"|"sphere"|"plane"|"cylinder"|"cone",position:[x,y,z],scale:[x,y,z],rotation:[x,y,z],color:[r,g,b],emission:0–8}],
camera:{from:{position:[x,y,z],target:[x,y,z]},to:{position:[x,y,z],target:[x,y,z]},lens:15–100},
lights:[{position:[x,y,z],target:[x,y,z],power:0–10000,color:[r,g,b]}]}}.
En 3D usá hasta 64 objetos y 8 luces, RGB de 0 a 1. Se generará un archivo que el usuario podrá insertar.
Si el usuario pide editar efectos nativos, modelos externos o un personaje existente, ofrece el asistente de edición
del timeline sin inventar que creaste un trabajo. Usá placement "end" solo si se pide agregar un render al final
del timeline. Jamás pidas ni incluyas contraseñas, URLs, rutas, HTML ni scripts.`

const PLAN_SCHEMA = {
  type: 'object',
  properties: {
    type: { enum: [...MEDIA_JOBS, 'motion.render', 'scene.render', null] },
    options: { type: 'object', additionalProperties: true },
    explanation: { type: 'string' },
    placement: { enum: ['manual', 'end'] },
  },
  required: ['type', 'options', 'explanation', 'placement'],
  additionalProperties: false,
}

const OPTION_FIELDS = {
  'media.transcribe': ['language'],
  'media.captionVideo': ['language'],
  'media.reference': ['threshold'],
  'media.normalize': ['lufs'],
  'media.convert': ['format', 'scale', 'fps', 'quality', 'start', 'duration'],
  'media.extractAudio': ['audioFormat'],
}

function validatePlan(plan, hasMedia) {
  if (!plan || typeof plan.explanation !== 'string' || !plan.explanation.trim()) {
    throw new Error('La IA devolvió un plan sin explicación')
  }
  const explanation = plan.explanation.trim().slice(0, 600)
  if (plan.type === null) return { type: null, explanation }
  if (MEDIA_JOBS.has(plan.type)) {
    if (!hasMedia) return { type: null, explanation: 'Elegí el medio de origen antes de pedir un trabajo audiovisual.' }
    const options = Object.fromEntries((OPTION_FIELDS[plan.type] || []).flatMap(key => {
      const value = plan.options?.[key]
      return typeof value === 'number' && Number.isFinite(value) || typeof value === 'string' && value.length <= 20
        ? [[key, value]] : []
    }))
    return { type: plan.type, options, explanation }
  }
  const validators = { 'motion.render': validateMotion, 'scene.render': validateScene }
  if (!Object.hasOwn(validators, plan.type)) throw new Error('La IA eligió una herramienta fuera de Studio')
  validators[plan.type](plan.options?.scene)
  return { type: plan.type, options: { scene: plan.options.scene }, explanation,
    placement: plan.placement === 'end' ? 'end' : 'manual' }
}

async function planProduction(job, payload) {
  if (!ENDPOINT || !MODEL) throw new Error('Configurá AI_CHAT_URL y AI_MODEL en el servidor')
  if (typeof payload.prompt !== 'string' || !payload.prompt.trim() || payload.prompt.length > 1400) {
    throw new Error('Ingresá una instrucción de hasta 1400 caracteres')
  }
  const controller = new AbortController()
  job.onCancel = () => controller.abort()
  const hasMedia = payload.hasMedia === true
  try {
    const headers = { 'Content-Type': 'application/json' }
    if (API_KEY) headers.Authorization = `Bearer ${API_KEY}`
    const response = await fetch(ENDPOINT, {
      method: 'POST', headers, redirect: 'error',
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(120_000)]),
      body: JSON.stringify({
        model: MODEL, stream: false, temperature: 0, max_tokens: 2800,
        response_format: { type: 'json_schema', json_schema: { name: 'anime_studio_plan', schema: PLAN_SCHEMA } },
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: '{"instruction":"Pasá mi video en japonés a un MP4 con subtítulos.","hasMedia":true}' },
          { role: 'assistant', content: '{"type":"media.captionVideo","options":{"language":"ja"},"explanation":"Transcribiré los diálogos y exportaré un MP4 con una pista de subtítulos.","placement":"manual"}' },
          { role: 'user', content: JSON.stringify({ instruction: payload.prompt, hasMedia }) },
        ],
      }),
    })
    if (!response.ok || !response.body) throw new Error(`El proveedor de IA respondió HTTP ${response.status}`)
    const chunks = []
    let size = 0
    for await (const chunk of response.body) {
      size += chunk.length
      if (size > 100_000) throw new Error('El proveedor superó el límite de respuesta')
      chunks.push(chunk)
    }
    try {
      const body = JSON.parse(Buffer.concat(chunks).toString('utf8'))
      return validatePlan(JSON.parse(body.choices?.[0]?.message?.content), hasMedia)
    } catch (error) {
      throw new Error(error instanceof SyntaxError ? 'La IA no devolvió JSON válido' : error.message)
    }
  } finally {
    job.onCancel = null
  }
}

module.exports = { aiEnabled: Boolean(ENDPOINT && MODEL), planProduction, validatePlan }
