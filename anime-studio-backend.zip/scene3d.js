'use strict'

const path = require('node:path')
const fs = require('node:fs/promises')

function numeric(value, min, max, label) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) {
    throw new Error(`${label} debe estar entre ${min} y ${max}`)
  }
  return value
}

function vector(value, min, max, label) {
  if (!Array.isArray(value) || value.length !== 3) throw new Error(`${label} requiere tres coordenadas`)
  return value.map(n => numeric(n, min, max, label))
}

function pose(value) {
  if (!value || typeof value !== 'object') throw new Error('Falta una pose de cámara')
  const position = vector(value.position, -100, 100, 'Posición de cámara')
  const target = vector(value.target, -100, 100, 'Objetivo de cámara')
  if (Math.hypot(...position.map((coordinate, i) => coordinate - target[i])) < 0.01) {
    throw new Error('La cámara y su objetivo necesitan posiciones distintas')
  }
  return { position, target }
}

async function stageModel(dir, input) {
  if (typeof input !== 'string' || input.length > Math.ceil(8 * 1024 * 1024 * 4 / 3) + 4 ||
      input.length % 4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(input)) {
    throw new Error('El modelo GLB debe pesar hasta 8 MB')
  }
  const model = Buffer.from(input, 'base64')
  if (model.length < 28 || model.length > 8 * 1024 * 1024 || model.toString('ascii', 0, 4) !== 'glTF' ||
      model.readUInt32LE(4) !== 2 || model.readUInt32LE(8) !== model.length) throw new Error('El archivo no es un GLB 2.0 válido')
  const length = model.readUInt32LE(12)
  const next = 20 + length
  if (length > 1_000_000 || next + 8 >= model.length || model.toString('ascii', 16, 20) !== 'JSON' ||
      model.readUInt32LE(next) + next + 8 !== model.length || model.readUInt32LE(next + 4) !== 0x004e4942) {
    throw new Error('El GLB debe contener una escena JSON y un bloque binario integrado')
  }
  const doc = JSON.parse(model.toString('utf8', 20, next))
  if (doc.buffers?.length !== 1 || doc.buffers[0].uri !== undefined ||
      (doc.images ?? []).some(image => image.uri !== undefined || !Number.isInteger(image.bufferView)) ||
      (doc.nodes ?? []).length > 256 || (doc.meshes ?? []).length > 64 ||
      (doc.accessors ?? []).length > 256 || (doc.accessors ?? []).some(accessor => accessor.count > 500_000)) {
    throw new Error('El GLB debe ser autónomo y ajustarse a los límites de geometría')
  }
  const filename = path.join(dir, 'model.glb')
  await fs.writeFile(filename, model, { flag: 'wx', mode: 0o600 })
  return filename
}

function validateScene(value, hasModel = false) {
  if (!value || !Array.isArray(value.objects) || (!hasModel && !value.objects.length) || value.objects.length > 64) {
    throw new Error('La escena necesita entre 1 y 64 objetos')
  }
  const duration = numeric(value.duration ?? 2, 0.25, 8, 'Duración')
  const fps = value.fps ?? 24
  if (![12, 24, 30].includes(fps)) throw new Error('FPS no compatible')
  const width = numeric(value.width ?? 640, 128, 1280, 'Ancho')
  const height = numeric(value.height ?? 360, 128, 1280, 'Alto')
  if (![width, height].every(n => Number.isInteger(n) && n % 2 === 0)) throw new Error('La resolución necesita dimensiones pares')
  const objects = value.objects.map(obj => {
    if (!obj || !['cube', 'sphere', 'plane', 'cylinder', 'cone'].includes(obj.kind)) throw new Error('Objeto 3D no compatible')
    return {
      kind: obj.kind, position: vector(obj.position ?? [0, 0, 0], -100, 100, 'Posición'),
      scale: vector(obj.scale ?? [1, 1, 1], 0.01, 30, 'Escala'),
      rotation: vector(obj.rotation ?? [0, 0, 0], -360, 360, 'Rotación'),
      color: vector(obj.color ?? [0.65, 0.2, 0.5], 0, 1, 'Color'),
      emission: numeric(obj.emission ?? 0, 0, 8, 'Emisión'),
    }
  })
  const camera = value.camera ?? { from: { position: [6, -8, 5], target: [0, 0, 0] } }
  const from = pose(camera.from)
  const to = pose(camera.to ?? camera.from)
  const lights = value.lights ?? [{ position: [3, -4, 7], power: 900 }]
  if (!Array.isArray(lights) || lights.length > 8) throw new Error('Se permiten hasta 8 luces')
  const frames = Math.max(2, Math.round(duration * fps))
  const sequence = value.sequence === true
  if (sequence && width * height * frames > 30_000_000) {
    throw new Error('Reducí la resolución o la duración para exportar una secuencia PNG')
  }
  return {
    width, height, fps, duration, frames, sequence, objects,
    camera: { from, to, lens: numeric(camera.lens ?? 40, 15, 100, 'Distancia focal') },
    lights: lights.map(light => {
      if (!light || typeof light !== 'object') throw new Error('Luz inválida')
      const aiming = pose({ position: light.position, target: light.target ?? [0, 0, 0] })
      return { ...aiming, color: vector(light.color ?? [1, 1, 1], 0, 1, 'Color de luz'),
        power: numeric(light.power ?? 900, 0, 10_000, 'Potencia de luz') }
    }),
    world: vector(value.world ?? [0.12, 0.12, 0.18], 0, 1, 'Color de fondo'),
  }
}

async function renderScene(job, value, run, onLine, modelPath) {
  const spec = validateScene(value, Boolean(modelPath))
  const config = path.join(job.dir, 'scene.json')
  const blend = path.join(job.dir, 'scene.blend')
  const video = path.join(job.dir, 'scene.mp4')
  await fs.writeFile(config, JSON.stringify(spec))
  await run('blender', ['--background', '--factory-startup', '--disable-autoexec', '--threads', '2',
    '--python-exit-code', '1', '--python', path.join(__dirname, 'render-scene.py'), '--', config, blend, video, modelPath ?? ''],
  { job, timeoutMs: 15 * 60_000, onProgress: chunk => onLine(chunk, spec.frames) })
  let sequence
  if (spec.sequence) {
    const frameDir = path.join(job.dir, 'frames')
    sequence = path.join(job.dir, 'fotogramas.zip')
    await run('ffmpeg', ['-v', 'error', '-nostdin', '-framerate', String(spec.fps), '-start_number', '1',
      '-i', path.join(frameDir, 'frame-%04d.png'), '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
      '-movflags', '+faststart', video], { job })
  }
  return { blend, video, config, sequence, result: { width: spec.width, height: spec.height, fps: spec.fps, duration: spec.frames / spec.fps } }
}

module.exports = { renderScene, stageModel, validateScene }
