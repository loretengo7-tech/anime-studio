(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,91407,34093,54449,86250,76519,e=>{"use strict";function t(e,t){let a=e.shapeKeyframes;if(!a||0===a.length||!e.points||0===e.points.length)return e.points??[];let i=[...a].sort((e,t)=>e.time-t.time),r=i[0],o=i[i.length-1];if(t<=r.time)return r.points;if(t>=o.time)return o.points;for(let e=0;e<i.length-1;e++){let a=i[e],r=i[e+1];if(t>=a.time&&t<=r.time){let e=(t-a.time)/Math.max(1e-6,r.time-a.time),i=a.points,o=r.points,s=Math.min(i.length,o.length),l=[];for(let t=0;t<s;t++){let r=i[t]??a.points[t],s=o[t]??a.points[t];r&&s&&l.push({x:r.x+(s.x-r.x)*e,y:r.y+(s.y-r.y)*e,hIn:r.hIn&&s.hIn?{x:r.hIn.x+(s.hIn.x-r.hIn.x)*e,y:r.hIn.y+(s.hIn.y-r.hIn.y)*e}:void 0,hOut:r.hOut&&s.hOut?{x:r.hOut.x+(s.hOut.x-r.hOut.x)*e,y:r.hOut.y+(s.hOut.y-r.hOut.y)*e}:void 0})}return l}}return e.points}let a=0;function i(e="id"){return a+=1,`${e}_${Date.now().toString(36)}${a.toString(36)}${Math.random().toString(36).slice(2,7)}`}function r(e="Untitled Project"){let t=Date.now();return{id:i("proj"),name:e,createdAt:t,updatedAt:t,composition:{width:1920,height:1080,fps:30,duration:30,background:"#000000"},tracks:[{id:"track_text",kind:"text",name:"Text",locked:!1,visible:!0,muted:!1,height:44},{id:"track_v2",kind:"video",name:"Video 2",locked:!1,visible:!0,muted:!1,height:64},{id:"track_v1",kind:"video",name:"Video 1",locked:!1,visible:!0,muted:!1,height:64},{id:"track_adj",kind:"adjustment",name:"Adjustment",locked:!1,visible:!0,muted:!1,height:36},{id:"track_a1",kind:"audio",name:"Audio 1",locked:!1,visible:!0,muted:!1,height:56}],clips:[],assets:[],markers:[],beats:[],bpm:0,aiHistory:[],version:1}}function o(e){let t=e.composition.duration;for(let a of e.clips)t=Math.max(t,a.start+a.duration);return t}function s(e,t,a,r){return{id:i("clip"),trackId:e,name:t,start:a,duration:r,effects:[],blendMode:"normal",x:0,y:0,z:0,scale:1,rotation:0,opacity:1,anchorX:0,anchorY:0,keyframes:[],mask:null,speed:1,timeRemap:null,reverse:!1,parentId:null,threeD:!1,trackMatte:null}}function l(e,t,a,i="#ffffff"){return{...s(e,"Solid",t,a),kind:"solid",color:i}}function n(e,t,a,i,r){let o=Math.round(.4*i),l=Math.round(.4*r);return{...s(e,"Shape",t,a),kind:"shape",shape:{type:"rect",width:o,height:l,fill:"#f5f5f4",stroke:"#a1a1aa",strokeWidth:0,cornerRadius:0}}}function u(e,t,a){return{...s(e,"Null",t,a),kind:"null"}}function c(e,t,a,i){return{...s(e,"Camera",t,a),kind:"camera",camera:{positionX:0,positionY:0,positionZ:-i,rotationX:0,rotationY:0,rotationZ:0,focalLength:Math.round(1.2*i),zoom:1,depthOfField:0,aperture:.4,focusDistance:i}}}e.s(["createDefaultProject",()=>r,"evalMaskPoints",()=>t,"makeCameraClip",()=>c,"makeClipBase",()=>s,"makeNullClip",()=>u,"makeShapeClip",()=>n,"makeSolidClip",()=>l,"projectDuration",()=>o,"uid",()=>i],34093);var m=e.i(71006),d=e.i(67223),h=e.i(40901);let f="anime-studio:plugins",p=["motion","lighting","distortion","color","anime","stylize","generate","perspective","time","audio"],v=[],_=!1,g=new Set,b=null,x=null;function y(){if(!_){_=!0;try{let e=localStorage.getItem(f);if(e){let t=JSON.parse(e);Array.isArray(t)&&(v=t.filter(e=>e&&e.id&&Array.isArray(e.effects)))}}catch{}if(0===v.length)v=C.map(e=>({...e,installedAt:Date.now()})),k();else{let e=new Set(v.map(e=>e.id)),t=C.filter(t=>!e.has(t.id));t.length>0&&(v=[...v,...t.map(e=>({...e,installedAt:Date.now()}))],k())}}}function k(){try{localStorage.setItem(f,JSON.stringify(v))}catch{}}function T(){for(let e of(b=null,x=null,g))e()}function w(){return y(),[...v]}function E(e){return g.add(e),()=>g.delete(e)}function A(e){let t;y();try{t="string"==typeof e?JSON.parse(e):e}catch{return{ok:!1,error:"Invalid JSON manifest"}}if(!t||"object"!=typeof t)return{ok:!1,error:"Manifest is not an object"};if(!t.id||"string"!=typeof t.id||!/^[a-z0-9_]{2,40}$/.test(t.id))return{ok:!1,error:"Plugin id must be a slug (a-z0-9_, 2-40 chars)"};if(!t.name||"string"!=typeof t.name)return{ok:!1,error:"Missing plugin name"};if(!p.includes(t.category))return{ok:!1,error:`Category must be one of: ${p.join(", ")}`};if(!Array.isArray(t.effects)||0===t.effects.length)return{ok:!1,error:"Plugin must declare at least one effect"};if(t.effects.length>8)return{ok:!1,error:"Max 8 effects per plugin"};for(let e of t.effects){if(!e.type||"string"!=typeof e.type)return{ok:!1,error:"Effect missing type"};if(!e.name||"string"!=typeof e.name)return{ok:!1,error:`Effect ${e.type} missing name`};let t=function(e){if(e.length>8e3)return"Shader too long (max 8000 chars)";if(!/vec3\s+pl_main\s*\(/.test(e))return"Shader must define vec3 pl_main(...)";let t=0;for(let a of e)if("{"===a?t++:"}"===a&&t--,t<0)return"Unbalanced braces in shader";return 0!==t?"Unbalanced braces in shader":/^\s*#version/m.test(e)?"Shader must not contain #version":/^\s*precision/m.test(e)?"Shader must not redeclare precision":/uniform\s+sampler2D/.test(e)?"Shader must not declare samplers (color-in/color-out only)":/texture2D\s*\(\s*u_tex/.test(e)?"Shader must not sample u_tex (color-in/color-out only)":null}(e.shader??"");if(t)return{ok:!1,error:`Effect ${e.type}: ${t}`};if(Array.isArray(e.params)||(e.params=[]),e.params.length>8)return{ok:!1,error:`Effect ${e.type}: max 8 params`};for(let t of e.params){if(!/^[a-zA-Z][a-zA-Z0-9_]{0,23}$/.test(t.key))return{ok:!1,error:`Effect ${e.type}: invalid param key "${t.key}"`};if("number"!=typeof t.min||"number"!=typeof t.max||"number"!=typeof t.default)return{ok:!1,error:`Effect ${e.type}: param ${t.key} needs numeric min/max/default`}}}return v.some(e=>e.id===t.id)?{ok:!1,error:`Plugin "${t.id}" is already installed`}:(v.push({...t,installedAt:Date.now()}),k(),T(),{ok:!0,plugin:t})}function S(e){y();let t=v.length;return(v=v.filter(t=>t.id!==e)).length!==t&&(k(),T(),!0)}function R(e){return e.replace(/[^a-zA-Z0-9_]/g,"_").replace(/^(\d)/,"p$1")}function P(){y();let e=[];for(let t of v)for(let a of t.effects)e.push({pluginId:t.id,pluginName:t.name,effect:a});return e}function M(e,t){return x||(x=new Map,P().forEach((e,t)=>x.set(`${e.pluginId}:${e.effect.type}`,t+1))),x.get(`${e}:${t}`)??0}function I(){if(b)return b;y();let e=P();if(0===e.length)return b="vec3 applyPlugin(vec3 col, vec2 uv, vec2 res, float time) { return col; }";let t=[],a=["vec3 applyPlugin(vec3 col, vec2 uv, vec2 res, float time) {","  if (u_pluginSel < 0.5) return col;"];e.forEach((e,a)=>{let i=e.effect.shader;for(let t of e.effect.params)i=i.split(`u_p_${t.key}`).join(`u_pl${a}_${R(t.key)}`);for(let r of(i=i.split("pl_main").join(`pl${a}_main`),e.effect.params))t.push(`uniform float u_pl${a}_${R(r.key)};`);t.push(`// plugin: ${e.pluginId} :: ${e.effect.type}`),t.push(i)});let i=[];return e.forEach((e,t)=>{i.push(`  if (u_pluginSel < ${(t+1).toFixed(1)}) return pl${t}_main(col, uv, res, time);`)}),a.length=2,a.push(...i),a.push("  return col;","}"),b=[...t,...a].join("\n")}function D(){y();let e=[];for(let t of P()){let a=v.find(e=>e.id===t.pluginId);e.push({type:t.effect.type,name:t.effect.name,category:a?.category??"stylize",description:t.effect.description,params:t.effect.params.map(e=>({...e,uniform:R(e.key)})),pluginId:t.pluginId,pluginName:t.pluginName})}return e}let C=[{id:"vhs_pack",name:"VHS Damage Pack",version:"1.2.0",author:"Anime Studio Labs",category:"distortion",description:"Analog tape artifacts: wavy tracking warp and chroma bleed.",effects:[{type:"vhs_tape_warp",name:"VHS Tape Warp",description:"Horizontal tracking wobble with occasional head-switch jump.",params:[{key:"wobble",label:"Wobble",min:0,max:1,step:.01,default:.35},{key:"jump",label:"Head Switch",min:0,max:1,step:.01,default:.25},{key:"speed",label:"Speed",min:.5,max:12,step:.1,default:4}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  // NOTE: uv-warp approximation via luminance wave (color-level only)
  float t = floor(time * u_p_speed * 3.0);
  float band = floor(uv.y * 18.0);
  float w = (fract(sin(dot(vec2(band, t), vec2(12.9898, 78.233))) * 43758.5453) - 0.5)
          * u_p_wobble * 0.35;
  float jumpRow = step(0.98 - u_p_jump * 0.08, fract(sin(t * 91.7) * 43758.5453));
  float j = jumpRow * step(0.96, fract(uv.y * 9.0 + t)) * 0.08;
  float wave = sin(uv.y * 40.0 + time * 2.0) * 0.02 * u_p_wobble;
  float shift = w + j + wave;
  // emulate horizontal smear: mix toward a horizontally-offset luma tint
  vec3 shifted = vec3(col.r * (1.0 + shift * 6.0), col.g, col.b * (1.0 - shift * 4.0));
  float tapeNoise = fract(sin(dot(uv * res + time * 7.0, vec2(93.989, 67.345))) * 43758.5453) - 0.5;
  shifted += tapeNoise * u_p_wobble * 0.18;
  return clamp(shifted, 0.0, 1.0);
}`},{type:"vhs_chroma_bleed",name:"VHS Chroma Bleed",description:"Color separation smear + scanline darkening.",params:[{key:"bleed",label:"Bleed",min:0,max:1,step:.01,default:.4},{key:"scan",label:"Scanlines",min:0,max:1,step:.01,default:.3}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  vec3 c = col;
  c.r = mix(c.r, dot(c, vec3(0.4, 0.5, 0.1)), u_p_bleed * 0.5);
  c.b = mix(c.b, dot(c, vec3(0.1, 0.2, 0.7)), u_p_bleed * 0.5);
  c *= 1.0 - u_p_scan * 0.45 * step(0.5, fract(uv.y * res.y / 2.5));
  return clamp(c, 0.0, 1.0);
}`}]},{id:"datamosh_pack",name:"Datamosh Pack",version:"1.0.1",author:"Anime Studio Labs",category:"distortion",description:"Compression-artifact aesthetics: block smearing and pixel bleeding.",effects:[{type:"datamosh_blocks",name:"Datamosh",description:"Animated block displacement that melts the image.",params:[{key:"amount",label:"Melt",min:0,max:1,step:.01,default:.45},{key:"block",label:"Block Size",min:4,max:64,step:1,default:16},{key:"speed",label:"Speed",min:.5,max:16,step:.5,default:6}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float t = floor(time * u_p_speed);
  vec2 cell = floor(uv * res / u_p_block);
  float r1 = fract(sin(dot(cell, vec2(127.1, 311.7)) + t) * 43758.5453);
  float r2 = fract(sin(dot(cell, vec2(269.5, 183.3)) + t * 1.7) * 43758.5453);
  vec2 drift = vec2(r1 - 0.5, r2 - 0.5) * u_p_amount * u_p_block / res;
  // smear: neighbor-cell average tinted by drift magnitude
  float mag = length(drift) * res.x;
  vec3 smeared = mix(col, col.gbr, clamp(mag * 0.08, 0.0, 1.0));
  vec3 outc = mix(smeared, vec3(dot(smeared, vec3(0.333))), clamp(u_p_amount * (r2 - 0.6) * 2.0, 0.0, 1.0));
  return clamp(outc, 0.0, 1.0);
}`}]},{id:"holo_pack",name:"Hologram Pack",version:"1.1.0",author:"Anime Studio Labs",category:"stylize",description:"Sci-fi hologram treatments: scan shimmer and fresnel edge tint.",effects:[{type:"holo_scan",name:"Hologram Scan",description:"Ghostly cyan scan shimmer with flicker.",params:[{key:"intensity",label:"Intensity",min:0,max:1,step:.01,default:.5},{key:"speed",label:"Scan Speed",min:.5,max:12,step:.1,default:3},{key:"flicker",label:"Flicker",min:0,max:1,step:.01,default:.4}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float scan = exp(-abs(fract(uv.y * 3.0 - time * u_p_speed) - 0.5) * 9.0);
  float lines = step(0.5, fract(uv.y * res.y / 3.0));
  float flick = 1.0 - u_p_flicker * 0.4 * fract(sin(time * 47.0) * 43758.5453);
  vec3 hcol = vec3(0.35, 0.95, 1.0);
  vec3 c = col * flick;
  c += hcol * scan * u_p_intensity * 0.8;
  c = mix(c, c * (0.75 + 0.25 * lines), u_p_intensity * 0.6);
  return clamp(c, 0.0, 1.0);
}`}]},{id:"snowfall_pack",name:"Snowfall Pack",version:"1.0.0",author:"Anime Studio Labs",category:"generate",description:"Gentle procedural snow with depth layers and drift.",effects:[{type:"snowfall_overlay",name:"Snowfall",description:"Two-layer drifting snow flakes.",params:[{key:"density",label:"Density",min:0,max:1,step:.01,default:.45},{key:"speed",label:"Fall Speed",min:.1,max:3,step:.05,default:.6},{key:"drift",label:"Wind Drift",min:0,max:2,step:.05,default:.5},{key:"size",label:"Flake Size",min:.5,max:4,step:.1,default:1.5}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  vec3 c = col;
  for (int layer = 0; layer < 2; layer++) {
    float fl = float(layer);
    vec2 g = uv * vec2(14.0 + fl * 8.0, 10.0 + fl * 5.0);
    g.y += time * u_p_speed * (1.4 + fl * 0.7);
    g.x += sin(time * 0.7 + fl * 2.1) * u_p_drift * 0.6;
    vec2 id = floor(g);
    vec2 f = fract(g) - 0.5;
    float rnd = fract(sin(dot(id + fl * 13.0, vec2(12.9898, 78.233))) * 43758.5453);
    if (rnd < u_p_density * 0.4) {
      vec2 off = (vec2(fract(rnd * 57.0), fract(rnd * 113.0)) - 0.5) * 0.55;
      float d = length((f - off) / max(u_p_size * 0.11, 0.02));
      c += vec3(0.95, 0.97, 1.0) * smoothstep(1.0, 0.15, d) * (0.55 - fl * 0.15);
    }
  }
  return clamp(c, 0.0, 1.0);
}`}]},{id:"capcut_looks_pack",name:"Looks & Flash Pack",version:"1.0.0",author:"Anime Studio Labs",category:"color",description:"One-tap cinematic looks, beat flash, flicker, negative pulse and cinema bars.",effects:[{type:"film_fade",name:"Film Fade",description:"Lifted blacks and muted color — faded film look.",params:[{key:"fade",label:"Fade",min:0,max:1,step:.01,default:.35},{key:"sat",label:"Saturation",min:0,max:1.5,step:.01,default:.75}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float l = dot(col, vec3(0.299, 0.587, 0.114));
  vec3 c = mix(vec3(l), col, u_p_sat);
  c = c * (1.0 - u_p_fade * 0.35) + vec3(0.06, 0.05, 0.07) * u_p_fade * 1.6;
  return clamp(c, 0.0, 1.0);
}`},{type:"split_tone",name:"Split Tone",description:"Teal shadows, orange highlights.",params:[{key:"amount",label:"Amount",min:0,max:1,step:.01,default:.6},{key:"balance",label:"Balance",min:0,max:1,step:.01,default:.5}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float l = dot(col, vec3(0.299, 0.587, 0.114));
  float w = smoothstep(0.0, 1.0, l + (u_p_balance - 0.5));
  vec3 tone = mix(vec3(0.10, 0.45, 0.55), vec3(1.0, 0.62, 0.30), w);
  vec3 c = mix(col, col * tone * 1.6, u_p_amount * 0.6);
  return clamp(c, 0.0, 1.0);
}`},{type:"neon_night",name:"Neon Night",description:"Cyberpunk blue/magenta night grade.",params:[{key:"amount",label:"Amount",min:0,max:1,step:.01,default:.7},{key:"punch",label:"Punch",min:0,max:1,step:.01,default:.4}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float l = dot(col, vec3(0.299, 0.587, 0.114));
  vec3 neon = mix(vec3(0.15, 0.55, 1.0), vec3(1.0, 0.2, 0.75), smoothstep(0.25, 0.8, l));
  vec3 c = mix(col, col * neon * 1.8, u_p_amount);
  c = (c - 0.5) * (1.0 + u_p_punch * 0.6) + 0.5;
  return clamp(c, 0.0, 1.0);
}`},{type:"beat_flash",name:"Beat Flash",description:"White flash that pulses at a steady rate.",params:[{key:"rate",label:"Rate (Hz)",min:.5,max:8,step:.1,default:2},{key:"power",label:"Power",min:0,max:1,step:.01,default:.6}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float ph = fract(time * u_p_rate);
  float f = pow(1.0 - ph, 6.0) * u_p_power;
  return clamp(col + vec3(f), 0.0, 1.0);
}`},{type:"color_flicker",name:"Color Flicker",description:"Random per-step color tint flicker.",params:[{key:"speed",label:"Speed",min:.5,max:20,step:.1,default:8},{key:"amount",label:"Amount",min:0,max:1,step:.01,default:.4}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float n = floor(time * u_p_speed);
  float r = fract(sin(n * 91.345) * 43758.5453);
  vec3 tint = vec3(1.0) + (vec3(fract(r * 7.0), fract(r * 13.0), fract(r * 29.0)) - 0.5) * u_p_amount;
  return clamp(col * tint, 0.0, 1.0);
}`},{type:"negative_pulse",name:"Negative Pulse",description:"Alternates between normal and inverted colors.",params:[{key:"rate",label:"Rate (Hz)",min:.2,max:8,step:.1,default:1.5},{key:"amount",label:"Amount",min:0,max:1,step:.01,default:1}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float s = step(0.5, fract(time * u_p_rate));
  return mix(col, vec3(1.0) - col, s * u_p_amount);
}`},{type:"cinema_bars",name:"Cinema Bars",description:"Black letterbox bars top and bottom.",params:[{key:"size",label:"Bar Size",min:0,max:.3,step:.005,default:.12},{key:"soft",label:"Softness",min:0,max:.05,step:.001,default:.004}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  float top = smoothstep(u_p_size, u_p_size + u_p_soft + 0.001, uv.y);
  float bot = smoothstep(u_p_size, u_p_size + u_p_soft + 0.001, 1.0 - uv.y);
  return col * top * bot;
}`},{type:"dream_haze",name:"Dream Haze",description:"Soft lifted haze with a warm pastel tint.",params:[{key:"haze",label:"Haze",min:0,max:1,step:.01,default:.4},{key:"warm",label:"Warmth",min:0,max:1,step:.01,default:.3}],shader:`vec3 pl_main(vec3 col, vec2 uv, vec2 res, float time) {
  vec3 c = col + (vec3(1.0) - col) * u_p_haze * 0.28;
  c = mix(c, c * vec3(1.06, 1.0, 0.92), u_p_warm);
  float l = dot(c, vec3(0.299, 0.587, 0.114));
  c = mix(vec3(l), c, 1.0 - u_p_haze * 0.25);
  return clamp(c, 0.0, 1.0);
}`}]}];function F(e){return e*Math.PI/180}e.s(["SAMPLE_PLUGINS",0,C,"getPluginEffectDefs",()=>D,"getPluginShaderChunk",()=>I,"installPluginFromJSON",()=>A,"listInstalledPlugins",()=>w,"onPluginsChanged",()=>E,"pluginSelectionIndex",()=>M,"sanitizeParamKey",()=>R,"uninstallPlugin",()=>S],54449);let U=new Map,X=new Map,L=`
attribute vec2 a_pos;   // unit quad corners (-1..1)
attribute vec2 a_uv;
uniform mat3 u_matrix;  // layer model-projection matrix (affine, or homography for 3D layers)
uniform float u_flipY;
varying vec2 v_uv;
void main() {
  v_uv = a_uv;
  vec3 p = u_matrix * vec3(a_pos, 1.0);
  // For 2D layers p.z == 1 (affine mat3). For 3D layers u_matrix is a full
  // homography: using p.z as gl_Position.w gives perspective-correct UV
  // interpolation across the warped quad.
  gl_Position = vec4(p.xy, 0.0, p.z);
}
`,z=`
precision highp float;
varying vec2 v_uv;
uniform sampler2D u_tex;
uniform sampler2D u_back;      // backdrop (composite so far)
uniform sampler2D u_prev;      // previous composite (trails)
uniform float u_hasTex;
uniform vec2 u_layerSize;      // layer pixel size
uniform vec2 u_compRes;        // comp pixel resolution (render res)
uniform float u_time;
uniform float u_localTime;
uniform float u_opacity;
uniform float u_blend;         // blend mode index
uniform float u_efEnabled;
uniform sampler2D u_matte;     // track matte source (unit 4)
uniform float u_matteMode;     // 0 off \xb7 1 alpha \xb7 2 alphaInv \xb7 3 luma \xb7 4 lumaInv
uniform float u_matteRender;   // 1 while rendering the matte source itself
uniform float u_srcFlip;       // 1 when u_tex is an FBO (adjustment pass)

// ---- grading (combined CPU-side from all color effects)
uniform float u_exposure, u_contrast, u_saturation, u_temperature, u_tint;
uniform float u_lift, u_gamma, u_gain, u_vibrance;
uniform float u_vigAmount, u_vigSoft;

// ---- blur
uniform float u_blurRadius;
uniform vec2 u_blurDir;
uniform vec2 u_motionVec;
uniform float u_zoomBlur;
uniform float u_radialBlur;

// ---- distortion
uniform vec2 u_rgbSplit;
uniform float u_waveAmount, u_waveFreq, u_waveSpeed;
uniform float u_glitch, u_glitchSpeed, u_glitchBlock;
uniform float u_crtCurve, u_crtScan;

// ---- lighting
uniform float u_glowThreshold, u_glowIntensity, u_glowRadius;
uniform float u_auraThreshold, u_auraIntensity, u_auraHue, u_auraPulse;
uniform float u_flareX, u_flareY, u_flareIntensity, u_flareStreak;
uniform float u_leakIntensity, u_leakHue, u_leakAngle;

// ---- anime
uniform float u_slIntensity, u_slCount, u_slSpeed, u_slCX, u_slCY;
uniform float u_flashAmount, u_flashMode;
uniform float u_burstProgress, u_burstIntensity, u_burstHue;
uniform float u_boltIntensity, u_boltCount, u_boltSpeed;
uniform float u_partDensity, u_partSize, u_partSpeed, u_partHue;
uniform float u_halfMix, u_halfScale, u_halfAngle;
uniform float u_trailsDecay;

// ---- mask
uniform float u_maskEnabled, u_maskType, u_maskX, u_maskY, u_maskW, u_maskH, u_maskFeather, u_maskInvert;
// pen mask: flattened closed polygon in layer-uv aspect space (CPU-side bezier flatten)
uniform vec2 u_maskPts[24];
uniform float u_maskPtsN;
uniform float u_maskAspect;

// ---- perspective (AE-style)
uniform float u_bulgeAmount, u_bulgeRadius, u_bulgeCX, u_bulgeCY;
uniform float u_twirlAngle, u_twirlRadius, u_twirlCX, u_twirlCY;
uniform float u_ripAmount, u_ripWave, u_ripSpeed;
uniform float u_fisheyeAmount;
uniform float u_kaleidoSeg, u_kaleidoRot;
uniform float u_tiltX, u_tiltY;
uniform float u_mirrorMode, u_mirrorPos, u_tileN, u_bzAmt, u_bzRate;
uniform float u_keyTol, u_keySoft, u_keyHue;
uniform float u_tsAmt, u_tsPos, u_tsWidth;
uniform float u_dsX, u_dsY, u_dsOpacity, u_dsSoft;

// ---- stylize
uniform float u_posterLevels;
uniform float u_pixSize;
uniform float u_sketchAmount, u_sketchThresh;
uniform float u_neonIntensity, u_neonHue, u_neonThresh;
uniform float u_oilRadius, u_oilMix;
uniform float u_duoHueA, u_duoHueB, u_duoMix;

// ---- generate
uniform float u_grainAmount, u_grainSize, u_grainSpeed;
uniform float u_starDensity, u_starSpeed, u_starTwinkle;
uniform float u_rainIntensity, u_rainAngle, u_rainSpeed;
uniform float u_sakuraDensity, u_sakuraSpeed, u_sakuraSway, u_sakuraSize;
uniform float u_auroraIntensity, u_auroraHue, u_auroraSpeed;
uniform float u_gridSpacing, u_gridOpacity, u_gridGlow;

// ---- time
uniform float u_echoDecay, u_echoX, u_echoY;
uniform float u_shakeIntensity, u_shakeFreq, u_shakeRot;

// ---- lighting extra
uniform float u_bloomThresh, u_bloomIntensity;
uniform float u_godIntensity, u_godX, u_godY, u_godRays;
uniform float u_rimIntensity, u_rimHue;

// ---- color extra
uniform float u_hueDegrees;
uniform float u_cbR, u_cbG, u_cbB;
uniform float u_scAmount, u_scPivot;
uniform float u_sharpenAmount, u_sharpenRadius;
uniform float u_cartoonMix, u_cartoonLevels, u_cartoonEdge;
uniform float u_turbAmount, u_turbScale, u_turbSpeed;

// ---- plugin system (AE-style third-party effects)
uniform float u_pluginSel;
/*__PLUGIN_CHUNK__*/

// ---- LUT (tiled 3D in a 2D atlas)
uniform float u_lutEnabled;
uniform float u_lutSize;
uniform sampler2D u_lutTex;

const float PI = 3.14159265;

// pen-mask helpers: segment SDF + closed polygon SDF (crossing-number inside test)
float asSdSeg(vec2 p, vec2 a, vec2 b) {
  vec2 pa = p - a, ba = b - a;
  float h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-6), 0.0, 1.0);
  return length(pa - ba * h);
}
float asSdPolygon(vec2 p, float n) {
  float nn = max(min(n, 24.0), 3.0);
  vec2 a0 = u_maskPts[0];
  vec2 prevPt = a0;
  float dMin = 1e5;
  int inside = 0;
  // strictly bare loop index (WebGL1 constant-index-expression safe)
  for (int i = 1; i <= 24; i++) {
    if (float(i) > nn) break;
    vec2 curPt = a0;                      // wrap segment closes back to vertex 0
    if (float(i) < nn) curPt = u_maskPts[i];
    dMin = min(dMin, asSdSeg(p, prevPt, curPt));
    if ((prevPt.y > p.y) != (curPt.y > p.y)) {
      float xint = (curPt.x - prevPt.x) * (p.y - prevPt.y) / (curPt.y - prevPt.y) + prevPt.x;
      if (p.x < xint) inside = 1 - inside;
    }
    prevPt = curPt;
  }
  return inside == 1 ? -dMin : dMin;
}

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}
float hash1(float n) { return fract(sin(n) * 43758.5453); }
float noise2(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
             mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  for (int i = 0; i < 4; i++) {
    v += a * noise2(p);
    p = p * 2.02 + vec2(17.3, 9.1);
    a *= 0.5;
  }
  return v;
}
vec3 hueShift(vec3 c, float deg) {
  float a = deg * PI / 180.0;
  vec3 k = vec3(0.57735);
  float ca = cos(a);
  return c * ca + cross(k, c) * sin(a) + k * dot(k, c) * (1.0 - ca);
}
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 applyLUT(vec3 c) {
  float n = u_lutSize;
  // Tiled atlas: width = n*n, height = n. Blue channel picks the tile.
  float b = clamp(c.b, 0.0, 0.999) * (n - 1.0);
  float tile = floor(b);
  float frac = b - tile;
  float tileX = mod(tile, n);
  float tileY = floor(tile / n);
  float tile2 = min(tile + 1.0, n - 1.0);
  float tileX2 = mod(tile2, n);
  float tileY2 = floor(tile2 / n);
  float uu = (tileX * n + clamp(c.r, 0.0, 0.999) * (n - 1.0)) / (n * n);
  float vv = (tileY * n + clamp(c.g, 0.0, 0.999) * (n - 1.0)) / n;
  float uu2 = (tileX2 * n + clamp(c.r, 0.0, 0.999) * (n - 1.0)) / (n * n);
  float vv2 = (tileY2 * n + clamp(c.g, 0.0, 0.999) * (n - 1.0)) / n;
  vec3 s0 = texture2D(u_lutTex, vec2(uu, vv)).rgb;
  vec3 s1 = texture2D(u_lutTex, vec2(uu2, vv2)).rgb;
  return mix(s0, s1, frac);
}

void main() {
  vec2 uv = v_uv;
  vec2 res = u_compRes;
  vec2 px = 1.0 / res;
  // adjustment layers sample the composite FBO through u_tex — mirror the
  // sample coordinates into screen orientation for that pass only
  if (u_srcFlip > 0.5) uv = vec2(uv.x, 1.0 - uv.y);

  // ---------------- distortions (uv space) ----------------
  if (u_efEnabled > 0.5) {
    // turbulent displace (fractal noise warp)
    if (u_turbAmount > 0.01) {
      float evo = u_time * u_turbSpeed;
      vec2 np = uv * max(u_turbScale, 0.5);
      float nx = fbm(np + vec2(evo, -evo * 0.7));
      float ny = fbm(np + vec2(5.2 - evo, 1.3 + evo * 0.9));
      uv += (vec2(nx, ny) - 0.5) * (u_turbAmount * px * 2.0);
    }
    // CRT curve
    if (u_crtCurve > 0.001) {
      vec2 c = uv * 2.0 - 1.0;
      c *= 1.0 + u_crtCurve * 0.18 * (c.x * c.x + c.y * c.y);
      uv = c * 0.5 + 0.5;
    }
    // pixelate (uv quantize)
    if (u_pixSize > 1.5) {
      vec2 blocks = res / max(u_pixSize, 2.0);
      uv = (floor(uv * blocks) + 0.5) / blocks;
    }
    // camera shake (procedural jitter + rotation)
    if (u_shakeIntensity > 0.001) {
      float st = u_time * max(u_shakeFreq, 0.1);
      float sx = (noise2(vec2(st, 3.7)) - 0.5) * 2.0 * u_shakeIntensity;
      float sy = (noise2(vec2(st + 17.3, 9.1)) - 0.5) * 2.0 * u_shakeIntensity;
      float ang = (noise2(vec2(st + 31.7, 5.2)) - 0.5) * 2.0 * u_shakeRot * PI / 180.0;
      uv -= 0.5;
      float cs = cos(ang), sn = sin(ang);
      uv = vec2(uv.x * cs - uv.y * sn, uv.x * sn + uv.y * cs) + 0.5;
      uv += vec2(sx, sy) * px;
    }
    // bulge / pinch
    if (abs(u_bulgeAmount) > 0.001) {
      vec2 bc = vec2(0.5 + u_bulgeCX * 0.5, 0.5 - u_bulgeCY * 0.5);
      vec2 c = uv - bc;
      c.x *= res.x / max(res.y, 1.0);
      float r = length(c);
      float rr = u_bulgeRadius * 0.9;
      if (r < rr) {
        float k = 1.0 - u_bulgeAmount * 0.85 * pow(1.0 - r / rr, 2.0);
        vec2 cuv = vec2(c.x * k / (res.x / max(res.y, 1.0)), c.y * k);
        uv = bc + cuv;
      }
    }
    // twirl
    if (abs(u_twirlAngle) > 0.5) {
      vec2 tc = vec2(0.5 + u_twirlCX * 0.5, 0.5 - u_twirlCY * 0.5);
      vec2 c = uv - tc;
      c.x *= res.x / max(res.y, 1.0);
      float r = length(c);
      if (r < u_twirlRadius) {
        float ang = u_twirlAngle * PI / 180.0 * (1.0 - r / u_twirlRadius);
        float cs = cos(ang), sn = sin(ang);
        c = vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs);
        uv = tc + vec2(c.x / (res.x / max(res.y, 1.0)), c.y);
      }
    }
    // ripple
    if (u_ripAmount > 0.001) {
      vec2 c = uv - 0.5;
      float r = length(c) * res.y;
      float wv = sin(r / max(u_ripWave, 4.0) * PI * 2.0 - u_time * u_ripSpeed * PI * 2.0) * u_ripAmount * 7.0;
      uv += normalize(c + vec2(1e-5)) * wv * px;
    }
    // fisheye
    if (abs(u_fisheyeAmount) > 0.001) {
      vec2 c = uv * 2.0 - 1.0;
      float r2 = dot(c, c);
      float k = 1.0 - u_fisheyeAmount * 0.42 * r2;
      uv = (c * k) * 0.5 + 0.5;
    }
    // beat zoom: punch-in pulse at a steady rate
    if (u_bzAmt > 0.001) {
      float bzPh = fract(u_time * max(u_bzRate, 0.1));
      float bzS = 1.0 + u_bzAmt * pow(1.0 - bzPh, 4.0);
      uv = 0.5 + (uv - 0.5) / bzS;
    }
    // mirror: 1 = horizontal, 2 = vertical, 3 = both
    if (u_mirrorMode > 0.5) {
      if (u_mirrorMode < 1.5 || u_mirrorMode > 2.5) { if (uv.x > u_mirrorPos) uv.x = 2.0 * u_mirrorPos - uv.x; }
      if (u_mirrorMode > 1.5) { if (uv.y > u_mirrorPos) uv.y = 2.0 * u_mirrorPos - uv.y; }
    }
    // tile / split screen (NxN copies)
    if (u_tileN > 1.5) {
      uv = fract(uv * floor(u_tileN + 0.5));
    }
    // kaleidoscope
    if (u_kaleidoSeg > 1.5) {
      float segs = max(2.0, u_kaleidoSeg);
      vec2 c = uv - 0.5;
      float ang = atan(c.y, c.x) + u_kaleidoRot * PI / 180.0;
      float r = length(c);
      float seg = PI * 2.0 / segs;
      float a2 = mod(ang, seg);
      a2 = min(a2, seg * 2.0 - a2);
      uv = vec2(0.5 + cos(a2) * r, 0.5 + sin(a2) * r);
    }
    // 2D tilt (shear)
    if (abs(u_tiltX) > 0.001 || abs(u_tiltY) > 0.001) {
      uv.x += u_tiltX * (0.5 - uv.y) * 0.35;
      uv.y += u_tiltY * (uv.x - 0.5) * 0.35;
    }
    // wave
    if (u_waveAmount > 0.01) {
      float w = sin(uv.y * u_waveFreq * PI * 2.0 + u_time * u_waveSpeed) * u_waveAmount * px.x;
      uv.x += w;
    }
    // glitch: slice displacement + block noise
    if (u_glitch > 0.001) {
      float t = floor(u_time * u_glitchSpeed * 8.0);
      float band = floor(uv.y * 24.0);
      float r1 = hash(vec2(band, t));
      if (r1 > 1.0 - u_glitch * 0.5) {
        uv.x += (hash(vec2(band, t + 7.0)) - 0.5) * u_glitch * 0.15;
      }
      float blk = u_glitchBlock / res.x;
      vec2 cell = floor(uv / vec2(blk, blk * 0.6));
      float r2 = hash(cell + t);
      if (r2 > 1.0 - u_glitch * 0.22) {
        uv.x += (hash(cell + t + 3.0) - 0.5) * blk * u_glitch * 2.0;
        uv.y += (hash(cell + t + 11.0) - 0.5) * blk * u_glitch * 1.2;
      }
    }
  }

  // ---------------- base sample (with RGB split) ----------------
  vec2 splitOff = vec2(0.0);
  if (u_efEnabled > 0.5 && (u_rgbSplit.x != 0.0 || u_rgbSplit.y != 0.0)) splitOff = u_rgbSplit * px;

  vec3 col;
  float texA = 1.0;
  if (u_hasTex > 0.5) {
    vec4 tR = texture2D(u_tex, uv + splitOff);
    vec4 tG = texture2D(u_tex, uv);
    vec4 tB = texture2D(u_tex, uv - splitOff);
    col = vec3(tR.r, tG.g, tB.b);
    texA = (tR.a + tG.a + tB.a) / 3.0;
  } else {
    col = vec3(0.0);
    texA = 0.0;
  }

  // ---------------- chroma key ----------------
  if (u_efEnabled > 0.5 && u_keyTol > 0.001 && u_hasTex > 0.5) {
    vec3 keyRgb = clamp(abs(fract(u_keyHue / 360.0 + vec3(0.0, 0.6667, 0.3333)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    vec2 keyC = vec2(dot(col, vec3(-0.169, -0.331, 0.5)), dot(col, vec3(0.5, -0.419, -0.081)));
    vec2 keyK = vec2(dot(keyRgb, vec3(-0.169, -0.331, 0.5)), dot(keyRgb, vec3(0.5, -0.419, -0.081)));
    float keyA = smoothstep(u_keyTol, u_keyTol + u_keySoft + 0.001, distance(keyC, keyK));
    float keyL = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(keyL), col, mix(0.35, 1.0, keyA));   // suppress key-color spill on edges
    texA *= keyA;
  }

  // ---------------- sharpen + cartoon (source-space) ----------------
  if (u_efEnabled > 0.5 && u_hasTex > 0.5) {
    // unsharp-mask sharpen
    if (u_sharpenAmount > 0.001) {
      vec2 so = vec2(u_sharpenRadius, u_sharpenRadius) * px;
      vec3 nb = texture2D(u_tex, clamp(uv + vec2(so.x, 0.0), vec2(0.001), vec2(0.999))).rgb
              + texture2D(u_tex, clamp(uv - vec2(so.x, 0.0), vec2(0.001), vec2(0.999))).rgb
              + texture2D(u_tex, clamp(uv + vec2(0.0, so.y), vec2(0.001), vec2(0.999))).rgb
              + texture2D(u_tex, clamp(uv - vec2(0.0, so.y), vec2(0.001), vec2(0.999))).rgb;
      col = mix(col, col + (col - nb * 0.25) * u_sharpenAmount * 2.0, clamp(u_sharpenAmount, 0.0, 1.0));
    }
    // cartoon / cel shade: posterized colors + ink edges
    if (u_cartoonMix > 0.001) {
      float lv = max(u_cartoonLevels, 2.0);
      vec3 post = floor(clamp(col, 0.0, 1.0) * lv + 0.5) / lv;
      vec2 e = px * 1.6;
      float lap = abs(luma(texture2D(u_tex, clamp(uv + vec2(e.x, 0.0), vec2(0.001), vec2(0.999))).rgb) - luma(col))
                + abs(luma(texture2D(u_tex, clamp(uv - vec2(e.x, 0.0), vec2(0.001), vec2(0.999))).rgb) - luma(col))
                + abs(luma(texture2D(u_tex, clamp(uv + vec2(0.0, e.y), vec2(0.001), vec2(0.999))).rgb) - luma(col))
                + abs(luma(texture2D(u_tex, clamp(uv - vec2(0.0, e.y), vec2(0.001), vec2(0.999))).rgb) - luma(col));
      float ink = smoothstep(0.10, 0.30, lap * 2.0);
      vec3 toon = mix(post, vec3(0.02), ink * u_cartoonEdge);
      col = mix(col, toon, u_cartoonMix);
    }
  }

  // ---------------- blur ----------------
  if (u_efEnabled > 0.5) {
    // combined directional/gaussian/motion blur — 12 taps
    float blurAmt = max(u_blurRadius, 0.0);
    vec2 dir = u_blurDir + u_motionVec;
    float dirLen = length(dir);
    if (blurAmt > 0.5 || dirLen > 0.5) {
      vec3 acc = col;
      float wsum = 1.0;
      for (int i = 1; i <= 6; i++) {
        float fi = float(i);
        float g = exp(-0.35 * fi * fi);
        vec2 o = (dir / max(dirLen, 1.0)) * fi * max(blurAmt, dirLen / 6.0) * px;
        acc += texture2D(u_tex, uv + o).rgb * g;
        acc += texture2D(u_tex, uv - o).rgb * g;
        wsum += 2.0 * g;
      }
      col = acc / wsum;
    }
    // tilt-shift: blur grows with distance from a focus band
    if (u_tsAmt > 0.01) {
      float tsM = smoothstep(u_tsWidth, u_tsWidth + 0.25, abs(uv.y - u_tsPos));
      float tsR = u_tsAmt * tsM;
      if (tsR > 0.3) {
        vec3 tsAcc = col;
        float tsW = 1.0;
        for (int i = 1; i <= 4; i++) {
          float fi = float(i);
          float g = exp(-0.25 * fi * fi);
          vec2 ox = vec2(fi * tsR * 1.5 * px.x, 0.0);
          vec2 oy = vec2(0.0, fi * tsR * 1.5 * px.y);
          tsAcc += (texture2D(u_tex, uv + ox).rgb + texture2D(u_tex, uv - ox).rgb
                  + texture2D(u_tex, uv + oy).rgb + texture2D(u_tex, uv - oy).rgb) * g;
          tsW += 4.0 * g;
        }
        col = tsAcc / tsW;
      }
    }
    // zoom blur — 6 taps toward center
    if (u_zoomBlur > 0.001) {
      vec2 center = vec2(0.5) ;
      vec3 acc = col;
      for (int i = 1; i <= 6; i++) {
        float fi = float(i) / 6.0;
        vec2 o = (uv - center) * u_zoomBlur * 0.25 * fi;
        acc += texture2D(u_tex, uv - o).rgb;
      }
      col = acc / 7.0;
    }
    // radial (rotational) blur — 6 taps
    if (u_radialBlur > 0.001) {
      vec3 acc = col;
      vec2 rel = uv - 0.5;
      for (int i = 1; i <= 6; i++) {
        float fi = float(i) / 6.0;
        float ang = u_radialBlur * 0.12 * fi;
        float cs = cos(ang), sn = sin(ang);
        vec2 rot = vec2(rel.x * cs - rel.y * sn, rel.x * sn + rel.y * cs) + 0.5;
        acc += texture2D(u_tex, rot).rgb;
      }
      col = acc / 7.0;
    }
  }

  // ---------------- grading ----------------
  if (u_efEnabled > 0.5) {
    // exposure (stops)
    col *= pow(2.0, u_exposure);
    // lift / gamma / gain
    col = col * u_gain + u_lift;
    col = pow(max(col, vec3(0.0)), vec3(1.0 / max(u_gamma, 0.01)));
    // contrast around mid grey
    col = (col - 0.5) * (1.0 + u_contrast) + 0.5;
    // temperature / tint
    col.r += u_temperature * 0.18;
    col.b -= u_temperature * 0.18;
    col.g += u_tint * 0.14;
    col.r -= u_tint * 0.05;
    col.b -= u_tint * 0.05;
    // saturation
    float l = luma(col);
    col = mix(vec3(l), col, 1.0 + u_saturation);
    // vibrance: boost low-sat pixels more
    if (abs(u_vibrance) > 0.001) {
      float sat = max(col.r, max(col.g, col.b)) - min(col.r, min(col.g, col.b));
      col = mix(vec3(l), col, 1.0 + u_vibrance * (1.0 - sat));
    }
    // hue rotate
    if (abs(u_hueDegrees) > 0.5) {
      col = hueShift(col, u_hueDegrees);
    }
    // color balance
    if (abs(u_cbR) + abs(u_cbG) + abs(u_cbB) > 0.001) {
      col += vec3(u_cbR, u_cbG, u_cbB) * 0.3;
    }
    // S-curve contrast (filmic)
    if (u_scAmount > 0.001) {
      vec3 pc = pow(max(col, vec3(0.0)), vec3(log(max(u_scPivot, 0.1)) / log(0.5)));
      col = mix(pc, pc * pc * (3.0 - 2.0 * pc), clamp(u_scAmount * 1.6, 0.0, 1.0));
    }
    // posterize
    if (u_posterLevels >= 1.5) {
      float lv = max(2.0, u_posterLevels);
      col = floor(clamp(col, 0.0, 1.0) * lv + 0.5) / lv;
    }
    // duotone
    if (u_duoMix > 0.001) {
      float dl = luma(col);
      vec3 duo = hueShift(vec3(0.16, 0.22, 0.55), u_duoHueA) * (1.0 - dl) + hueShift(vec3(1.0, 0.82, 0.42), u_duoHueB) * dl;
      col = mix(col, duo, u_duoMix);
    }
    // vignette
    if (u_vigAmount > 0.001) {
      vec2 vq = (uv - 0.5) * vec2(res.x / max(res.y, 1.0), 1.0);
      float d = length(vq) / (0.5 * sqrt(1.0 + (res.x / max(res.y, 1.0)) * (res.x / max(res.y, 1.0))));
      float v = smoothstep(1.0 - u_vigSoft, 1.0 + u_vigSoft * 0.4, d * (1.0 + u_vigAmount));
      col *= 1.0 - v * u_vigAmount;
    }
  }

  // ---------------- lighting: glow (bright-pass blur) ----------------
  if (u_efEnabled > 0.5 && u_glowIntensity > 0.001 && u_hasTex > 0.5) {
    vec3 acc = vec3(0.0);
    float r = u_glowRadius / res.x * 8.0;
    for (int i = 0; i < 8; i++) {
      float a = float(i) * PI / 4.0;
      vec2 o = vec2(cos(a), sin(a)) * r * px;
      vec3 s = texture2D(u_tex, uv + o).rgb;
      float b = max(0.0, luma(s) - u_glowThreshold);
      acc += s * b;
    }
    vec3 bright = max(vec3(0.0), col - vec3(u_glowThreshold)) * 2.0;
    col += (acc / 8.0 + bright) * u_glowIntensity * 0.85;
  }

  // ---------------- stylize: sketch / neon / oil ----------------
  float shAlpha = 0.0;
  if (u_efEnabled > 0.5) {
    // drop shadow (shadow alpha carried to blend stage)
    if (u_dsOpacity > 0.001 && u_hasTex > 0.5) {
      vec2 so = vec2(u_dsX, -u_dsY) * px;
      float sacc = 0.0;
      for (int i = 0; i < 5; i++) {
        float fi = float(i) * 1.2566;
        vec2 o = vec2(cos(fi), sin(fi)) * max(u_dsSoft, 0.5) * px;
        sacc += texture2D(u_tex, clamp(uv + so + o, vec2(0.001), vec2(0.999))).a;
      }
      shAlpha = clamp(sacc * 0.2, 0.0, 1.0) * u_dsOpacity * (1.0 - texA);
    }
    // pencil sketch
    if (u_sketchAmount > 0.001 && u_hasTex > 0.5) {
      vec2 e = px * 1.5;
      float lumC = luma(col);
      float lap = abs(luma(texture2D(u_tex, uv + vec2(e.x, 0.0)).rgb) - lumC)
                + abs(luma(texture2D(u_tex, uv - vec2(e.x, 0.0)).rgb) - lumC)
                + abs(luma(texture2D(u_tex, uv + vec2(0.0, e.y)).rgb) - lumC)
                + abs(luma(texture2D(u_tex, uv - vec2(0.0, e.y)).rgb) - lumC);
      float line = smoothstep(u_sketchThresh, u_sketchThresh + 0.22, lap * 2.2);
      vec3 sk = mix(vec3(0.96), vec3(0.07), line);
      col = mix(col, sk, u_sketchAmount);
    }
    // neon edges
    if (u_neonIntensity > 0.001 && u_hasTex > 0.5) {
      vec2 e = px * 2.0;
      float lap = luma(texture2D(u_tex, uv + vec2(e.x, 0.0)).rgb) + luma(texture2D(u_tex, uv - vec2(e.x, 0.0)).rgb)
                + luma(texture2D(u_tex, uv + vec2(0.0, e.y)).rgb) + luma(texture2D(u_tex, uv - vec2(0.0, e.y)).rgb)
                - 4.0 * luma(col);
      float edge = max(0.0, lap - u_neonThresh * 0.5);
      vec3 ncol = hueShift(vec3(0.85, 0.2, 1.0), u_neonHue);
      col += ncol * edge * u_neonIntensity * 2.4;
    }
    // oil paint (4-sector kuwahara, radius ≤ 3)
    if (u_oilMix > 0.001 && u_hasTex > 0.5) {
      const int R = 3;
      vec3 bestMean = col;
      float bestVar = 1e5;
      for (int q = 0; q < 4; q++) {
        vec2 qs = vec2(q == 0 || q == 3 ? -1.0 : 1.0, q < 2 ? -1.0 : 1.0);
        vec3 acc = vec3(0.0);
        vec3 acc2 = vec3(0.0);
        float cnt = 0.0;
        for (int dy = 0; dy <= R; dy++) {
          for (int dx = 0; dx <= R; dx++) {
            vec2 o = vec2(float(dx), float(dy)) * qs * max(u_oilRadius, 1.0) * px;
            vec3 s = texture2D(u_tex, clamp(uv + o, vec2(0.001), vec2(0.999))).rgb;
            acc += s;
            acc2 += s * s;
            cnt += 1.0;
          }
        }
        vec3 mean = acc / cnt;
        vec3 variance = abs(acc2 / cnt - mean * mean);
        float v = variance.r + variance.g + variance.b;
        if (v < bestVar) { bestVar = v; bestMean = mean; }
      }
      col = mix(col, bestMean, u_oilMix);
    }
  }

  // ---------------- anime aura ----------------
  if (u_efEnabled > 0.5 && u_auraIntensity > 0.001 && u_hasTex > 0.5) {
    vec2 e = px * 2.0;
    float lap = luma(texture2D(u_tex, uv + vec2(e.x, 0.0)).rgb) + luma(texture2D(u_tex, uv - vec2(e.x, 0.0)).rgb)
              + luma(texture2D(u_tex, uv + vec2(0.0, e.y)).rgb) + luma(texture2D(u_tex, uv - vec2(0.0, e.y)).rgb)
              - 4.0 * luma(col);
    float edge = max(0.0, lap);
    float pulse = 0.75 + 0.25 * sin(u_time * u_auraPulse * PI * 2.0);
    vec3 auraCol = hueShift(vec3(0.35, 0.75, 1.0), u_auraHue);
    col += auraCol * edge * u_auraIntensity * 2.2 * pulse;
    // outer bloom tinted
    vec2 o2 = px * 8.0;
    float outer = max(0.0, luma(texture2D(u_tex, uv + o2).rgb) - u_auraThreshold);
    col += auraCol * outer * u_auraIntensity * 0.8 * pulse;
  }

  // ---------------- lighting extras: soft bloom / god rays / rim ----------------
  if (u_efEnabled > 0.5) {
    if (u_bloomIntensity > 0.001 && u_hasTex > 0.5) {
      vec3 acc = vec3(0.0);
      float rb = 14.0 / res.x * 8.0;
      for (int i = 0; i < 8; i++) {
        float a = float(i) * PI / 4.0;
        vec2 o = vec2(cos(a), sin(a)) * rb * px;
        vec3 s = texture2D(u_tex, uv + o).rgb;
        acc += s;
      }
      vec3 wide = acc / 8.0;
      vec3 bright = max(vec3(0.0), wide - u_bloomThresh);
      col += bright * u_bloomIntensity * 1.1;
    }
    if (u_godIntensity > 0.001) {
      vec2 sp = vec2(0.5 + u_godX * 0.5, 0.5 - u_godY * 0.5);
      vec2 d = uv - sp;
      float ang = atan(d.y, d.x);
      float r = length(d);
      float rays = floor((ang / PI * 0.5 + 0.5) * max(u_godRays, 2.0));
      float rayOn = step(0.45, hash1(rays));
      float fade = exp(-r * 3.2);
      col += vec3(1.0, 0.96, 0.86) * rayOn * fade * u_godIntensity * 0.6 * smoothstep(0.0, 0.18, r);
    }
    if (u_rimIntensity > 0.001 && u_hasTex > 0.5) {
      vec2 e = px * 2.5;
      float lap = luma(texture2D(u_tex, uv + vec2(e.x, 0.0)).rgb) + luma(texture2D(u_tex, uv - vec2(e.x, 0.0)).rgb)
                + luma(texture2D(u_tex, uv + vec2(0.0, e.y)).rgb) + luma(texture2D(u_tex, uv - vec2(0.0, e.y)).rgb)
                - 4.0 * luma(col);
      float edge = max(0.0, lap);
      col += hueShift(vec3(1.0, 0.86, 0.62), u_rimHue) * edge * u_rimIntensity * 2.0;
    }
  }

  // ---------------- anime overlays ----------------
  if (u_efEnabled > 0.5) {
    // speed lines
    if (u_slIntensity > 0.001) {
      vec2 fc = uv - vec2(0.5 + u_slCX * 0.5, 0.5 - u_slCY * 0.5);
      float ang = atan(fc.y, fc.x);
      float rad = length(fc);
      float idx = floor((ang / PI * 0.5 + 0.5) * u_slCount);
      float line = hash1(idx);
      float on = step(1.0 - u_slIntensity * 0.65, hash1(idx + floor(u_time * u_slSpeed)));
      float thick = 0.35 + 0.65 * hash1(idx * 3.7);
      float inner = smoothstep(0.06, 0.22, rad);
      float m = on * thick * inner * smoothstep(0.9, 0.35, rad);
      col = mix(col, vec3(1.0), m * u_slIntensity * 0.9);
    }
    // impact flash
    if (u_flashAmount > 0.001) {
      if (u_flashMode > 0.5) {
        vec3 inv = 1.0 - col;
        col = mix(col, inv * 1.2, u_flashAmount);
      } else {
        col = mix(col, vec3(1.0), u_flashAmount);
      }
    }
    // energy burst rings
    if (u_burstIntensity > 0.001) {
      vec2 fc = uv - 0.5;
      float rad = length(fc) * 2.0;
      float ring = abs(rad - u_burstProgress * 1.4);
      float ringM = smoothstep(0.08, 0.0, ring) * (1.0 - u_burstProgress * 0.7);
      vec3 bcol = hueShift(vec3(0.2, 0.9, 1.0), u_burstHue);
      col += bcol * ringM * u_burstIntensity;
      col += bcol * smoothstep(0.03, 0.0, ring) * u_burstIntensity * 1.5;
    }
    // lightning
    if (u_boltIntensity > 0.001) {
      for (int i = 0; i < 4; i++) {
        if (float(i) >= u_boltCount) break;
        float fi = float(i);
        float t = floor(u_time * u_boltSpeed + fi * 17.0);
        float seed = hash1(t + fi * 31.0);
        float x0 = mix(-0.2, 1.2, hash1(seed * 91.7));
        float seg = floor(uv.x * 14.0);
        float dx = x0 + (hash1(seg * 7.3 + seed) - 0.5) * 0.16 + uv.x * 0.1 - 0.05;
        float d = abs(uv.y - dx);
        float bolt = smoothstep(0.006, 0.0, d) * step(hash1(t * 3.3 + fi), u_boltIntensity);
        col += vec3(0.85, 0.9, 1.0) * bolt * u_boltIntensity;
      }
    }
    // particles
    if (u_partDensity > 0.001) {
      vec3 pcol = hueShift(vec3(1.0, 0.65, 0.25), u_partHue);
      float acc = 0.0;
      for (int i = 0; i < 3; i++) {
        float fi = float(i);
        vec2 g = uv * vec2(24.0, 18.0) + fi * 13.7;
        g.y -= u_time * u_partSpeed * (6.0 + fi * 3.0);
        vec2 id = floor(g);
        vec2 f = fract(g) - 0.5;
        float rnd = hash(id + fi);
        if (rnd < u_partDensity * 0.35) {
          vec2 off = (vec2(hash(id + 3.0), hash(id + 7.0)) - 0.5) * 0.7;
          float d = length(f - off);
          acc += smoothstep(u_partSize * 0.014 * (0.5 + rnd), 0.0, d);
        }
      }
      col += pcol * acc * 0.85;
    }
    // manga halftone
    if (u_halfMix > 0.001) {
      float a = u_halfAngle * PI / 180.0;
      vec2 rp = vec2(uv.x * cos(a) - uv.y * sin(a), uv.x * sin(a) + uv.y * cos(a)) * res.y / u_halfScale;
      vec2 f = fract(rp) - 0.5;
      float dotM = smoothstep(0.35, 0.25, length(f));
      float l = luma(col);
      vec3 inked = mix(vec3(0.0), vec3(1.0), step(dotM, l));
      col = mix(col, inked, u_halfMix);
    }
    // CRT scanlines
    if (u_crtScan > 0.001) {
      col *= 1.0 - u_crtScan * 0.5 * step(0.5, fract(uv.y * res.y / 3.0));
    }
    // film grain
    if (u_grainAmount > 0.001) {
      float g = noise2(uv * res * (0.6 * max(u_grainSize, 0.3)) + vec2(u_time * u_grainSpeed * 13.0, u_time * u_grainSpeed * 7.0));
      col += (g - 0.5) * u_grainAmount * 0.4;
    }
    // starfield
    if (u_starDensity > 0.001) {
      vec2 g = uv * vec2(42.0, 24.0);
      g.y += u_time * u_starSpeed * 2.0;
      vec2 id = floor(g);
      vec2 f = fract(g) - 0.5;
      float rnd = hash(id);
      if (rnd < u_starDensity * 0.5) {
        vec2 off = (vec2(hash(id + 1.0), hash(id + 2.0)) - 0.5) * 0.6;
        float d = length(f - off);
        float tw = 0.55 + 0.45 * sin(u_time * u_starTwinkle * 3.0 + rnd * 40.0);
        col += vec3(1.0, 0.98, 0.9) * smoothstep(0.05 + rnd * 0.06, 0.0, d) * tw;
      }
    }
    // rain
    if (u_rainIntensity > 0.001) {
      float ra = u_rainAngle * PI / 180.0;
      vec2 rp = uv * vec2(70.0, 10.0);
      rp += vec2(u_time * u_rainSpeed * sin(ra) * 4.0, u_time * u_rainSpeed);
      float xid = floor(rp.x);
      float phase = fract(rp.y);
      float on = step(0.94 - u_rainIntensity * 0.12, hash(vec2(xid, floor(rp.y))));
      float streak = smoothstep(0.5, 0.0, abs(phase - 0.5) - 0.32);
      col += vec3(0.78, 0.84, 0.96) * on * streak * u_rainIntensity * 0.75;
    }
    // sakura petals
    if (u_sakuraDensity > 0.001) {
      for (int layer = 0; layer < 2; layer++) {
        float fl = float(layer);
        vec2 g = uv * vec2(9.0 + fl * 3.0, 6.0 + fl * 2.0);
        g.y += u_time * u_sakuraSpeed * (1.0 + fl * 0.5);
        g.x += sin(u_time * u_sakuraSway + g.y * 1.7) * 0.35;
        vec2 id = floor(g);
        vec2 f = fract(g) - 0.5;
        float rnd = hash(id + fl * 7.0);
        if (rnd < u_sakuraDensity * 0.35) {
          vec2 off = (vec2(hash(id + 3.0), hash(id + 5.0)) - 0.5) * 0.5;
          vec2 p = (f - off) / max(u_sakuraSize * 0.12, 0.02);
          p.x *= 1.35;
          float d = length(p);
          float petal = smoothstep(0.62, 0.3, d) * smoothstep(0.12, 0.3, abs(p.x));
          col = mix(col, vec3(1.0, 0.74, 0.8), petal * 0.85);
        }
      }
    }
    // aurora
    if (u_auroraIntensity > 0.001) {
      float y1 = 0.38 + 0.16 * sin(uv.x * 4.2 + u_time * u_auroraSpeed) + 0.08 * sin(uv.x * 11.0 - u_time * u_auroraSpeed * 1.7);
      float band = exp(-abs(uv.y - y1) * 8.5);
      float ray = 0.6 + 0.4 * sin(uv.x * 38.0 + u_time * u_auroraSpeed * 3.0);
      vec3 acol = hueShift(vec3(0.12, 1.0, 0.55), u_auroraHue);
      col += acol * band * ray * u_auroraIntensity * 0.9;
    }
    // grid / HUD
    if (u_gridOpacity > 0.001) {
      vec2 gg = uv * res / max(u_gridSpacing, 4.0);
      vec2 gf = abs(fract(gg) - 0.5);
      float line = smoothstep(0.07, 0.02, min(gf.x, gf.y));
      float scan = exp(-abs(fract(uv.y * 2.0 - u_time * 0.3) - 0.5) * 12.0) * u_gridGlow;
      vec3 gcol = vec3(0.35, 0.9, 0.75);
      col = mix(col, gcol, line * u_gridOpacity * 0.55);
      col += gcol * scan * u_gridOpacity * 0.6;
    }
  }

  // ---------------- trails (feedback) ----------------
  vec2 fboUv = vec2(v_uv.x, 1.0 - v_uv.y); // FBO textures are stored NDC-y-up
  if (u_efEnabled > 0.5 && u_trailsDecay > 0.001) {
    vec3 prevCol = texture2D(u_prev, fboUv).rgb;
    col = max(col, prevCol * u_trailsDecay);
  }
  // motion echo (directional feedback)
  if (u_efEnabled > 0.5 && u_echoDecay > 0.05) {
    vec2 eo = vec2(u_echoX, -u_echoY) * px * 3.0;
    vec3 prevCol = texture2D(u_prev, clamp(fboUv + eo, vec2(0.001), vec2(0.999))).rgb;
    col = max(col, prevCol * u_echoDecay);
  }
  if (u_efEnabled > 0.5) {
    // lens flare
    if (u_flareIntensity > 0.001) {
      vec2 sp = vec2(0.5 + u_flareX * 0.5, 0.5 - u_flareY * 0.5);
      vec2 d = uv - sp;
      d.x *= res.x / max(res.y, 1.0);
      float core = exp(-length(d) * 14.0);
      float streak = exp(-abs(d.y) * (60.0 - u_flareStreak * 40.0)) * exp(-abs(d.x) * 1.8);
      vec3 fcol = vec3(1.0, 0.92, 0.8);
      col += fcol * (core * 1.2 + streak * u_flareStreak * 1.4) * u_flareIntensity;
      // ghosts
      vec2 gd = (sp - uv) * 1.8;
      float g1 = exp(-length(d + gd) * 22.0);
      float g2 = exp(-length(d + gd * 2.3) * 26.0);
      col += (vec3(0.4, 0.7, 1.0) * g1 + vec3(1.0, 0.5, 0.4) * g2) * u_flareIntensity * 0.5;
    }
    // light leak
    if (u_leakIntensity > 0.001) {
      float a = u_leakAngle * PI / 180.0;
      vec2 dirv = vec2(cos(a), sin(a));
      float grad = dot(uv - 0.5, dirv) + 0.75;
      vec3 lcol = hueShift(vec3(1.0, 0.6, 0.3), u_leakHue);
      col += lcol * max(0.0, grad) * u_leakIntensity * 0.55;
    }
  }

  // ---------------- plugin dispatch (AE-style third-party effects) ----------------
  if (u_efEnabled > 0.5 && u_pluginSel > 0.5) {
    col = applyPlugin(col, uv, res, u_time);
  }

  // ---------------- LUT ----------------
  if (u_lutEnabled > 0.5 && u_lutSize > 1.5) {
    col = applyLUT(clamp(col, 0.0, 1.0));
  }

  // ---------------- mask ----------------
  float alpha = u_opacity;
  if (u_efEnabled > 0.5 && u_maskEnabled > 0.5) {
    float aspect = res.x / max(res.y, 1.0);
    float d;
    if (u_maskType > 1.5) {
      // pen (bezier flattened to polygon on CPU, points in layer-uv aspect space)
      vec2 pp = vec2(uv.x * max(u_maskAspect, 0.01), uv.y);
      d = asSdPolygon(pp, max(u_maskPtsN, 3.0));
    } else {
      vec2 mc = uv - vec2(0.5 + u_maskX * 0.5, 0.5 - u_maskY * 0.5);
      mc *= vec2(aspect, 1.0);
      float w = u_maskW * 0.5, h = u_maskH * 0.5;
      if (u_maskType < 0.5) {
        vec2 q = abs(mc) - vec2(w * aspect * 0.5 * 2.0, h);
        d = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0);
      } else {
        vec2 nrm = mc / vec2(w * aspect, h);
        d = length(nrm) - 1.0;
      }
    }
    float aa = max(u_maskFeather, 0.001);
    float m = 1.0 - smoothstep(-aa, aa, d);
    if (u_maskInvert > 0.5) m = 1.0 - m;
    alpha *= m;
  }

  // ---------------- track matte gating ----------------
  if (u_efEnabled > 0.5 && u_matteMode > 0.5) {
    vec4 mt = texture2D(u_matte, fboUv);
    float mf = u_matteMode < 1.5 ? mt.a
             : u_matteMode < 2.5 ? 1.0 - mt.a
             : u_matteMode < 3.5 ? luma(mt.rgb)
             : 1.0 - luma(mt.rgb);
    alpha *= clamp(mf, 0.0, 1.0);
  }

  // ---------------- blend with backdrop ----------------
  if (u_matteRender > 0.5) {
    // matte source pass: no backdrop blending — output straight color + alpha
    float saM = clamp(alpha * max(texA, shAlpha), 0.0, 1.0);
    gl_FragColor = vec4(col, saM);
    return;
  }
  vec3 back = texture2D(u_back, fboUv).rgb;
  vec3 outc;
  float bm = u_blend;
  float layerA = texA;
  float sa = alpha * max(layerA, shAlpha); // combined layer alpha (+ drop shadow)
  if (bm < 0.5) {
    outc = mix(back, col, sa);
  } else if (bm < 1.5) { // add
    outc = back + col * sa;
  } else if (bm < 2.5) { // screen
    outc = mix(back, 1.0 - (1.0 - back) * (1.0 - col), sa);
  } else if (bm < 3.5) { // multiply
    outc = mix(back, back * col, sa);
  } else if (bm < 4.5) { // overlay
    vec3 ov = mix(2.0 * back * col, 1.0 - 2.0 * (1.0 - back) * (1.0 - col), step(0.5, back));
    outc = mix(back, ov, sa);
  } else if (bm < 5.5) { // lighten
    outc = mix(back, max(back, col), sa);
  } else { // difference
    outc = mix(back, abs(back - col), sa);
  }

  gl_FragColor = vec4(clamp(outc, 0.0, 1.0), 1.0);
}
`;function B(e){return z.replace("/*__PLUGIN_CHUNK__*/",e)}let N=`
precision highp float;
varying vec2 v_uv;
uniform sampler2D u_tex;
uniform float u_lutEnabled;
uniform float u_lutSize;
uniform sampler2D u_lutTex;
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 applyLUT(vec3 c) {
  float n = u_lutSize;
  float b = clamp(c.b, 0.0, 0.999) * (n - 1.0);
  float tile = floor(b);
  float frac = b - tile;
  float tileX = mod(tile, n);
  float tileY = floor(tile / n);
  float tile2 = min(tile + 1.0, n - 1.0);
  float tileX2 = mod(tile2, n);
  float tileY2 = floor(tile2 / n);
  float uu = (tileX * n + clamp(c.r, 0.0, 0.999) * (n - 1.0)) / (n * n);
  float vv = (tileY * n + clamp(c.g, 0.0, 0.999) * (n - 1.0)) / n;
  float uu2 = (tileX2 * n + clamp(c.r, 0.0, 0.999) * (n - 1.0)) / (n * n);
  float vv2 = (tileY2 * n + clamp(c.g, 0.0, 0.999) * (n - 1.0)) / n;
  vec3 s0 = texture2D(u_lutTex, vec2(uu, vv)).rgb;
  vec3 s1 = texture2D(u_lutTex, vec2(uu2, vv2)).rgb;
  return mix(s0, s1, frac);
}
void main() {
  vec4 c = texture2D(u_tex, vec2(v_uv.x, 1.0 - v_uv.y));
  if (u_lutEnabled > 0.5 && u_lutSize > 1.5) {
    c.rgb = applyLUT(clamp(c.rgb, 0.0, 1.0));
  }
  gl_FragColor = c;
}
`,O={normal:0,add:1,screen:2,multiply:3,overlay:4,lighten:5,difference:6};function Y(){return[1,0,0,0,1,0,0,0,1]}function H(e,t){let a=Array(9).fill(0);for(let i=0;i<3;i++)for(let r=0;r<3;r++)for(let o=0;o<3;o++)a[3*i+r]+=e[3*i+o]*t[3*o+r];return a}function G(e,t){return[1,0,0,0,1,0,e,t,1]}function V(e,t){return[e,0,0,0,t,0,0,0,1]}function W(e){let t=Math.cos(e),a=Math.sin(e);return[t,a,0,-a,t,0,0,0,1]}function $(e,t,a={hasTex:0,layerSize:[16,16],opacity:1,blend:0,exposure:0,contrast:0,saturation:0,temperature:0,tint:0,lift:0,gamma:1,gain:1,vibrance:0,vigAmount:0,vigSoft:.5,blurRadius:0,blurDir:[0,0],motionVec:[0,0],zoomBlur:0,radialBlur:0,rgbSplit:[0,0],waveAmount:0,waveFreq:8,waveSpeed:2,glitch:0,glitchSpeed:6,glitchBlock:24,crtCurve:0,crtScan:0,glowThreshold:.55,glowIntensity:0,glowRadius:12,auraThreshold:.4,auraIntensity:0,auraHue:210,auraPulse:2,flareX:0,flareY:0,flareIntensity:0,flareStreak:.6,leakIntensity:0,leakHue:30,leakAngle:45,slIntensity:0,slCount:80,slSpeed:3,slCX:0,slCY:0,flashAmount:0,flashMode:1,burstProgress:.5,burstIntensity:0,burstHue:190,boltIntensity:0,boltCount:3,boltSpeed:8,partDensity:0,partSize:2,partSpeed:.6,partHue:35,halfMix:0,halfScale:8,halfAngle:45,trailsDecay:0,bulgeAmount:0,bulgeRadius:.7,bulgeCX:0,bulgeCY:0,twirlAngle:0,twirlRadius:.6,twirlCX:0,twirlCY:0,ripAmount:0,ripWave:60,ripSpeed:1.5,fisheyeAmount:0,kaleidoSeg:0,kaleidoRot:0,mirrorMode:0,mirrorPos:.5,tileN:1,bzAmt:0,bzRate:2,keyTol:0,keySoft:.08,keyHue:120,tsAmt:0,tsPos:.5,tsWidth:.15,tiltX:0,tiltY:0,dsX:10,dsY:10,dsOpacity:0,dsSoft:8,posterLevels:0,pixSize:0,sketchAmount:0,sketchThresh:.35,neonIntensity:0,neonHue:320,neonThresh:.3,oilRadius:3,oilMix:0,duoHueA:230,duoHueB:45,duoMix:0,grainAmount:0,grainSize:1.2,grainSpeed:2,starDensity:0,starSpeed:.3,starTwinkle:1,rainIntensity:0,rainAngle:12,rainSpeed:2.5,sakuraDensity:0,sakuraSpeed:.5,sakuraSway:1,sakuraSize:1.4,auroraIntensity:0,auroraHue:150,auroraSpeed:.8,gridSpacing:32,gridOpacity:0,gridGlow:.4,echoDecay:0,echoX:-14,echoY:0,shakeIntensity:0,shakeFreq:12,shakeRot:.8,bloomThresh:.5,bloomIntensity:0,godIntensity:0,godX:-.3,godY:.4,godRays:10,rimIntensity:0,rimHue:40,hueDegrees:0,cbR:0,cbG:0,cbB:0,scAmount:0,scPivot:.5,sharpenAmount:0,sharpenRadius:1,cartoonMix:0,cartoonLevels:5,cartoonEdge:0,turbAmount:0,turbScale:6,turbSpeed:.6,pluginSel:0,pluginParams:{},maskEnabled:0,maskType:0,maskX:0,maskY:0,maskW:1,maskH:1,maskFeather:.08,maskInvert:0,maskPts:[],maskPtsN:0,maskAspect:1,lutEnabled:0,lutSize:0}){for(let e of Object.keys(a))if("hasTex"===e||"layerSize"===e||"opacity"===e||"blend"===e||e.startsWith("lut"))continue;for(let i of e.effects.filter(e=>e.enabled)){let e=e=>(0,m.evalEffectParam)(i,e,t);switch(i.type){case"directional_blur":{let t=e("amount"),i=e("angle")*Math.PI/180;a.blurDir=[Math.cos(i)*t,-Math.sin(i)*t];break}case"gaussian_blur":a.blurRadius=Math.max(a.blurRadius,e("amount"));break;case"zoom_blur":a.zoomBlur=Math.max(a.zoomBlur,e("amount"));break;case"radial_blur":a.radialBlur=Math.max(a.radialBlur,e("amount"));break;case"motion_trails":a.trailsDecay=e("decay");break;case"glow":a.glowThreshold=e("threshold"),a.glowIntensity=e("intensity"),a.glowRadius=e("radius");break;case"aura":a.auraThreshold=e("threshold"),a.auraIntensity=e("intensity"),a.auraHue=e("hue"),a.auraPulse=e("pulse");break;case"lens_flare":a.flareX=e("x"),a.flareY=e("y"),a.flareIntensity=e("intensity"),a.flareStreak=e("streak");break;case"light_leak":a.leakIntensity=e("intensity"),a.leakHue=e("hue"),a.leakAngle=e("angle");break;case"vignette":a.vigAmount=e("amount"),a.vigSoft=e("softness");break;case"rgb_split":{let t=e("amount"),i=e("angle")*Math.PI/180;a.rgbSplit=[Math.cos(i)*t,Math.sin(i)*t];break}case"chromatic_aberration":{let t=14*e("amount");a.rgbSplit=[Math.max(a.rgbSplit[0],.6*t),Math.max(a.rgbSplit[1],.6*t)];break}case"glitch":a.glitch=e("amount"),a.glitchSpeed=e("speed"),a.glitchBlock=e("blockSize");break;case"wave_distortion":a.waveAmount=e("amount"),a.waveFreq=e("frequency"),a.waveSpeed=e("speed");break;case"screen_distortion":a.crtCurve=e("curve"),a.crtScan=e("scanlines");break;case"exposure":a.exposure+=e("stops");break;case"contrast":a.contrast+=e("amount");break;case"saturation":a.saturation+=e("amount");break;case"temperature":a.temperature+=e("value");break;case"tint":a.tint+=e("value");break;case"lift_gamma_gain":a.lift+=e("lift"),a.gamma*=e("gamma"),a.gain*=e("gain");break;case"vibrance":a.vibrance+=e("amount");break;case"speed_lines":a.slIntensity=e("intensity"),a.slCount=e("count"),a.slSpeed=e("speed"),a.slCX=e("centerX"),a.slCY=e("centerY");break;case"impact_flash":a.flashAmount=e("amount"),a.flashMode=e("mode");break;case"energy_burst":a.burstProgress=e("progress"),a.burstIntensity=e("intensity"),a.burstHue=e("hue");break;case"lightning":a.boltIntensity=e("intensity"),a.boltCount=e("boltCount"),a.boltSpeed=e("speed");break;case"particles":a.partDensity=e("density"),a.partSize=e("size"),a.partSpeed=e("speed"),a.partHue=e("hue");break;case"halftone":a.halfMix=e("amount"),a.halfScale=e("scale"),a.halfAngle=e("angle");break;case"bulge":a.bulgeAmount=e("amount"),a.bulgeRadius=e("radius"),a.bulgeCX=e("centerX"),a.bulgeCY=e("centerY");break;case"twirl":a.twirlAngle=e("angle"),a.twirlRadius=e("radius"),a.twirlCX=e("centerX"),a.twirlCY=e("centerY");break;case"ripple":a.ripAmount=e("amount"),a.ripWave=e("wavelength"),a.ripSpeed=e("speed");break;case"fisheye":a.fisheyeAmount=e("amount");break;case"kaleido":a.kaleidoSeg=e("segments"),a.kaleidoRot=e("rotation");break;case"mirror":a.mirrorMode=Math.round(e("mode")),a.mirrorPos=e("position");break;case"tile":a.tileN=Math.round(e("count"));break;case"beat_zoom":a.bzAmt=e("amount"),a.bzRate=e("rate");break;case"chroma_key":a.keyTol=e("tolerance"),a.keySoft=e("softness"),a.keyHue=e("hue");break;case"tilt_shift":a.tsAmt=e("amount"),a.tsPos=e("position"),a.tsWidth=e("width");break;case"tilt_2d":a.tiltX=e("shearX"),a.tiltY=e("shearY");break;case"drop_shadow":a.dsX=e("offsetX"),a.dsY=e("offsetY"),a.dsOpacity=e("opacity"),a.dsSoft=e("softness");break;case"posterize":a.posterLevels=e("levels");break;case"pixelate":a.pixSize=e("size");break;case"sketch":a.sketchAmount=e("amount"),a.sketchThresh=e("threshold");break;case"neon_edges":a.neonIntensity=e("intensity"),a.neonHue=e("hue"),a.neonThresh=e("threshold");break;case"oil_paint":a.oilRadius=e("radius"),a.oilMix=e("mix");break;case"duotone":a.duoHueA=e("hueA"),a.duoHueB=e("hueB"),a.duoMix=e("mix");break;case"film_grain":a.grainAmount=e("amount"),a.grainSize=e("size"),a.grainSpeed=e("speed");break;case"starfield":a.starDensity=e("density"),a.starSpeed=e("speed"),a.starTwinkle=e("twinkle");break;case"rain_overlay":a.rainIntensity=e("intensity"),a.rainAngle=e("angle"),a.rainSpeed=e("speed");break;case"sakura_petals":a.sakuraDensity=e("density"),a.sakuraSpeed=e("speed"),a.sakuraSway=e("sway"),a.sakuraSize=e("size");break;case"aurora_waves":a.auroraIntensity=e("intensity"),a.auroraHue=e("hue"),a.auroraSpeed=e("speed");break;case"grid_overlay":a.gridSpacing=e("spacing"),a.gridOpacity=e("opacity"),a.gridGlow=e("glow");break;case"motion_echo":a.echoDecay=e("decay"),a.echoX=e("offsetX"),a.echoY=e("offsetY");break;case"camera_shake":a.shakeIntensity=e("intensity"),a.shakeFreq=e("frequency"),a.shakeRot=e("rotation");break;case"soft_bloom":a.bloomThresh=e("threshold"),a.bloomIntensity=e("intensity");break;case"godrays":a.godIntensity=e("intensity"),a.godX=e("x"),a.godY=e("y"),a.godRays=e("rays");break;case"rim_light":a.rimIntensity=e("intensity"),a.rimHue=e("hue");break;case"hue_shift":a.hueDegrees=e("degrees");break;case"color_balance":a.cbR=e("red"),a.cbG=e("green"),a.cbB=e("blue");break;case"s_curve":a.scAmount=e("amount"),a.scPivot=e("pivot");break;case"sharpen":a.sharpenAmount=e("amount"),a.sharpenRadius=e("radius");break;case"cartoon":a.cartoonMix=e("mix"),a.cartoonLevels=e("levels"),a.cartoonEdge=e("edge");break;case"turbulent_displace":a.turbAmount=e("amount"),a.turbScale=e("scale"),a.turbSpeed=e("speed");break;case"posterize_time":break;default:{let t=h.EFFECT_MAP[i.type];if(t?.pluginId){let r=M(t.pluginId,i.type);if(r>0)for(let i of(a.pluginSel=r,t.params))a.pluginParams[`u_pl${r-1}_${R(i.key)}`]=e(i.key)}}}}return e.mask?(a.maskEnabled=1,a.maskType="ellipse"===e.mask.shape?1:2*("pen"===e.mask.shape),a.maskX=e.mask.x,a.maskY=e.mask.y,a.maskW=e.mask.width,a.maskH=e.mask.height,a.maskFeather=Math.max(.001,e.mask.feather),a.maskInvert=+!!e.mask.invert):(a.maskEnabled=0,a.maskType=0,a.maskPtsN=0),a}function q(e){return[e.videoWidth||e.naturalWidth||e.width||16,e.videoHeight||e.naturalHeight||e.height||16]}class j{gl=null;canvas=null;prog;blitProg;quadVBO=null;uniformLocs={};blitLocs={};pp=[];ppIndex=0;prevTex=null;prevSize="";prevSizeTex=null;texCache=new Map;bridgeChecked=new WeakSet;bridgeElements=new WeakSet;bridgeCanvases=new WeakMap;lutTex=null;dummyTex=null;lutSize=0;compLutEnabled=!1;lutSource=null;revision=0;unsubscribePlugins;renderScale=1;attach(e,t=!1){this.canvas=e;let a={alpha:!1,antialias:!1,depth:!1,stencil:!1,premultipliedAlpha:!1,preserveDrawingBuffer:t,powerPreference:"high-performance"};if(this.gl=e.getContext("webgl2",a)||e.getContext("webgl",a)||e.getContext("experimental-webgl",a),!this.gl)throw Error("WebGL not supported on this device");let i=this.gl;this.buildMainProgram(),this.blitProg=this.buildProgram(L,N),this.unsubscribePlugins?.(),this.unsubscribePlugins=E(()=>{this.revision++,this.refreshProgram()});let r=i.createBuffer();i.bindBuffer(i.ARRAY_BUFFER,r);let o=new Float32Array([-1,-1,0,1,1,-1,1,1,-1,1,0,0,1,1,1,0]);i.bufferData(i.ARRAY_BUFFER,o,i.STATIC_DRAW),this.quadVBO=r;let s=i.createTexture();i.bindTexture(i.TEXTURE_2D,s),i.texImage2D(i.TEXTURE_2D,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,new Uint8Array([0,0,0,255])),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MAG_FILTER,i.NEAREST),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE),this.dummyTex=s,this.resize()}buildProgram(e,t){let a=this.gl,i=(e,t)=>{let i=a.createShader(e);if(a.shaderSource(i,t),a.compileShader(i),!a.getShaderParameter(i,a.COMPILE_STATUS)){let e=a.getShaderInfoLog(i);throw Error(`Shader compile error: ${e}`)}return i},r=a.createProgram();if(a.attachShader(r,i(a.VERTEX_SHADER,e)),a.attachShader(r,i(a.FRAGMENT_SHADER,t)),a.linkProgram(r),!a.getProgramParameter(r,a.LINK_STATUS))throw Error(`Program link error: ${a.getProgramInfoLog(r)}`);return r}buildMainProgram(){this.prog=this.buildProgram(L,B(I())),this.uniformLocs={}}refreshProgram(){if(this.gl)try{let e=this.prog;this.buildMainProgram(),e&&this.gl.deleteProgram(e)}catch(e){try{let e=this.prog;this.prog=this.buildProgram(L,B("")),this.uniformLocs={},e&&this.gl.deleteProgram(e)}catch{}}}resize(){let e=this.gl,t=this.canvas;if(!e||!t)return;let a=t.width,i=t.height;for(let t of this.pp)e.deleteFramebuffer(t.fbo),e.deleteTexture(t.tex);this.pp=[];for(let t=0;t<2;t++){let t=e.createTexture();e.bindTexture(e.TEXTURE_2D,t),e.texImage2D(e.TEXTURE_2D,0,e.RGB,a,i,0,e.RGB,e.UNSIGNED_BYTE,null),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE);let r=e.createFramebuffer();e.bindFramebuffer(e.FRAMEBUFFER,r),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0),e.bindFramebuffer(e.FRAMEBUFFER,null),this.pp.push({fbo:r,tex:t})}this.ppIndex=0,this.prevTex&&(e.deleteTexture(this.prevTex),this.prevTex=null)}loadLUT(e){let t=this.gl;if(!t)return!1;let a=e.split("\n"),i=0,r=[];for(let e of a){let t=e.trim();if(!t||t.startsWith("#"))continue;if(t.startsWith("LUT_3D_SIZE")){i=parseInt(t.split(/\s+/)[1],10);continue}if(t.startsWith("LUT_")||t.startsWith("DOMAIN_")||t.startsWith("TITLE"))continue;let a=t.split(/\s+/).map(parseFloat);a.length>=3&&a.every(e=>!isNaN(e))&&r.push(a[0],a[1],a[2])}if(i<2||r.length<i*i*i*3)return!1;let o=i*i,s=i,l=new Uint8Array(o*s*4);for(let e=0;e<i;e++)for(let t=0;t<i;t++)for(let a=0;a<i;a++){let s=(e*i*i+t*i+a)*3,n=e%i,u=Math.floor(e/i),c=n*i+a,m=((u*i+t)*o+c)*4;l[m]=Math.round(255*r[s]),l[m+1]=Math.round(255*r[s+1]),l[m+2]=Math.round(255*r[s+2]),l[m+3]=255}this.lutTex&&t.deleteTexture(this.lutTex);let n=t.createTexture();return t.bindTexture(t.TEXTURE_2D,n),t.texImage2D(t.TEXTURE_2D,0,t.RGBA,o,s,0,t.RGBA,t.UNSIGNED_BYTE,l),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MIN_FILTER,t.LINEAR),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MAG_FILTER,t.LINEAR),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_S,t.CLAMP_TO_EDGE),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_T,t.CLAMP_TO_EDGE),this.lutTex=n,this.lutSize=i,this.compLutEnabled=!0,this.lutSource=e,this.revision++,!0}clearLUT(){this.compLutEnabled=!1,this.lutTex&&this.gl&&this.gl.deleteTexture(this.lutTex),this.lutTex=null,this.lutSize=0,this.lutSource=null,this.revision++}getOrCreateTexture(e,t){let a=this.gl,i=this.texCache.get(e),r=t.videoWidth??t.naturalWidth??t.width??t.width,o=t.videoHeight??t.naturalHeight??t.height??t.height,s=t instanceof HTMLVideoElement,l=s&&!t.paused?t.getVideoPlaybackQuality?.().totalVideoFrames:void 0,n=s&&!t.seeking?t.paused?`time:${t.currentTime}`:l?`frame:${l}`:void 0:void 0,u=n&&`${n}@${this.canvas.width}x${this.canvas.height}`;if(s&&i?.video===t&&i.w===r&&i.h===o&&(t.seeking||void 0!==u&&u===i.frame))return i;if(s&&!this.bridgeChecked.has(t)&&t.readyState>=2&&t.videoWidth>0&&(this.bridgeChecked.add(t),function(e){try{if(e.readyState<2||0===e.videoWidth)return!1;let t=[[8,4],[16,9],[24,13],[12,14],[20,5]],a=document.createElement("canvas");a.width=32,a.height=18;let i=a.getContext("2d");i.drawImage(e,0,0,32,18);let r=0;for(let[e,a]of t){let t=i.getImageData(e,a,1,1).data;r=Math.max(r,t[0],t[1],t[2])}let o=document.createElement("canvas");o.width=32,o.height=18;let s=o.getContext("webgl")||o.getContext("experimental-webgl");if(!s)return!1;let l=s.createTexture();s.bindTexture(s.TEXTURE_2D,l),s.texImage2D(s.TEXTURE_2D,0,s.RGBA,s.RGBA,s.UNSIGNED_BYTE,e);let n=(e,t)=>{let a=s.createShader(e);return s.shaderSource(a,t),s.compileShader(a),a},u=s.createProgram();s.attachShader(u,n(s.VERTEX_SHADER,"attribute vec2 p; varying vec2 uv; void main(){ uv = p*0.5+0.5; gl_Position = vec4(p,0,1); }")),s.attachShader(u,n(s.FRAGMENT_SHADER,"precision mediump float; varying vec2 uv; uniform sampler2D t; void main(){ gl_FragColor = texture2D(t, uv); }")),s.linkProgram(u),s.useProgram(u);let c=s.createBuffer();s.bindBuffer(s.ARRAY_BUFFER,c),s.bufferData(s.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),s.STATIC_DRAW);let m=s.getAttribLocation(u,"p");s.enableVertexAttribArray(m),s.vertexAttribPointer(m,2,s.FLOAT,!1,0,0),s.viewport(0,0,32,18),s.drawArrays(s.TRIANGLE_STRIP,0,4);let d=0;for(let[e,a]of t){let t=new Uint8Array(4);s.readPixels(e,a,1,1,s.RGBA,s.UNSIGNED_BYTE,t),d=Math.max(d,t[0],t[1],t[2])}return d<6&&r>12}catch{return!1}}(t)&&this.bridgeElements.add(t)),s&&this.bridgeElements.has(t))try{let s=Math.max(this.canvas.width,this.canvas.height),l=Math.min(1,s/Math.max(r,o)),n=Math.max(2,Math.round(r*l)),c=Math.max(2,Math.round(o*l)),m=this.bridgeCanvases.get(t);if(m&&m.width===n&&m.height===c||((m=document.createElement("canvas")).width=n,m.height=c,this.bridgeCanvases.set(t,m)),m.getContext("2d").drawImage(t,0,0,n,c),i&&i.src===m&&i.w===r&&i.h===o)a.bindTexture(a.TEXTURE_2D,i.tex),a.texImage2D(a.TEXTURE_2D,0,a.RGBA,a.RGBA,a.UNSIGNED_BYTE,m);else{let t=this.uploadTexture(m,r,o,i);if(!t)return null;i=t,this.texCache.set(e,i)}return i.video=t,i.frame=u,i}catch{return null}if(i&&i.src===t&&i.w===r&&i.h===o){a.bindTexture(a.TEXTURE_2D,i.tex);try{a.texImage2D(a.TEXTURE_2D,0,a.RGBA,a.RGBA,a.UNSIGNED_BYTE,t)}catch{return i}}else{let a=this.uploadTexture(t,r,o,i);if(!a)return null;i=a,this.texCache.set(e,i)}return s&&(i.video=t,i.frame=u),i}uploadTexture(e,t,a,i){let r=this.gl;i&&r.deleteTexture(i.tex);let o=r.createTexture();r.bindTexture(r.TEXTURE_2D,o),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MAG_FILTER,r.LINEAR);try{r.texImage2D(r.TEXTURE_2D,0,r.RGBA,r.RGBA,r.UNSIGNED_BYTE,e)}catch{return r.deleteTexture(o),null}return{tex:o,src:e,w:t,h:a}}disposeTexture(e){let t=this.texCache.get(e);t&&this.gl&&(this.gl.deleteTexture(t.tex),this.texCache.delete(e))}disposeAllTextures(){if(this.gl){for(let[e]of this.texCache)this.disposeTexture(e);this.prevTex&&(this.gl.deleteTexture(this.prevTex),this.prevTex=null)}}dispose(){this.unsubscribePlugins?.(),this.unsubscribePlugins=void 0,this.disposeAllTextures(),this.gl?.getExtension("WEBGL_lose_context")?.loseContext(),this.gl=null,this.canvas=null}trimUnusedTextures(e){if(this.gl)for(let t of[...this.texCache.keys()])e.has(t)||this.disposeTexture(t)}snapshotPrev(){let e=this.gl;this.pp[this.ppIndex],this.prevTex||(this.prevTex=e.createTexture(),e.bindTexture(e.TEXTURE_2D,this.prevTex),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)),e.activeTexture(e.TEXTURE2),e.bindTexture(e.TEXTURE_2D,this.prevTex);let t=this.canvas.width,a=this.canvas.height;this.prevSize===`${t}x${a}`&&this.prevSizeTex===this.prevTex?e.copyTexSubImage2D(e.TEXTURE_2D,0,0,0,0,0,t,a):(e.copyTexImage2D(e.TEXTURE_2D,0,e.RGB,0,0,t,a,0),this.prevSize=`${t}x${a}`,this.prevSizeTex=this.prevTex)}lastRenderStats={layers:0,drew:0,texOk:0};render(e,a,i){var r;let o,s=this.gl,l=this.canvas;if(!s||!l)return;let n=0,u=0,{time:c}=i,h=+!i.bypassEffects,f=l.width,p=l.height,v=e.composition,_=[...e.tracks].reverse().filter(e=>"audio"!==e.kind&&e.visible),g=[];for(let t of _)for(let a of e.clips)a.trackId===t.id&&c>=a.start-1e-6&&c<a.start+a.duration-1e-6&&g.push({clip:a,order:_.indexOf(t)});g.sort((e,t)=>e.order-t.order),s.bindFramebuffer(s.FRAMEBUFFER,this.pp[this.ppIndex].fbo);let b=(r=v.background,(o=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(r))?[parseInt(o[1],16)/255,parseInt(o[2],16)/255,parseInt(o[3],16)/255]:[0,0,0]);s.clearColor(b[0],b[1],b[2],+!i.mattePass),s.clear(s.COLOR_BUFFER_BIT),s.viewport(0,0,f,p),s.useProgram(this.prog),s.bindBuffer(s.ARRAY_BUFFER,this.quadVBO);let x=s.getAttribLocation(this.prog,"a_pos"),y=s.getAttribLocation(this.prog,"a_uv");s.enableVertexAttribArray(x),s.enableVertexAttribArray(y),s.vertexAttribPointer(x,2,s.FLOAT,!1,16,0),s.vertexAttribPointer(y,2,s.FLOAT,!1,16,8),s.activeTexture(s.TEXTURE1),s.bindTexture(s.TEXTURE_2D,this.pp[this.ppIndex].tex),s.uniform1i(this.loc("u_back"),1),s.activeTexture(s.TEXTURE2),this.prevTex?s.bindTexture(s.TEXTURE_2D,this.prevTex):s.bindTexture(s.TEXTURE_2D,this.pp[this.ppIndex].tex),s.uniform1i(this.loc("u_prev"),2),s.activeTexture(s.TEXTURE3),s.bindTexture(s.TEXTURE_2D,this.lutTex&&this.compLutEnabled?this.lutTex:this.dummyTex),s.uniform1i(this.loc("u_lutTex"),3),s.uniform1f(this.loc("u_lutEnabled"),this.compLutEnabled&&this.lutSize>1?1:0),s.uniform1f(this.loc("u_lutSize"),this.lutSize),s.activeTexture(s.TEXTURE4),s.bindTexture(s.TEXTURE_2D,this.dummyTex),s.uniform1i(this.loc("u_matte"),4),s.uniform1f(this.loc("u_matteMode"),0),s.uniform1f(this.loc("u_matteRender"),+!!i.mattePass);let k=null,T=null;if(!i.mattePass)for(let{clip:e}of g){if("camera"!==e.kind)continue;let t=c-e.start;T=e.camera,k={px:(0,m.evalProperty)(e,"x",t)+e.camera.positionX,py:(0,m.evalProperty)(e,"y",t)+e.camera.positionY,pz:(0,m.evalProperty)(e,"z",t)+e.camera.positionZ,rx:e.camera.rotationX,ry:e.camera.rotationY,rz:e.camera.rotationZ+(0,m.evalProperty)(e,"rotation",t),focalLength:e.camera.focalLength,zoom:e.camera.zoom*Math.max(.05,(0,m.evalProperty)(e,"scale",t))}}let w=new Set,E=new Map,A={alpha:1,alphaInv:2,luma:3,lumaInv:4};if(!i.mattePass)for(let{clip:t}of g){if(!t.trackMatte)continue;let a=e.clips.find(e=>e.id===t.trackMatte.sourceClipId);a&&(w.add(a.id),E.set(t.id,A[t.trackMatte.mode]))}for(let{clip:i}of g){let r=c-i.start;if("adjustment"===i.kind){this.renderAdjustment(i,r,c,h,f,p);continue}if("audio"===i.kind||"null"===i.kind||"camera"===i.kind||w.has(i.id))continue;let o=null,l=0,_=0;if("video"===i.kind){let e=i.effects.find(e=>"posterize_time"===e.type&&e.enabled),t=e?Math.floor(r*Math.max(1,e.params.fps??12))/Math.max(1,e.params.fps??12):r,s=(0,d.clipSourceTime)(i,t);(o=a.get(i,s))&&([l,_]=q(o))}else"image"===i.kind?(o=a.get(i,0))&&([l,_]=q(o)):"text"===i.kind?(o=a.getTextCanvas(i,r,v.fps))&&(l=o.width,_=o.height):"solid"===i.kind?(o=function(e,t,a,i){let r=`${t}|${a}x${i}`,o=U.get(e);if(o&&o.sig===r)return o.canvas;let s=document.createElement("canvas");s.width=Math.max(2,a),s.height=Math.max(2,i);let l=s.getContext("2d");return l?(l.fillStyle=t,l.fillRect(0,0,s.width,s.height),U.set(e,{sig:r,canvas:s}),s):null}(i.id,i.color,v.width,v.height))&&(l=v.width,_=v.height):"shape"===i.kind&&(o=function(e,t,a,i){let r=JSON.stringify(t)+`|${a}x${i}`,o=X.get(e);if(o&&o.sig===r)return o.canvas;let s=document.createElement("canvas");s.width=Math.max(2,a),s.height=Math.max(2,i);let l=s.getContext("2d");if(!l)return null;let n=s.width/2,u=s.height/2,c=Math.max(1,t.width/2),m=Math.max(1,t.height/2);if(l.beginPath(),"rect"===t.type){var d,h,f,p;let e;d=n-c,h=u-m,f=2*c,p=2*m,e=Math.max(0,Math.min(t.cornerRadius,Math.min(f,p)/2)),l.beginPath(),l.moveTo(d+e,h),l.lineTo(d+f-e,h),l.arcTo(d+f,h,d+f,h+e,e),l.lineTo(d+f,h+p-e),l.arcTo(d+f,h+p,d+f-e,h+p,e),l.lineTo(d+e,h+p),l.arcTo(d,h+p,d,h+p-e,e),l.lineTo(d,h+e),l.arcTo(d,h,d+e,h,e),l.closePath()}else if("ellipse"===t.type)l.ellipse(n,u,c,m,0,0,2*Math.PI);else{let e=Math.max(3,Math.min(24,Math.round(t.sides??6)));for(let t=0;t<e;t++){let a=t/e*Math.PI*2-Math.PI/2,i=n+Math.cos(a)*c,r=u+Math.sin(a)*m;0===t?l.moveTo(i,r):l.lineTo(i,r)}l.closePath()}return t.strokeWidth>0&&(l.strokeStyle=t.stroke,l.lineWidth=t.strokeWidth,l.stroke()),"none"!==t.fill&&(l.fillStyle=t.fill,l.fill()),X.set(e,{sig:r,canvas:s}),s}(i.id,i.shape,v.width,v.height))&&(l=v.width,_=v.height);let g=$(i,r);if(g.opacity=(0,m.evalProperty)(i,"opacity",r),g.blend=O[i.blendMode],g.lutEnabled=0,g.lutSize=0,g.hasTex=+!!o,h){let e=this.propertyVelocityComp(i,"x",r),t=this.propertyVelocityComp(i,"y",r),a=Math.hypot(e,t);a>40&&(g.motionVec=[e/a*Math.min(a/300,1)*10,-t/a*Math.min(a/300,1)*10])}else g.motionVec=[0,0];let b=(0,m.evalProperty)(i,"x",r),x=(0,m.evalProperty)(i,"y",r),y=(0,m.evalProperty)(i,"scale",r),A=(0,m.evalProperty)(i,"rotation",r)*Math.PI/180,S=(0,m.evalProperty)(i,"anchorX",r),R=(0,m.evalProperty)(i,"anchorY",r),P=Y(),M=H(G(1,1),V(.5,.5)),I=1;o&&l>0&&(I=Math.min(v.width/l,v.height/_));let D=(l/2-S)*I,C=(_/2-R)*I;P=H(V(2/v.width,2/v.height),P),P=H(G(b,x),P),P=H(V(y,y),P),P=H(W(A),P),P=H(G(-D,-C),P),P=H(V(I*l,I*_),P),P=H(M,P);let L=this.parentChainMatrix(e,i,c,v);if(i.threeD){let e=(0,m.evalProperty)(i,"z",r),t=I*(l||v.width),a=I*(_||v.height),o=(l/2-S)*I,s=(_/2-R)*I,n=function(e){let{cx:t,cy:a,cz:i,w:r,h:o,rotationDeg:s,cam:l,compW:n,compH:u}=e;if(!l)return null;let c=F(s),m=Math.cos(c),d=Math.sin(c),h=[[-r/2,-o/2],[r/2,-o/2],[r/2,o/2],[-r/2,o/2]].map(([e,r])=>[t+e*m-r*d,a+e*d+r*m,i]).map(e=>(function(e,t,a,i){let r=e[0]-t.px,o=e[1]-t.py,s=e[2]-t.pz;if([r,o,s]=function(e,t,a,i){let[r,o,s]=e;if(0!==i){let e=Math.cos(F(i)),t=Math.sin(F(i));[r,o]=[r*e-o*t,r*t+o*e]}if(0!==a){let e=Math.cos(F(a)),t=Math.sin(F(a));[r,s]=[r*e+s*t,-r*t+s*e]}if(0!==t){let e=Math.cos(F(t)),a=Math.sin(F(t));[o,s]=[o*e-s*a,o*a+s*e]}return[r,o,s]}([r,o,s],-t.rx,-t.ry,-t.rz),s<=.01)return null;let l=Math.max(16,t.focalLength)/Math.max(.01,t.zoom);return[r/s*(l/(a/2)),o/s*(l/(i/2))]})(e,l,n,u));for(let e of h)if(!e)return null;return function(e){if(4!==e.length)return null;let t=[[-1,-1],[1,-1],[1,1],[-1,1]],a=[],i=[];for(let r=0;r<4;r++){let[o,s]=t[r],[l,n]=e[r];a.push([o,s,1,0,0,0,-o*l,-s*l]),i.push(l),a.push([0,0,0,o,s,1,-o*n,-s*n]),i.push(n)}for(let e=0;e<8;e++){let t=e;for(let i=e+1;i<8;i++)Math.abs(a[i][e])>Math.abs(a[t][e])&&(t=i);if(1e-10>Math.abs(a[t][e]))return null;[a[e],a[t]]=[a[t],a[e]],[i[e],i[t]]=[i[t],i[e]];for(let t=e+1;t<8;t++){let r=a[t][e]/a[e][e];if(0!==r){for(let i=e;i<8;i++)a[t][i]-=r*a[e][i];i[t]-=r*i[e]}}}let r=Array(8).fill(0);for(let e=7;e>=0;e--){let t=i[e];for(let i=e+1;i<8;i++)t-=a[e][i]*r[i];r[e]=t/a[e][e]}return[r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],1]}(h)}({cx:b+-(o*Math.cos(A)-s*Math.sin(A)),cy:x+-(o*Math.sin(A)+s*Math.cos(A)),cz:e,w:t,h:a,rotationDeg:180*A/Math.PI,cam:k,compW:v.width,compH:v.height});if(n){if(P=n,k&&T&&T.depthOfField>0){let t=Math.min(24,Math.abs(Math.abs(e-k.pz)-T.focusDistance)*T.aperture*.02*T.depthOfField);t>.3&&(g.blurRadius=Math.max(g.blurRadius,t))}}else if(k)continue}if(L&&(P=H(P,L)),i.mask?.shape==="pen"&&o&&l>0){let e=function(e,t=5,a=24){let i=e.length;if(i<3)return e.map(e=>({x:e.x,y:e.y}));let r=Math.max(1,Math.min(t,Math.floor(a/i))),o=[];for(let t=0;t<i;t++){let a=e[t],s=e[(t+1)%i],l=a.x+(a.hOut?.x??0),n=a.y+(a.hOut?.y??0),u=s.x+(s.hIn?.x??0),c=s.y+(s.hIn?.y??0);for(let e=0;e<r;e++){let t=e/r,i=1-t;o.push({x:i*i*i*a.x+3*i*i*t*l+3*i*t*t*u+t*t*t*s.x,y:i*i*i*a.y+3*i*i*t*n+3*i*t*t*c+t*t*t*s.y})}}return o.slice(0,a)}(t(i.mask,r));if(e.length>=3){let t=l/Math.max(1,_),a=function(e){let[t,a,i,r,o,s,l,n,u]=e,c=o*u-s*n,m=-(r*u-s*l),d=r*n-o*l,h=t*c+a*m+i*d;if(1e-12>Math.abs(h))return[1,0,0,0,1,0,0,0,1];let f=1/h;return[c*f,-(a*u-i*n)*f,(a*s-i*o)*f,m*f,(t*u-i*l)*f,-(t*s-i*r)*f,d*f,-(t*n-a*l)*f,(t*o-a*r)*f]}(P),i=[];for(let r of e){let e=r.x/v.width*2,o=r.y/v.height*2,s=a[0]*e+a[3]*o+a[6],l=a[1]*e+a[4]*o+a[7];i.push((.5*s+.5)*t,.5-.5*l)}g.maskPts=i,g.maskPtsN=Math.min(24,e.length),g.maskAspect=t}else g.maskPtsN=0}else g.maskPtsN=0;if(!o||0===l||0===_)continue;n++;let z=E.get(i.id)??0;if(z>0&&i.trackMatte){let t=this.renderMatteSource(e,a,i.trackMatte.sourceClipId,c);s.activeTexture(s.TEXTURE4),s.bindTexture(s.TEXTURE_2D,t??this.dummyTex),s.uniform1i(this.loc("u_matte"),4),s.uniform1f(this.loc("u_matteMode"),t?z:0)}let B=this.pp[this.ppIndex],N=this.pp[1-this.ppIndex];if(s.bindFramebuffer(s.FRAMEBUFFER,N.fbo),s.viewport(0,0,f,p),this.copyCompositeInto(B,N,f,p),s.activeTexture(s.TEXTURE0),o){let e=this.getOrCreateTexture(i.id,o);e?s.bindTexture(s.TEXTURE_2D,e.tex):g.hasTex=0}else s.bindTexture(s.TEXTURE_2D,B.tex);s.uniform1i(this.loc("u_tex"),0),s.activeTexture(s.TEXTURE1),s.bindTexture(s.TEXTURE_2D,B.tex),s.uniform1i(this.loc("u_back"),1),s.activeTexture(s.TEXTURE2),s.bindTexture(s.TEXTURE_2D,this.prevTex??B.tex),s.uniform1i(this.loc("u_prev"),2),g.hasTex>.5&&u++,this.setUniforms(g,c,r,f,p,h),s.uniform1f(this.loc("u_srcFlip"),0),s.uniformMatrix3fv(this.loc("u_matrix"),!1,new Float32Array(P)),s.drawArrays(s.TRIANGLE_STRIP,0,4),this.ppIndex=1-this.ppIndex,z>0&&(s.activeTexture(s.TEXTURE4),s.bindTexture(s.TEXTURE_2D,this.dummyTex),s.uniform1f(this.loc("u_matteMode"),0))}if(this.lastRenderStats={layers:g.length,drew:n,texOk:u},h&&!i.mattePass&&g.some(({clip:e})=>e.effects.some(e=>e.enabled&&("motion_trails"===e.type||"motion_echo"===e.type)))&&this.snapshotPrev(),i.mattePass)return;s.bindFramebuffer(s.FRAMEBUFFER,null),s.viewport(0,0,f,p),s.useProgram(this.blitProg),s.bindBuffer(s.ARRAY_BUFFER,this.quadVBO);let S=s.getAttribLocation(this.blitProg,"a_pos"),R=s.getAttribLocation(this.blitProg,"a_uv");s.enableVertexAttribArray(S),s.enableVertexAttribArray(R),s.vertexAttribPointer(S,2,s.FLOAT,!1,16,0),s.vertexAttribPointer(R,2,s.FLOAT,!1,16,8),s.activeTexture(s.TEXTURE0),s.bindTexture(s.TEXTURE_2D,this.pp[this.ppIndex].tex),s.uniform1i(this.blitLoc("u_tex"),0),s.activeTexture(s.TEXTURE1),this.lutTex&&this.compLutEnabled?s.bindTexture(s.TEXTURE_2D,this.lutTex):s.bindTexture(s.TEXTURE_2D,this.dummyTex),s.uniform1i(this.blitLoc("u_lutTex"),1),s.uniform1f(this.blitLoc("u_lutEnabled"),this.compLutEnabled&&this.lutSize>1?1:0),s.uniform1f(this.blitLoc("u_lutSize"),this.lutSize);let P=Y();s.uniformMatrix3fv(this.blitLoc("u_matrix"),!1,new Float32Array(P)),s.uniform1f(this.blitLoc("u_flipY"),0),s.drawArrays(s.TRIANGLE_STRIP,0,4)}copyCompositeInto(e,t,a,i){let r=this.gl;r.bindFramebuffer(r.FRAMEBUFFER,t.fbo),r.viewport(0,0,a,i),r.useProgram(this.blitProg),r.bindBuffer(r.ARRAY_BUFFER,this.quadVBO);let o=r.getAttribLocation(this.blitProg,"a_pos"),s=r.getAttribLocation(this.blitProg,"a_uv");r.enableVertexAttribArray(o),r.enableVertexAttribArray(s),r.vertexAttribPointer(o,2,r.FLOAT,!1,16,0),r.vertexAttribPointer(s,2,r.FLOAT,!1,16,8),r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,e.tex),r.uniform1i(this.blitLoc("u_tex"),0),r.activeTexture(r.TEXTURE1),r.bindTexture(r.TEXTURE_2D,this.dummyTex),r.uniform1i(this.blitLoc("u_lutTex"),1),r.uniform1f(this.blitLoc("u_lutEnabled"),0),r.uniform1f(this.blitLoc("u_lutSize"),0),r.uniformMatrix3fv(this.blitLoc("u_matrix"),!1,new Float32Array(Y())),r.uniform1f(this.blitLoc("u_flipY"),0),r.drawArrays(r.TRIANGLE_STRIP,0,4),r.useProgram(this.prog);let l=r.getAttribLocation(this.prog,"a_pos"),n=r.getAttribLocation(this.prog,"a_uv");r.enableVertexAttribArray(l),r.enableVertexAttribArray(n),r.vertexAttribPointer(l,2,r.FLOAT,!1,16,0),r.vertexAttribPointer(n,2,r.FLOAT,!1,16,8)}parentChainMatrix(e,t,a,i){let r=null,o=t,s=new Set([t.id]);for(let t=0;t<8&&!(!o.parentId||s.has(o.parentId));t++){let t=e.clips.find(e=>e.id===o.parentId);if(!t||"audio"===t.kind)break;s.add(t.id);let l=a-t.start,n=(0,m.evalProperty)(t,"x",l),u=(0,m.evalProperty)(t,"y",l),c=(0,m.evalProperty)(t,"scale",l),d=(0,m.evalProperty)(t,"rotation",l)*Math.PI/180,h=(0,m.evalProperty)(t,"anchorX",l),f=(0,m.evalProperty)(t,"anchorY",l),p=H(G(1,1),V(.5,.5)),v=Y();v=H(V(2/i.width,2/i.height),v),v=H(G(n,u),v),v=H(V(c,c),v),v=H(W(d),v),v=H(G(-(i.width/2-h),-(i.height/2-f)),v),v=H(V(i.width,i.height),v),v=H(p,v),r=r?H(r,v):v,o=t}return r}renderMatteSource(e,t,a,i){let r=e.clips.find(e=>e.id===a);if(!r)return null;let o=this.ppIndex,s=this.lastRenderStats,l={...e,tracks:e.tracks.filter(e=>e.id===r.trackId),clips:[r]};this.render(l,t,{time:i,mattePass:!0});let n=this.pp[this.ppIndex].tex;return this.ppIndex=o,this.lastRenderStats=s,n}renderAdjustment(e,t,a,i,r,o){let s=this.gl,l=this.pp[this.ppIndex],n=this.pp[1-this.ppIndex];s.bindFramebuffer(s.FRAMEBUFFER,n.fbo),s.viewport(0,0,r,o),s.useProgram(this.prog),s.bindBuffer(s.ARRAY_BUFFER,this.quadVBO);let u=s.getAttribLocation(this.prog,"a_pos"),c=s.getAttribLocation(this.prog,"a_uv");s.enableVertexAttribArray(u),s.enableVertexAttribArray(c),s.vertexAttribPointer(u,2,s.FLOAT,!1,16,0),s.vertexAttribPointer(c,2,s.FLOAT,!1,16,8),s.activeTexture(s.TEXTURE0),s.bindTexture(s.TEXTURE_2D,l.tex),s.uniform1i(this.loc("u_tex"),0),s.activeTexture(s.TEXTURE1),s.bindTexture(s.TEXTURE_2D,l.tex),s.uniform1i(this.loc("u_back"),1),s.activeTexture(s.TEXTURE2),s.bindTexture(s.TEXTURE_2D,this.prevTex??l.tex),s.uniform1i(this.loc("u_prev"),2);let d=$(e,t);d.opacity=(0,m.evalProperty)(e,"opacity",t),d.blend=O[e.blendMode],d.hasTex=1,d.lutEnabled=0,d.lutSize=0,d.layerSize=[r,o],this.setUniforms(d,a,t,r,o,i);let h=Y();s.uniformMatrix3fv(this.loc("u_matrix"),!1,new Float32Array(h)),s.uniform1f(this.loc("u_srcFlip"),1),s.drawArrays(s.TRIANGLE_STRIP,0,4),this.ppIndex=1-this.ppIndex}propertyVelocityComp(e,t,a){let i=1/K,r=e.keyframes.find(e=>e.property===t);if(!r||0===r.keyframes.length)return 0;let o=(0,m.evalProperty)(e,t,Math.max(0,a-i));return((0,m.evalProperty)(e,t,a+i)-o)/(2*i)}loc(e){return e in this.uniformLocs||(this.uniformLocs[e]=this.gl.getUniformLocation(this.prog,e)),this.uniformLocs[e]}blitLoc(e){return e in this.blitLocs||(this.blitLocs[e]=this.gl.getUniformLocation(this.blitProg,e)),this.blitLocs[e]}setUniforms(e,t,a,i,r,o){let s=this.gl,l=e=>this.loc(e),n=(e,t)=>{let a=l(e);a&&s.uniform1f(a,t)},u=(e,t)=>{let a=l(e);a&&s.uniform2f(a,t[0],t[1])};if(n("u_hasTex",e.hasTex),s.uniform2f(l("u_layerSize"),e.layerSize[0],e.layerSize[1]),s.uniform2f(l("u_compRes"),i,r),n("u_time",t),n("u_localTime",a),n("u_opacity",e.opacity),n("u_blend",e.blend),n("u_efEnabled",o),n("u_exposure",e.exposure),n("u_contrast",e.contrast),n("u_saturation",e.saturation),n("u_temperature",e.temperature),n("u_tint",e.tint),n("u_lift",e.lift),n("u_gamma",e.gamma),n("u_gain",e.gain),n("u_vibrance",e.vibrance),n("u_vigAmount",e.vigAmount),n("u_vigSoft",e.vigSoft),n("u_blurRadius",e.blurRadius),u("u_blurDir",e.blurDir),u("u_motionVec",e.motionVec),n("u_zoomBlur",e.zoomBlur),n("u_radialBlur",e.radialBlur),u("u_rgbSplit",e.rgbSplit),n("u_waveAmount",e.waveAmount),n("u_waveFreq",e.waveFreq),n("u_waveSpeed",e.waveSpeed),n("u_glitch",e.glitch),n("u_glitchSpeed",e.glitchSpeed),n("u_glitchBlock",e.glitchBlock),n("u_crtCurve",e.crtCurve),n("u_crtScan",e.crtScan),n("u_glowThreshold",e.glowThreshold),n("u_glowIntensity",e.glowIntensity),n("u_glowRadius",e.glowRadius),n("u_auraThreshold",e.auraThreshold),n("u_auraIntensity",e.auraIntensity),n("u_auraHue",e.auraHue),n("u_auraPulse",e.auraPulse),n("u_flareX",e.flareX),n("u_flareY",e.flareY),n("u_flareIntensity",e.flareIntensity),n("u_flareStreak",e.flareStreak),n("u_leakIntensity",e.leakIntensity),n("u_leakHue",e.leakHue),n("u_leakAngle",e.leakAngle),n("u_slIntensity",e.slIntensity),n("u_slCount",e.slCount),n("u_slSpeed",e.slSpeed),n("u_slCX",e.slCX),n("u_slCY",e.slCY),n("u_flashAmount",e.flashAmount),n("u_flashMode",e.flashMode),n("u_burstProgress",e.burstProgress),n("u_burstIntensity",e.burstIntensity),n("u_burstHue",e.burstHue),n("u_boltIntensity",e.boltIntensity),n("u_boltCount",e.boltCount),n("u_boltSpeed",e.boltSpeed),n("u_partDensity",e.partDensity),n("u_partSize",e.partSize),n("u_partSpeed",e.partSpeed),n("u_partHue",e.partHue),n("u_halfMix",e.halfMix),n("u_halfScale",e.halfScale),n("u_halfAngle",e.halfAngle),n("u_trailsDecay",e.trailsDecay),n("u_maskEnabled",e.maskEnabled),n("u_maskType",e.maskType),n("u_maskX",e.maskX),n("u_maskY",e.maskY),n("u_maskW",e.maskW),n("u_maskH",e.maskH),n("u_maskFeather",e.maskFeather),n("u_maskInvert",e.maskInvert),e.maskPtsN>=3&&e.maskPts.length>=6){let t=l("u_maskPts[0]")??l("u_maskPts");t&&s.uniform2fv(t,e.maskPts.slice(0,2*Math.min(24,Math.floor(e.maskPtsN)))),n("u_maskPtsN",Math.min(24,Math.floor(e.maskPtsN)))}else n("u_maskPtsN",0);for(let[t,a]of(n("u_maskAspect",e.maskAspect),n("u_lutEnabled",0),n("u_lutSize",0),n("u_flipY",0),n("u_bulgeAmount",e.bulgeAmount),n("u_bulgeRadius",e.bulgeRadius),n("u_bulgeCX",e.bulgeCX),n("u_bulgeCY",e.bulgeCY),n("u_twirlAngle",e.twirlAngle),n("u_twirlRadius",e.twirlRadius),n("u_twirlCX",e.twirlCX),n("u_twirlCY",e.twirlCY),n("u_ripAmount",e.ripAmount),n("u_ripWave",e.ripWave),n("u_ripSpeed",e.ripSpeed),n("u_fisheyeAmount",e.fisheyeAmount),n("u_kaleidoSeg",e.kaleidoSeg),n("u_kaleidoRot",e.kaleidoRot),n("u_mirrorMode",e.mirrorMode),n("u_mirrorPos",e.mirrorPos),n("u_tileN",e.tileN),n("u_bzAmt",e.bzAmt),n("u_bzRate",e.bzRate),n("u_keyTol",e.keyTol),n("u_keySoft",e.keySoft),n("u_keyHue",e.keyHue),n("u_tsAmt",e.tsAmt),n("u_tsPos",e.tsPos),n("u_tsWidth",e.tsWidth),n("u_tiltX",e.tiltX),n("u_tiltY",e.tiltY),n("u_dsX",e.dsX),n("u_dsY",e.dsY),n("u_dsOpacity",e.dsOpacity),n("u_dsSoft",e.dsSoft),n("u_posterLevels",e.posterLevels),n("u_pixSize",e.pixSize),n("u_sketchAmount",e.sketchAmount),n("u_sketchThresh",e.sketchThresh),n("u_neonIntensity",e.neonIntensity),n("u_neonHue",e.neonHue),n("u_neonThresh",e.neonThresh),n("u_oilRadius",e.oilRadius),n("u_oilMix",e.oilMix),n("u_duoHueA",e.duoHueA),n("u_duoHueB",e.duoHueB),n("u_duoMix",e.duoMix),n("u_grainAmount",e.grainAmount),n("u_grainSize",e.grainSize),n("u_grainSpeed",e.grainSpeed),n("u_starDensity",e.starDensity),n("u_starSpeed",e.starSpeed),n("u_starTwinkle",e.starTwinkle),n("u_rainIntensity",e.rainIntensity),n("u_rainAngle",e.rainAngle),n("u_rainSpeed",e.rainSpeed),n("u_sakuraDensity",e.sakuraDensity),n("u_sakuraSpeed",e.sakuraSpeed),n("u_sakuraSway",e.sakuraSway),n("u_sakuraSize",e.sakuraSize),n("u_auroraIntensity",e.auroraIntensity),n("u_auroraHue",e.auroraHue),n("u_auroraSpeed",e.auroraSpeed),n("u_gridSpacing",e.gridSpacing),n("u_gridOpacity",e.gridOpacity),n("u_gridGlow",e.gridGlow),n("u_echoDecay",e.echoDecay),n("u_echoX",e.echoX),n("u_echoY",e.echoY),n("u_shakeIntensity",e.shakeIntensity),n("u_shakeFreq",e.shakeFreq),n("u_shakeRot",e.shakeRot),n("u_bloomThresh",e.bloomThresh),n("u_bloomIntensity",e.bloomIntensity),n("u_godIntensity",e.godIntensity),n("u_godX",e.godX),n("u_godY",e.godY),n("u_godRays",e.godRays),n("u_rimIntensity",e.rimIntensity),n("u_rimHue",e.rimHue),n("u_hueDegrees",e.hueDegrees),n("u_cbR",e.cbR),n("u_cbG",e.cbG),n("u_cbB",e.cbB),n("u_scAmount",e.scAmount),n("u_scPivot",e.scPivot),n("u_sharpenAmount",e.sharpenAmount),n("u_sharpenRadius",e.sharpenRadius),n("u_cartoonMix",e.cartoonMix),n("u_cartoonLevels",e.cartoonLevels),n("u_cartoonEdge",e.cartoonEdge),n("u_turbAmount",e.turbAmount),n("u_turbScale",e.turbScale),n("u_turbSpeed",e.turbSpeed),n("u_pluginSel",e.pluginSel),Object.entries(e.pluginParams))){let e=l(t);e&&s.uniform1f(e,a)}}}let K=30;var Q=e.i(77778),Z=e.i(99761);function J(e){for(let t of e)t.width=t.height=0}async function ee(e,t,a){let i=new Set(e.tracks.filter(e=>e.visible&&"audio"!==e.kind).map(e=>e.id)),r=e.clips.filter(e=>"audio"!==e.kind&&i.has(e.trackId));if(!r.length)throw Error("Añadí un clip visible para preparar la preview.");let s=Math.max(...r.map(e=>e.start+e.duration)),l=Math.max(0,Math.min(t,o(e)));if(l>=s)throw Error("Mové el cabezal a un tramo que tenga imagen.");let n=Math.min(s,l+4),u=Math.min(30,Math.max(1,e.composition.fps)),c=Math.max(1,Math.ceil((n-l)*u-1e-6)),{width:m,height:h}=e.composition,f=Math.min(1,480/Math.max(m,h),Math.sqrt(0x1800000/(m*h*c*4))),p=document.createElement("canvas");p.width=Math.max(2,Math.floor(m*f)),p.height=Math.max(2,Math.floor(h*f));let v=new j,_=Q.mediaManager.fork(),g=[],b=r.filter(e=>"video"===e.kind&&e.start<n&&e.start+e.duration>l),x=r.filter(e=>"image"===e.kind&&e.start<n&&e.start+e.duration>l);try{v.attach(p,!0),a.lut&&v.loadLUT(a.lut),await Promise.all(x.map(async e=>{if("image"!==e.kind)return;let t=performance.now()+4e3;for(;!_.getImage(e.assetId);){if(a.signal.throwIfAborted(),performance.now()>=t)throw Error(`No se pudo cargar \xab${e.name}\xbb.`);await new Promise(e=>setTimeout(e,25))}}));for(let t=0;t<c;t++){a.signal.throwIfAborted();let i=l+t/u;if(await Promise.all(b.map(async e=>{if(i<e.start||i>=e.start+e.duration)return;let t=_.getElement(e);if(!t)throw Error("Falta un video del proyecto.");if(await function(e,t){return e.readyState>=1||e.error?Promise.resolve():new Promise(a=>{let i=()=>{clearTimeout(r),e.removeEventListener("loadedmetadata",i),e.removeEventListener("error",i),t.removeEventListener("abort",i),a()},r=setTimeout(i,4e3);e.addEventListener("loadedmetadata",i,{once:!0}),e.addEventListener("error",i,{once:!0}),t.addEventListener("abort",i,{once:!0})})}(t,a.signal),a.signal.throwIfAborted(),t.readyState<1||t.error)throw Error(`No se pudo cargar \xab${e.name}\xbb.`);let r=i-e.start,o=e.effects.find(e=>"posterize_time"===e.type&&e.enabled),s=o?Math.max(1,o.params.fps??12):null,l=(0,d.clipSourceTime)(e,s?Math.floor(r*s)/s:r),n=(0,Q.mediaTime)(t,l);if(await _.seek(t,n,{tolerance:.012,capMs:1800,signal:a.signal}),t.seeking||t.readyState<2||Math.abs(t.currentTime-n)>.06)throw Error(`El fotograma de \xab${e.name}\xbb tard\xf3 demasiado en cargar.`)})),a.signal.throwIfAborted(),!v.gl||v.gl.isContextLost())throw Error("El navegador liberó el render de preview.");v.render(e,_,{time:i,bypassEffects:a.bypassEffects});let r=document.createElement("canvas");r.width=p.width,r.height=p.height;let o=r.getContext("2d",{alpha:!1});if(!o)throw Error("El navegador se quedó sin memoria para guardar la preview.");o.drawImage(p,0,0),g.push(r),(t%4==0||t+1===c)&&(a.onProgress((t+1)/c),await new Promise(e=>setTimeout(e,0)))}return a.signal.throwIfAborted(),{frames:g,start:l,end:n,fps:u}}catch(e){throw J(g),e}finally{_.dispose(),v.dispose(),p.width=p.height=0}}class et{compositor=new j;doc=null;state={playing:!1,time:0,rate:1,loop:!1,inPoint:null,outPoint:null};muted=!1;previewQuality=window.matchMedia("(pointer: coarse)").matches?"quarter":"half";compareMode=!1;listeners=new Set;rafId=0;lastFrameTime=0;seekInFlight=new Set;statsFrames=0;statsStart=0;lastTrim=0;bufferedSince=null;nativeMonitor=null;nativeClip=null;nativeVideo=null;nativeFrames=0;previewCanvas=null;paintedPreviewFrame=null;cachedPreview=null;previewAbort=null;previewCacheStatus={kind:"idle"};cacheListeners=new Set;cacheMediaRevision=0;cacheCompositorRevision=0;playbackRange=null;fps=30;suspended=!1;setSuspended(e){this.suspended=e,e?(this.previewAbort&&this.clearPreviewCache(),this.pause()):this.lastFrameTime=0}get currentTime(){return this.state.time}setDoc(e){var t;let a,i,r,o=this.doc;o!==e&&(this.clearPreviewCache(),this.nativeClip=e?(a=new Set((t=e).tracks.filter(e=>e.visible&&"audio"!==e.kind).map(e=>e.id)),r=(i=t.clips.filter(e=>"audio"!==e.kind&&a.has(e.trackId)))[0],1!==i.length||r?.kind!=="video"||r.mask||r.trackMatte||r.parentId||r.threeD||"normal"!==r.blendMode||r.keyframes.length||r.effects.some(e=>e.enabled)||0!==r.x||0!==r.y||1!==r.scale||0!==r.rotation||1!==r.opacity||0!==r.anchorX||0!==r.anchorY||r.reverse||r.timeRemap||1!==r.speed?null:r):null),this.doc=e,e&&(this.fps=e.composition.fps,K=e.composition.fps),o&&e&&o.id!==e.id&&(Q.mediaManager.dispose(),this.compositor.disposeAllTextures())}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}emit(){for(let e of this.listeners)e(this.state.time)}subscribeThrottled(e,t=100){let a=0;return this.subscribe(i=>{let r=ea();this.state.playing&&r-a<t||(a=r,e(i))})}rDoc=null;rFrame=NaN;rPlaying=!1;rRevision=-1;rSources=-1;rCompare=!1;rW=0;rH=0;rLast=0;rChanged=0;eTime=NaN;ePlaying=!1;eLast=0;attach(e,t,a){this.hideNativeVideo(),this.nativeMonitor=a,this.previewCanvas=t,this.paintedPreviewFrame=null,this.previewCanvas&&(this.previewCanvas.style.display="none"),this.rDoc=null,this.compositor.attach(e),this.ensureLoop()}renderScaleForQuality(){if(!this.doc)return .5;let e=this.previewQuality;return Math.min(1,("quarter"===e?480:"half"===e?960:1920)/Math.max(this.doc.composition.width,this.doc.composition.height))}syncCanvasSize(e){if(!this.doc)return;let t=this.renderScaleForQuality(),a=Math.max(2,Math.round(this.doc.composition.width*t)),i=Math.max(2,Math.round(this.doc.composition.height*t));(e.width!==a||e.height!==i)&&(e.width=a,e.height=i,this.compositor.resize())}ensureLoop(){if(this.rafId)return;let e=t=>{this.rafId=requestAnimationFrame(e);let a=this.lastFrameTime?(t-this.lastFrameTime)/1e3:0;this.lastFrameTime=t,this.tick(a)};this.rafId=requestAnimationFrame(e)}tick(e){if(this.suspended)return;let t=this.doc;if(!t)return;let a=this.compositor.canvas;if(!a)return;this.syncCanvasSize(a),(this.previewAbort||this.cachedPreview)&&(Q.mediaManager.revision!==this.cacheMediaRevision||this.compositor.revision!==this.cacheCompositorRevision)&&this.clearPreviewCache();let i=ea();if(this.state.playing&&(!this.cachedFrame(this.state.time)&&this.awaitingVideo(t)?this.bufferedSince??=i:this.bufferedSince=null,null===this.bufferedSince||i-this.bufferedSince>1200)){let a=this.state.time+e*this.state.rate,i=this.playbackRange?.end??this.state.outPoint??o(t),r=this.playbackRange?.start??this.state.inPoint??0;a>=i?this.state.loop?this.state.time=r:(this.state.time=i,this.pause()):this.state.time=Math.max(r,a)}let{playing:r,time:s}=this.state,l=r?Math.floor(s*this.fps+1e-5)/this.fps:s,n=this.cachedFrame(s),u=t!==this.rDoc||l!==this.rFrame||r!==this.rPlaying||this.compareMode!==this.rCompare||a.width!==this.rW||a.height!==this.rH||this.compositor.revision!==this.rRevision||Q.mediaManager.revision!==this.rSources||!!n!=!!this.paintedPreviewFrame;if(u&&(this.rChanged=i),u||!r&&(i-this.rChanged<350||this.seekInFlight.size>0)||i-this.rLast>250){this.rLast=i,this.rDoc=t,this.rFrame=l,this.rPlaying=r,this.rCompare=this.compareMode,this.rW=a.width,this.rH=a.height,this.rRevision=this.compositor.revision,this.rSources=Q.mediaManager.revision;let e=this.paintCachedFrame(n);(r||!e)&&((r||Z.audioEngine.ctx)&&Z.audioEngine.sync(t,s,r,this.muted,this.state.rate),this.driveMedia(t,s,r));let o=this.paintNativeVideo(t,s,e);!e&&!o&&(this.compositor.render(t,Q.mediaManager,{time:l,bypassEffects:this.compareMode}),this.statsFrames++)}let c=ea();if(c-this.lastTrim>2e3){this.lastTrim=c;let e=new Set;for(let a of t.clips)this.state.time>=a.start-3&&this.state.time<=a.start+a.duration+3&&e.add(a.id);this.compositor.trimUnusedTextures(e)}ea()-this.statsStart>1e3&&(this.fpsMeasured=Math.round(1e3*this.statsFrames/(ea()-this.statsStart)),this.statsFrames=0,this.statsStart=ea()),(this.state.playing||this.state.time!==this.eTime||this.state.playing!==this.ePlaying||ea()-this.eLast>500)&&(this.eTime=this.state.time,this.ePlaying=this.state.playing,this.eLast=ea(),this.emit())}fpsMeasured=0;hideNativeVideo(){let e=this.nativeVideo;e&&e.parentNode===this.nativeMonitor&&e.remove(),this.nativeVideo=null,this.nativeFrames=0}paintNativeVideo(e,t,a){let i=this.nativeMonitor,r=this.nativeClip;if(!i||!r||a||this.compositor.compLutEnabled||Q.mediaManager.synthesisHook||t<r.start||t>=r.start+r.duration)return this.hideNativeVideo(),!1;let o=Q.mediaManager.peekElement(r);if(!o||o.error||o.readyState<2&&this.nativeVideo!==o)return this.hideNativeVideo(),!1;i.style.backgroundColor=e.composition.background;let s=o.getVideoPlaybackQuality?.(),l=s?s.totalVideoFrames-s.droppedVideoFrames:0;return o!==this.nativeVideo?(this.hideNativeVideo(),o.style.cssText="display:block;width:100%;height:100%;object-fit:contain;pointer-events:none",i.appendChild(o),this.nativeVideo=o,this.nativeFrames=l):this.state.playing&&(this.statsFrames+=l?Math.max(0,l-this.nativeFrames):1,this.nativeFrames=l),!0}awaitingVideo(e){let t=this.state.time;return e.clips.some(a=>{if("video"!==a.kind||t<a.start||t>=a.start+a.duration)return!1;let i=e.tracks.find(e=>e.id===a.trackId);if(!i?.visible||a.reverse||a.timeRemap)return!1;let r=(0,d.clipAverageSpeed)(a)*this.state.rate;if(r<.25||r>4)return!1;let o=Q.mediaManager.peekElement(a);return!!o&&!o.error&&"1"!==o.dataset.playBlocked&&(o.readyState<2||o.seeking)})}driveMedia(e,t,a,i=!1){let r=new Set(e.tracks.filter(e=>"video"===e.kind&&e.visible).map(e=>e.id));for(let o of e.clips){if("video"!==o.kind)continue;if(!(r.has(o.trackId)&&t>=o.start&&t<o.start+o.duration)){let e=Q.mediaManager.peekElement(o);e&&Q.mediaManager.pause(e);continue}let e=Q.mediaManager.getElement(o);if(!e||e.error)continue;i&&delete e.dataset.playBlocked;let s=t-o.start,l=(0,Q.mediaTime)(e,(0,d.clipSourceTime)(o,s)),n=(0,d.clipAverageSpeed)(o)*this.state.rate,u=!o.timeRemap&&!o.reverse&&n>=.25&&n<=4;if(a&&u&&"1"!==e.dataset.playBlocked)Q.mediaManager.playAt(e,l,n);else{Q.mediaManager.pause(e);let t=a?.1:Math.min(.02,.45/this.fps);e.readyState>=1&&!e.seeking&&Math.abs(e.currentTime-l)>t&&!this.seekInFlight.has(o.id)&&(this.seekInFlight.add(o.id),Q.mediaManager.seek(e,l,{tolerance:t}).finally(()=>this.seekInFlight.delete(o.id)))}}}getPreviewCache=()=>this.previewCacheStatus;subscribePreviewCache=e=>(this.cacheListeners.add(e),()=>this.cacheListeners.delete(e));reportPreviewCache(e){for(let t of(this.previewCacheStatus=e,this.cacheListeners))t()}async preparePreview(){if(this.suspended||!this.doc)return;this.clearPreviewCache(),this.pause();let e=new AbortController;this.previewAbort=e,this.cacheMediaRevision=Q.mediaManager.revision,this.cacheCompositorRevision=this.compositor.revision,this.reportPreviewCache({kind:"preparing",progress:0});try{let t=await ee(this.doc,this.state.time,{bypassEffects:this.compareMode,lut:this.compositor.lutSource,signal:e.signal,onProgress:t=>{this.previewAbort===e&&this.reportPreviewCache({kind:"preparing",progress:t})}});if(e.signal.aborted)return void J(t.frames);this.cachedPreview=t,this.reportPreviewCache({kind:"ready",start:t.start,end:t.end})}catch(t){if(e.signal.aborted)return;throw this.reportPreviewCache({kind:"idle"}),t}finally{this.previewAbort===e&&(this.previewAbort=null)}}clearPreviewCache(){(this.previewAbort||this.cachedPreview)&&(this.previewAbort?.abort(),this.previewAbort=null,this.cachedPreview&&J(this.cachedPreview.frames),this.cachedPreview=null,this.playbackRange=null,this.paintCachedFrame(null),this.rDoc=null,this.reportPreviewCache({kind:"idle"}))}playCachedPreview(){let e=this.cachedPreview;e&&(this.seek(e.start),this.play(e))}cachedFrame(e){let t=this.cachedPreview;return t&&e>=t.start&&e<t.end?t.frames[Math.floor((e-t.start)*t.fps+1e-6)]??null:null}paintCachedFrame(e){let t=this.previewCanvas;if(!t)return!1;if(e===this.paintedPreviewFrame)return!!e;if(this.paintedPreviewFrame=null,!e)return t.style.display="none",!1;t.width!==e.width&&(t.width=e.width),t.height!==e.height&&(t.height=e.height);let a=t.getContext("2d",{alpha:!1});return!!a&&(a.drawImage(e,0,0),t.style.display="block",this.paintedPreviewFrame=e,this.statsFrames++,!0)}play(e=null){let t=this.doc;if(!t||this.suspended)return;this.previewAbort&&this.clearPreviewCache(),this.playbackRange=e;let a=e?.end??this.state.outPoint??o(t);this.state.time>=a&&(this.state.time=e?.start??this.state.inPoint??0),this.state.playing=!0,this.lastFrameTime=0,this.bufferedSince=null,Z.audioEngine.unlock(),Z.audioEngine.sync(t,this.state.time,!0,this.muted,this.state.rate),this.driveMedia(t,this.state.time,!0,!0),this.emit()}pause(){this.state.playing=!1,this.playbackRange=null,this.bufferedSince=null,Z.audioEngine.stopAll(),Q.mediaManager.pauseAll(),this.emit()}toggle(){this.state.playing?this.pause():this.play()}seek(e){let t=this.doc;t&&(this.previewAbort&&this.clearPreviewCache(),this.bufferedSince=null,this.state.time=Math.max(0,Math.min(o(t),e)),this.emit())}stepFrame(e){let t=this.doc?.composition.fps??30;this.pause(),this.seek(this.state.time+e/t)}goToStart(){this.seek(this.state.inPoint??0)}goToEnd(){let e=this.doc;e&&this.seek(this.state.outPoint??o(e))}setRate(e){this.state.rate=Math.min(4,Math.max(.1,e))}setQuality(e){this.previewQuality!==e&&this.clearPreviewCache(),this.previewQuality=e;let t=this.compositor.canvas;t&&this.doc&&(this.syncCanvasSize(t),this.compositor.resize())}toggleCompare(){return this.clearPreviewCache(),this.compareMode=!this.compareMode,this.compareMode}setLoop(e){this.state.loop=e}toggleMute(){return this.muted=!this.muted,this.muted}dispose(){this.clearPreviewCache(),this.hideNativeVideo(),this.rafId&&cancelAnimationFrame(this.rafId),this.rafId=0,Z.audioEngine.dispose(),Q.mediaManager.dispose(),this.compositor.disposeAllTextures()}}function ea(){return"u">typeof performance?performance.now():Date.now()}let ei=new et;e.s(["playbackEngine",0,ei],86250);let er={anime_hd:{label:"Anime HD (720p → 1080p)",description:"Progressive upscale + line-art reconstruction",params:{upscale:1.5,denoise:.25,deblock:.3,sharpen:.45,linePreserve:.8,detail:.3}},anime_4k:{label:"Anime 4K (1080p → 4K)",description:"2×-stepped upscale, denoise, line reconstruction",params:{upscale:2,denoise:.3,deblock:.35,sharpen:.5,linePreserve:.9,detail:.45}},upscale_2x:{label:"Upscale 2× (bicubic chain)",description:"Clean progressive 2× upscale",params:{upscale:2,denoise:.15,deblock:.2,sharpen:.3,linePreserve:.6,detail:.25}},upscale_4x:{label:"Upscale 4× (bicubic chain)",description:"Chain of 2× steps with detail reinjection",params:{upscale:4,denoise:.3,deblock:.4,sharpen:.5,linePreserve:.85,detail:.5}},denoise:{label:"Denoise",description:"Edge-aware noise reduction",params:{upscale:1,denoise:.6,deblock:.1,sharpen:.1,linePreserve:.6,detail:.1}},deblock:{label:"Deblock",description:"Compression artifact removal",params:{upscale:1,denoise:.2,deblock:.7,sharpen:.2,linePreserve:.5,detail:.15}},sharpen:{label:"Sharpen",description:"Detail + line crispness",params:{upscale:1,denoise:0,deblock:0,sharpen:.6,linePreserve:.7,detail:.2}},polish:{label:"Polish",description:"Gentle all-rounder: clean + crisp",params:{upscale:1,denoise:.3,deblock:.35,sharpen:.35,linePreserve:.7,detail:.3}},restore_lines:{label:"Restore Line Art",description:"Maximum line-art reconstruction pass",params:{upscale:1,denoise:.35,deblock:.4,sharpen:.55,linePreserve:1,detail:.35}}},eo=`
attribute vec2 a_pos;
attribute vec2 a_uv;
varying vec2 v_uv;
void main() {
  v_uv = a_uv;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`,es=`
precision highp float;
varying vec2 v_uv;
uniform sampler2D u_tex;
uniform vec2 u_texRes;
uniform vec2 u_outRes;
uniform float u_denoise;
uniform float u_deblock;
uniform float u_sharpen;
uniform float u_linePreserve;
uniform float u_detail;
uniform float u_step; // 0=denoise+deblock, 1=upscale, 2=edge-directed sharpen, 3=detail reconstruct

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec4 sampleTex(vec2 uv) { return texture2D(u_tex, uv); }

// Catmull-Rom bicubic (separable 4-tap per axis using cubic weights)
vec4 bicubic(vec2 uv) {
  vec2 texSize = u_texRes;
  vec2 coord = uv * texSize - 0.5;
  vec2 f = fract(coord);
  vec2 base = floor(coord);
  vec4 result = vec4(0.0);
  float wsum = 0.0;
  for (int dy = -1; dy <= 2; dy++) {
    for (int dx = -1; dx <= 2; dx++) {
      vec2 off = vec2(float(dx), float(dy));
      vec2 p = (base + off + 0.5) / texSize;
      float wx = cubicWeight(off.x - f.x);
      float wy = cubicWeight(off.y - f.y);
      float w = wx * wy;
      result += sampleTex(p) * w;
      wsum += w;
    }
  }
  return result / wsum;
}
float cubicWeight(float t) {
  t = abs(t);
  float t2 = t * t, t3 = t2 * t;
  if (t < 1.0) return 1.5 * t3 - 2.5 * t2 + 1.0;
  if (t < 2.0) return -0.5 * t3 + 2.5 * t2 - 4.0 * t + 2.0;
  return 0.0;
}

void main() {
  vec2 px = 1.0 / u_texRes;
  if (u_step < 0.5) {
    // Pass 0: bilateral denoise + deblock (flat-area blur)
    vec3 center = sampleTex(v_uv).rgb;
    vec3 acc = vec3(0.0);
    float wsum = 0.0;
    float centerLum = luma(center);
    for (int i = 0; i < 8; i++) {
      float a = float(i) * 0.7853981;
      vec2 dir = vec2(cos(a), sin(a));
      vec3 s = sampleTex(v_uv + dir * px * (1.0 + u_denoise * 2.0)).rgb;
      float lum = luma(s);
      float spatial = 1.0;
      float range = exp(-abs(lum - centerLum) * (6.0 + 18.0 * (1.0 - u_denoise)));
      float w = spatial * range;
      acc += s * w;
      wsum += w;
    }
    vec3 denoised = acc / wsum;
    // deblock: 8-neighbor average weighted by inverse variance of block
    vec3 blockAvg = vec3(0.0);
    for (int i = 0; i < 4; i++) {
      float a = float(i) * 1.5707963;
      vec2 dir = vec2(cos(a), sin(a));
      blockAvg += sampleTex(v_uv + dir * px * 2.0).rgb;
    }
    blockAvg /= 4.0;
    // variance estimate around pixel
    float v = 0.0;
    for (int i = 0; i < 4; i++) {
      float a = float(i) * 1.5707963;
      vec2 dir = vec2(cos(a), sin(a));
      v += abs(luma(sampleTex(v_uv + dir * px * 2.0).rgb) - centerLum);
    }
    v /= 4.0;
    float flat = 1.0 - smoothstep(0.02, 0.12, v);
    vec3 outc = mix(center, denoised, u_denoise);
    outc = mix(outc, blockAvg, u_deblock * flat * 0.8);
    gl_FragColor = vec4(outc, 1.0);
  } else if (u_step < 1.5) {
    // Pass 1: bicubic upscale
    gl_FragColor = bicubic(v_uv);
  } else if (u_step < 2.5) {
    // Pass 2: edge-DIRECTED line-art reconstruction.
    // Sobel gives gradient orientation; we sharpen ACROSS the line (along
    // the gradient) so anime ink lines re-crispen instead of halos forming.
    float tl = luma(sampleTex(v_uv + vec2(-px.x, -px.y)).rgb);
    float t  = luma(sampleTex(v_uv + vec2(0.0, -px.y)).rgb);
    float tr = luma(sampleTex(v_uv + vec2(px.x, -px.y)).rgb);
    float l  = luma(sampleTex(v_uv + vec2(-px.x, 0.0)).rgb);
    vec3 center = sampleTex(v_uv).rgb;
    float lum = luma(center);
    float r  = luma(sampleTex(v_uv + vec2(px.x, 0.0)).rgb);
    float bl = luma(sampleTex(v_uv + vec2(-px.x, px.y)).rgb);
    float b  = luma(sampleTex(v_uv + vec2(0.0, px.y)).rgb);
    float br = luma(sampleTex(v_uv + vec2(px.x, px.y)).rgb);
    float gx = -tl - 2.0 * l - bl + tr + 2.0 * r + br;
    float gy = -tl - 2.0 * t - tr + bl + 2.0 * b + br;
    float gmag = length(vec2(gx, gy));
    float edge = clamp(gmag * 1.4, 0.0, 1.0);
    // gradient direction (normalized)
    vec2 grad = gmag > 0.0001 ? vec2(gx, gy) / gmag : vec2(0.0);
    // sample along the gradient (across the line) for the unsharp pair
    vec3 across1 = sampleTex(v_uv + grad * px * 1.25).rgb;
    vec3 across0 = sampleTex(v_uv - grad * px * 1.25).rgb;
    vec3 alongBlur = (across1 + across0) * 0.5;
    vec3 detailC = center - alongBlur;
    float mask = mix(edge, max(edge, 0.22), 1.0 - u_linePreserve);
    vec3 outc = center + detailC * u_sharpen * 2.6 * mask;
    // flat-region deblock tail
    vec3 blurAvg = (sampleTex(v_uv + vec2(-px.x, 0.0)).rgb + sampleTex(v_uv + vec2(px.x, 0.0)).rgb +
                    sampleTex(v_uv + vec2(0.0, -px.y)).rgb + sampleTex(v_uv + vec2(0.0, px.y)).rgb) / 4.0;
    outc = mix(outc, blurAvg, u_deblock * (1.0 - edge) * 0.3);
    gl_FragColor = vec4(clamp(outc, 0.0, 1.0), 1.0);
  } else {
    // Pass 3: detail reconstruction — reinject high frequencies from a
    // wide guided blur (multi-scale unsharp, protects lines via linePreserve)
    vec3 center = sampleTex(v_uv).rgb;
    float lum = luma(center);
    vec3 fine = (sampleTex(v_uv + vec2(px.x, 0.0)).rgb + sampleTex(v_uv - vec2(px.x, 0.0)).rgb +
                 sampleTex(v_uv + vec2(0.0, px.y)).rgb + sampleTex(v_uv - vec2(0.0, px.y)).rgb) * 0.25;
    vec3 wide = (sampleTex(v_uv + vec2(px.x * 3.0, 0.0)).rgb + sampleTex(v_uv - vec2(px.x * 3.0, 0.0)).rgb +
                 sampleTex(v_uv + vec2(0.0, px.y * 3.0)).rgb + sampleTex(v_uv - vec2(0.0, px.y * 3.0)).rgb) * 0.25;
    vec3 fineBand = center - fine;
    vec3 midBand = fine - wide;
    // line mask: strong edges get fine-band boost, textures get mid-band
    float e2 = clamp(abs(lum - luma(wide)) * 3.0, 0.0, 1.0);
    float lineM = mix(0.45, clamp(e2 * 1.2, 0.0, 1.0), u_linePreserve);
    vec3 outc = center + fineBand * u_detail * 1.6 * lineM + midBand * u_detail * 0.9;
    gl_FragColor = vec4(clamp(outc, 0.0, 1.0), 1.0);
  }
}
`,el=new class{gl=null;canvas=null;prog=null;tex=null;vbo=null;locs={};ensure(){if(this.gl)return this.gl;let e=document.createElement("canvas"),t=e.getContext("webgl",{alpha:!1,antialias:!1,depth:!1})||e.getContext("experimental-webgl");if(!t)throw Error("WebGL unavailable for enhancement pipeline");let a=(e,a)=>{let i=t.createShader(e);if(t.shaderSource(i,a),t.compileShader(i),!t.getShaderParameter(i,t.COMPILE_STATUS))throw Error(`Enhance shader error: ${t.getShaderInfoLog(i)}`);return i},i=t.createProgram();if(t.attachShader(i,a(t.VERTEX_SHADER,eo)),t.attachShader(i,a(t.FRAGMENT_SHADER,es)),t.linkProgram(i),!t.getProgramParameter(i,t.LINK_STATUS))throw Error(`Enhance link error: ${t.getProgramInfoLog(i)}`);this.canvas=e,this.gl=t,this.prog=i;let r=t.createBuffer();return t.bindBuffer(t.ARRAY_BUFFER,r),t.bufferData(t.ARRAY_BUFFER,new Float32Array([-1,-1,0,1,1,-1,1,1,-1,1,0,0,1,1,1,0]),t.STATIC_DRAW),this.vbo=r,t}async process(e,t,a){return this.processParams(e,er[t].params,a)}async processParams(e,t,a){let i=this.ensure(),r=a??t.upscale,o=e.width,s=e.height;this.tex&&i.deleteTexture(this.tex);let l=i.createTexture();i.bindTexture(i.TEXTURE_2D,l),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MAG_FILTER,i.LINEAR),i.texImage2D(i.TEXTURE_2D,0,i.RGBA,i.RGBA,i.UNSIGNED_BYTE,e),this.tex=l;let n=(e,a,r,o,s,l)=>{let n=i.createTexture();i.bindTexture(i.TEXTURE_2D,n),i.texImage2D(i.TEXTURE_2D,0,i.RGBA,s,l,0,i.RGBA,i.UNSIGNED_BYTE,null),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MAG_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE);let u=i.createFramebuffer();i.bindFramebuffer(i.FRAMEBUFFER,u),i.framebufferTexture2D(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,n,0),i.viewport(0,0,s,l),i.useProgram(this.prog),i.bindBuffer(i.ARRAY_BUFFER,this.vbo);let c=i.getAttribLocation(this.prog,"a_pos"),m=i.getAttribLocation(this.prog,"a_uv");i.enableVertexAttribArray(c),i.enableVertexAttribArray(m),i.vertexAttribPointer(c,2,i.FLOAT,!1,16,0),i.vertexAttribPointer(m,2,i.FLOAT,!1,16,8),i.activeTexture(i.TEXTURE0),i.bindTexture(i.TEXTURE_2D,a);let d=e=>(e in this.locs||(this.locs[e]=i.getUniformLocation(this.prog,e)),this.locs[e]);return i.uniform1i(d("u_tex"),0),i.uniform2f(d("u_texRes"),r,o),i.uniform2f(d("u_outRes"),s,l),i.uniform1f(d("u_denoise"),t.denoise),i.uniform1f(d("u_deblock"),t.deblock),i.uniform1f(d("u_sharpen"),t.sharpen),i.uniform1f(d("u_linePreserve"),t.linePreserve),i.uniform1f(d("u_detail"),t.detail),i.uniform1f(d("u_step"),e),i.drawArrays(i.TRIANGLE_STRIP,0,4),{tex:n,fbo:u,w:s,h:l}},u={tex:l,fbo:null,w:o,h:s};if(t.denoise>.01||t.deblock>.01){let e=n(0,u.tex,u.w,u.h,u.w,u.h);u={tex:e.tex,fbo:e.fbo,w:e.w,h:e.h}}if(r>1.01){let e=r,a=Math.round(o*r);for(;e>1.001;){let i=Math.min(2,e),r=(e/=i)<=1.001?a:Math.round(u.w*i),l=Math.round(s/o*r),c=n(1,u.tex,u.w,u.h,r,l);if(u={tex:c.tex,fbo:c.fbo,w:c.w,h:c.h},e>1.001&&(t.sharpen>.01||t.detail>.01)){let e=n(2,u.tex,u.w,u.h,u.w,u.h),t=n(3,(u={tex:e.tex,fbo:e.fbo,w:e.w,h:e.h}).tex,u.w,u.h,u.w,u.h);u={tex:t.tex,fbo:t.fbo,w:t.w,h:t.h}}}}if(t.sharpen>.01){let e=n(2,u.tex,u.w,u.h,u.w,u.h);u={tex:e.tex,fbo:e.fbo,w:e.w,h:e.h}}if(t.detail>.01){let e=n(3,u.tex,u.w,u.h,u.w,u.h);u={tex:e.tex,fbo:e.fbo,w:e.w,h:e.h}}let c=document.createElement("canvas");c.width=u.w,c.height=u.h;let m=c.getContext("2d");i.bindFramebuffer(i.FRAMEBUFFER,u.fbo);let d=new Uint8Array(u.w*u.h*4);i.readPixels(0,0,u.w,u.h,i.RGBA,i.UNSIGNED_BYTE,d),i.bindFramebuffer(i.FRAMEBUFFER,null);let h=m.createImageData(u.w,u.h),f=4*u.w;for(let e=0;e<u.h;e++){let t=(u.h-1-e)*f,a=e*f;h.data.set(d.subarray(t,t+f),a)}return m.putImageData(h,0,0),i.deleteTexture(l),c}};async function en(t,a,i,r){let o=(await e.A(7637)).mediaManager;if(!o.assets.get(t))return null;let s=await o.extractFrame(t,a,720);if(!s)return null;let l=document.createElement("canvas");l.width=s.width,l.height=s.height,l.getContext("2d").drawImage(s,0,0);try{let e={...er[i].params,...r??{}},t=await el.processParams(s,e);return"close"in s&&"function"==typeof s.close&&s.close(),{before:l,after:t}}catch(e){throw"close"in s&&"function"==typeof s.close&&s.close(),e}}e.s(["ENHANCE_PRESETS",0,er,"enhanceFramePreview",()=>en,"enhanceRenderer",0,el],76519);let eu={low:2,medium:6,high:12,ultra:24};async function ec(e,t,a,i){let r=o(e),s=[],l="auto"===t.engine?"VideoEncoder"in window?"precise":"realtime":t.engine;if("realtime"===l&&await Promise.race([Z.audioEngine.unlock(),new Promise(e=>setTimeout(e,900))]),"precise"===l&&"VideoEncoder"in window)try{return await em(e,t,r,s,a,i)}catch(e){s.push(`Precise engine failed (${e instanceof Error?e.message:String(e)}); falling back to realtime capture.`)}return ep(e,t,r,s,a,i)}async function em(t,a,i,r,o,s){let l,n,u;o({phase:"prepare",progress:.02,message:"Preparing render pipeline…"});let{width:c,height:m,fps:d}=a,h=(a.bitrateMbps??eu[a.quality])*1e6,f=t.clips.some(e=>"audio"===e.kind||"video"===e.kind&&!t.tracks.find(t=>t.id===e.trackId)?.muted),p={codec:"avc1.42002A",width:c,height:m,bitrate:h,framerate:d},v={codec:"vp09.00.10.08",width:c,height:m,bitrate:h,framerate:d},[_,g]=await Promise.all([VideoEncoder.isConfigSupported(p).catch(()=>null),VideoEncoder.isConfigSupported(v).catch(()=>null)]);if(("mp4"===a.format||"auto"===a.format)&&_?.supported)l="mp4";else if(g?.supported)l="webm";else if(_?.supported)l="mp4";else throw Error("No supported hardware video encoder found for precise export");let b=null;if(f&&i>0&&"u">typeof AudioEncoder){let e="mp4"===l?{codec:"mp4a.40.2",sampleRate:48e3,numberOfChannels:2,bitrate:192e3}:{codec:"opus",sampleRate:48e3,numberOfChannels:2,bitrate:192e3},t=await AudioEncoder.isConfigSupported(e).catch(()=>null);t?.supported&&(b="mp4"===l?"aac":"opus")}f&&i>0&&!b&&r.push("u"<typeof AudioEncoder?`AudioEncoder is not available in this browser — audio is delivered as a separate WAV file.`:`This browser cannot encode ${"mp4"===l?"AAC (MP4 audio)":"Opus (WebM audio)"} — audio is delivered as a separate WAV file.`),f||(b=null);let x=null;if("mp4"===l){let{Muxer:t,ArrayBufferTarget:a}=await e.A(77986);x=e=>new t({target:new a,video:{codec:"avc",width:c,height:m},...e?{audio:{codec:"aac",numberOfChannels:e.numberOfChannels,sampleRate:e.sampleRate}}:{},fastStart:"in-memory"})}else{let{Muxer:t,ArrayBufferTarget:a}=await e.A(4607);x=e=>new t({target:new a,video:{codec:"V_VP9",width:c,height:m},...e?{audio:{codec:"A_OPUS",numberOfChannels:e.numberOfChannels,sampleRate:e.sampleRate}}:{}})}let y=x(b?{codec:b,numberOfChannels:2,sampleRate:48e3}:null),k=!1,T=null;if(f&&i>0){o({phase:"prepare",progress:.03,message:"Mixing audio offline…"});try{(T=await ed(t,i,48e3,2))&&0!==T.length||(T=null,r.push("No audible audio in the offline mix — video carries no sound."))}catch(e){T=null,r.push(`Audio mix failed: ${e instanceof Error?e.message:String(e)}`)}}if(T&&b)try{let e={codec:"aac"===b?"mp4a.40.2":"opus",sampleRate:48e3,numberOfChannels:2,bitrate:192e3},t=0,a=new AudioEncoder({output:(e,a)=>{y.addAudioChunk(e,a),t++},error:e=>r.push(`Audio encoder error: ${e.message}`)});a.configure(e);let i=T;for(let e=0;e<i.length;e+=48e3){let t=Math.min(48e3,i.length-e),r=new AudioData({format:"f32-planar",sampleRate:48e3,numberOfFrames:t,numberOfChannels:2,timestamp:Math.round(e/48e3*1e6),data:function(e,t,a,i){let r=new Float32Array(2*a);for(let i=0;i<2;i++){let o=e.getChannelData(Math.min(i,e.numberOfChannels-1));r.set(o.subarray(t,t+a),i*a)}return r}(i,e,t,2)});a.encode(r),r.close()}await a.flush(),a.close(),t>0?k=!0:r.push("Audio encoded but no chunks were produced — audio moves to the WAV sidecar.")}catch(e){k=!1,r.push(`Audio encode failed (${e instanceof Error?e.message:String(e)}) — audio moves to the WAV sidecar.`)}else f||r.push("No audio clips on the timeline.");let w=2*d,E=null,A=new VideoEncoder({output:(e,t)=>y.addVideoChunk(e,t),error:e=>{E=e.message}});A.configure("mp4"===l?p:v);let S=document.createElement("canvas");S.width=c,S.height=m;let R=new j;R.attach(S,!0),R.resize(),await ef(t,o,s);let P=Math.max(1,Math.round(i*d));for(let e=0;e<P;e++){if(s()){try{A.close()}catch{}throw Error("Export cancelled")}if(E){try{A.close()}catch{}throw Error(`Video encoder failed: ${E}`)}let i=e/d;if(e%15==0)for(let e of t.clips)"video"===e.kind&&i>e.start+e.duration+.5&&Q.mediaManager.releaseClip(e.id);await eh(t,i),R.render(t,Q.mediaManager,{time:i});let l=S;if(a.enhancePreset)try{l=await el.process(S,a.enhancePreset)}catch{r.push("Enhancement pass failed on a frame — frame encoded without enhancement.")}let n=new VideoFrame(l,{timestamp:Math.round(e/d*1e6),duration:Math.round(1e6/d)});if(A.encode(n,{keyFrame:e%w==0}),n.close(),e%3==0&&(o({phase:"render",progress:.05+e/P*.85,message:`Rendering frame ${e+1}/${P}`}),await new Promise(e=>setTimeout(e,0))),A.encodeQueueSize>30){let e=performance.now()+5e3;for(;A.encodeQueueSize>8;){if(performance.now()>e){try{A.close()}catch{}throw Error("Video encoder queue stalled (hardware encoder did not drain)")}await new Promise(e=>setTimeout(e,16))}}}o({phase:"encode",progress:.92,message:"Finalizing encoding…"}),await A.flush(),A.close(),y.finalize();let M=new Blob([y.target.buffer],{type:"mp4"===l?"video/mp4":"video/webm"});if(o({phase:"done",progress:1,message:"Export complete"}),R.disposeAllTextures(),!k&&T)try{n=function(e){let t=e.numberOfChannels,a=e.sampleRate,i=e.length,r=2*t,o=i*r,s=new ArrayBuffer(44+o),l=new DataView(s),n=(e,t)=>{for(let a=0;a<t.length;a++)l.setUint8(e+a,t.charCodeAt(a))};n(0,"RIFF"),l.setUint32(4,36+o,!0),n(8,"WAVE"),n(12,"fmt "),l.setUint32(16,16,!0),l.setUint16(20,1,!0),l.setUint16(22,t,!0),l.setUint32(24,a,!0),l.setUint32(28,a*r,!0),l.setUint16(32,r,!0),l.setUint16(34,16,!0),n(36,"data"),l.setUint32(40,o,!0);let u=[];for(let a=0;a<t;a++)u.push(e.getChannelData(a));let c=44;for(let e=0;e<i;e++)for(let a=0;a<t;a++){let t=Math.max(-1,Math.min(1,u[a][e]));l.setInt16(c,t<0?32768*t:32767*t,!0),c+=2}return new Blob([s],{type:"audio/wav"})}(T),u=`${(n.size/1024/1024).toFixed(1)}MB \xb7 ${T.numberOfChannels}ch \xb7 ${T.sampleRate}Hz PCM16`,r.push("Download the WAV too and you have the complete audio (works in any editor).")}catch(e){r.push(`WAV sidecar failed: ${e instanceof Error?e.message:String(e)}`)}return{blob:M,mimeType:"mp4"===l?"video/mp4":"video/webm",width:c,height:m,fps:d,durationSec:i,sizeBytes:M.size,engine:"precise (WebCodecs)",audioIncluded:k,audioWav:n,audioWavInfo:u,notes:r}}async function ed(e,t,a,i){let r=e.clips.filter(e=>"audio"===e.kind||"video"===e.kind).filter(t=>{let a=e.tracks.find(e=>e.id===t.trackId);return!a?.muted&&("audio"===t.kind||a?.kind==="video")});if(0===r.length)return null;let o=new(window.OfflineAudioContext||window.webkitOfflineAudioContext)(i,Math.ceil(t*a),a),s=o.createGain();for(let t of(s.gain.value=1,s.connect(o.destination),r)){let i=e.assets.find(e=>e.id===t.assetId);if(i)try{let e=await fetch(i.url),r=await e.arrayBuffer(),l=await o.decodeAudioData(r),n=o.createBufferSource();n.buffer=l;let u=(0,d.clipAverageSpeed)(t);n.playbackRate.value=Math.min(16,Math.max(.0625,Math.abs(u)||1));let c=n;for(let e of t.effects){if(!e.enabled)continue;let t=h.EFFECT_MAP[e.type];if(t&&"audio"===t.category){if("bass_boost"===e.type){let t=o.createBiquadFilter();t.type="lowshelf",t.frequency.value=200,t.gain.value=e.params.gainDB??6,c.connect(t),c=t}else if("treble_boost"===e.type){let t=o.createBiquadFilter();t.type="highshelf",t.frequency.value=3e3,t.gain.value=e.params.gainDB??4,c.connect(t),c=t}else if("compressor"===e.type){let t=o.createDynamicsCompressor();t.threshold.value=e.params.threshold??-18,t.ratio.value=e.params.ratio??6,c.connect(t),c=t}else if("reverb"===e.type){let t=o.createConvolver(),i=Math.max(.2,e.params.decay??1.8),r=Math.floor(a*i),l=o.createBuffer(2,r,a);for(let e=0;e<2;e++){let t=l.getChannelData(e);for(let e=0;e<r;e++)t[e]=(2*Math.random()-1)*Math.pow(1-e/r,2.5)}t.buffer=l;let n=o.createGain();n.gain.value=e.params.mix??.25;let u=o.createGain();u.gain.value=1,c.connect(t),t.connect(n),n.connect(s),c.connect(u),u.connect(s);continue}}}let m=o.createGain();c.connect(m),m.connect(s);let f="audio"===t.kind?t.volume:1,p=t.keyframes.find(e=>"volume"===e.property);if(p&&p.keyframes.length>0)for(let e of p.keyframes)m.gain.linearRampToValueAtTime(Math.max(0,e.value),t.start+e.time);else m.gain.value=f;"audio"===t.kind&&(t.fadeIn>0&&(m.gain.setValueAtTime(0,t.start),m.gain.linearRampToValueAtTime(f,t.start+t.fadeIn)),t.fadeOut>0&&(m.gain.setValueAtTime(f,t.start+t.duration-t.fadeOut),m.gain.linearRampToValueAtTime(0,t.start+t.duration)));let v=Math.max(0,t.start),_=Math.max(0,t.inPoint),g=Math.min(t.duration,l.duration/Math.abs(u||1));n.start(v,_,g)}catch{}}return await o.startRendering()}async function eh(e,t){let a=[];for(let i of e.clips){if("video"!==i.kind||t<i.start||t>=i.start+i.duration)continue;let e=Q.mediaManager.getElement(i);if(!e)continue;let r=(0,d.clipSourceTime)(i,t-i.start);a.push(Q.mediaManager.seek(e,r,{exact:!0}))}await Promise.all(a),await new Promise(e=>setTimeout(e,0))}async function ef(e,t,a){let i=new Set,r=[];for(let t of e.clips){if("video"!==t.kind||i.has(t.assetId+t.id))continue;i.add(t.assetId+t.id);let e=Q.mediaManager.getElement(t);e&&r.push(e)}0===r.length||(t({phase:"prepare",progress:.04,message:`Loading ${r.length} video source(s)…`}),await Promise.all(r.map(e=>new Promise(t=>{if(e.readyState>=2)return void t();let a=()=>{i(),t()},i=()=>{e.removeEventListener("loadeddata",a),e.removeEventListener("error",a),clearTimeout(r)};e.addEventListener("loadeddata",a,{once:!0}),e.addEventListener("error",a,{once:!0});let r=setTimeout(a,4e3)}))))}async function ep(e,t,a,i,r,o){r({phase:"prepare",progress:.02,message:"Preparing realtime capture…"});let s=function(){if("u"<typeof MediaRecorder)return null;for(let e of["video/mp4;codecs=avc1.42E01E,mp4a.40.2","video/mp4","video/webm;codecs=vp9,opus","video/webm;codecs=vp8,opus","video/webm"])if(MediaRecorder.isTypeSupported(e))return{mime:e,ext:e.startsWith("video/mp4")?"mp4":"webm"};return null}();if(!s)throw Error("MediaRecorder is not supported in this browser");let l=s.ext;"auto"!==t.format&&t.format!==l&&i.push(`This browser records ${l.toUpperCase()} — exporting ${l.toUpperCase()} instead of ${t.format.toUpperCase()}.`);let{width:n,height:u,fps:c}=t,m=document.createElement("canvas");m.width=n,m.height=u;let d=new j;d.attach(m,!0),d.resize();let h=m.captureStream(c),f=e.clips.filter(t=>{if("audio"!==t.kind&&"video"!==t.kind)return!1;let a=e.tracks.find(e=>e.id===t.trackId);return!a?.muted}),p=!1;if(f.length>0)try{let e=Z.audioEngine.getMediaStreamDestination().stream.getAudioTracks();for(let t of e)h.addTrack(t);(p=e.length>0)||i.push("Audio track could not be created — exporting video only.")}catch(e){i.push(`Audio capture unavailable: ${e instanceof Error?e.message:String(e)} — exporting video only.`)}else i.push("No audible clips — exporting video only.");let v=(t.bitrateMbps??eu[t.quality])*1e6,_=new MediaRecorder(h,{mimeType:s.mime,videoBitsPerSecond:v,audioBitsPerSecond:192e3}),g=[];_.ondataavailable=e=>{e.data.size>0&&g.push(e.data)};let b=new Promise(e=>{_.onstop=()=>e()}),x=!1;_.start(250);let y=performance.now(),k=Math.max(8,Math.round(1e3/Math.max(1,c)));if(await new Promise(t=>{let i=()=>{let s=(performance.now()-y)/1e3;if(o()){x=!0,t();return}s>=a?t():(ei.driveMedia(e,Math.min(s,a),!0),Z.audioEngine.sync(e,Math.min(s,a),!0,!1),d.render(e,Q.mediaManager,{time:Math.min(s,a)}),r({phase:"render",progress:.05+s/a*.85,message:`Recording ${s.toFixed(1)}s / ${a.toFixed(1)}s`}),setTimeout(i,k))};setTimeout(i,k)}),x){try{_.stop()}catch{}throw Error("Export cancelled")}await new Promise(e=>setTimeout(e,250)),_.stop(),await b,Z.audioEngine.stopAll(),d.disposeAllTextures();let T=new Blob(g,{type:s.mime.split(";")[0]});return r({phase:"done",progress:1,message:"Export complete"}),{blob:T,mimeType:s.mime.split(";")[0],width:n,height:u,fps:c,durationSec:a,sizeBytes:T.size,engine:`realtime (${l.toUpperCase()} via MediaRecorder)`,audioIncluded:p,notes:i}}e.s(["exportComposition",()=>ec],91407)}]);